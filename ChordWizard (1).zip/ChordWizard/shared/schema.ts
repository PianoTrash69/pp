import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const chordProgressions = pgTable("chord_progressions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  chords: jsonb("chords").notNull().$type<string[]>(),
  scale: text("scale").notNull(),
  tempo: text("tempo").notNull().default("120"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertChordProgressionSchema = createInsertSchema(chordProgressions).omit({
  id: true,
  createdAt: true,
});

export type InsertChordProgression = z.infer<typeof insertChordProgressionSchema>;
export type ChordProgression = typeof chordProgressions.$inferSelect;

// Music theory types
export interface Chord {
  name: string;
  root: string;
  type: string;
  notes: string[];
  roman: string;
  degree: number;
  quality: 'major' | 'minor' | 'diminished' | 'augmented';
}

export interface Scale {
  name: string;
  notes: string[];
  chords: Chord[];
  mode: string;
}
