import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Fallback responses for when OpenAI is unavailable
const fallbackResponses: Record<string, { answer: string; suggestions: string[] }> = {
  default: {
    answer: "I'm a music theory assistant! I can help explain concepts like scales, chords, progressions, and how they work together. The AI service is currently unavailable, but I can still provide some basic guidance.",
    suggestions: [
      "What are chord progressions?",
      "How do scales work?",
      "What makes chords sound good together?"
    ]
  },
  scale: {
    answer: "A scale is a collection of musical notes ordered by pitch. Each scale has a unique pattern of intervals that gives it its characteristic sound. Major scales sound bright and happy, while minor scales sound more melancholy or dramatic.",
    suggestions: [
      "Try the C major scale (all white keys on piano)",
      "Compare major and minor scales",
      "Explore different modes like Dorian or Mixolydian"
    ]
  },
  chord: {
    answer: "Chords are three or more notes played together that create harmony. The most basic chords are triads (3 notes). Major chords sound bright, minor chords sound sad, diminished chords sound tense, and augmented chords sound mysterious.",
    suggestions: [
      "Play a C major chord (C-E-G)",
      "Try a C minor chord (C-Eb-G)",
      "Build chords from your current scale"
    ]
  },
  progression: {
    answer: "Chord progressions are sequences of chords that create musical movement and emotion. Popular progressions like I-V-vi-IV work well because they create tension and resolution. Each chord has a function that leads naturally to the next.",
    suggestions: [
      "Try the vi-IV-I-V progression",
      "Play chords in your current scale",
      "Listen to how progressions create musical phrases"
    ]
  }
};

function getFallbackResponse(question: string): { answer: string; suggestions: string[] } {
  const lowercaseQuestion = question.toLowerCase();
  
  if (lowercaseQuestion.includes('scale') || lowercaseQuestion.includes('mode')) {
    return fallbackResponses.scale;
  } else if (lowercaseQuestion.includes('chord') && !lowercaseQuestion.includes('progression')) {
    return fallbackResponses.chord;
  } else if (lowercaseQuestion.includes('progression') || lowercaseQuestion.includes('sequence')) {
    return fallbackResponses.progression;
  }
  
  return fallbackResponses.default;
}

export async function getMusicTheoryAssistance(
  question: string, 
  context?: {
    currentScale?: string;
    currentChords?: string[];
    progressions?: string[];
  }
): Promise<{ answer: string; suggestions?: string[] }> {
  try {
    const contextInfo = context ? `
Current context:
- Scale: ${context.currentScale || 'None selected'}
- Active chords: ${context.currentChords?.join(', ') || 'None'}
- Progressions: ${context.progressions?.join(', ') || 'None'}
` : '';

    const systemPrompt = `You are a music theory assistant for ChordCraft, an interactive music theory learning application. Help users understand music theory concepts, chord progressions, scales, and harmony. Provide clear, educational explanations that are accessible to beginners but also informative for intermediate learners.

When answering:
- Be encouraging and supportive
- Use simple language but include proper musical terminology
- Provide practical examples when possible
- If relevant to the user's question, suggest specific chords, scales, or progressions they can try
- Keep responses concise but informative (2-3 paragraphs max)
- If you suggest actions, phrase them as things they can "try" or "explore" in the app

Focus on practical, hands-on learning rather than abstract theory.`;

    const userPrompt = `${contextInfo}

User question: ${question}

Please provide a helpful answer about music theory. If relevant, suggest up to 3 specific things they could try or explore in the application. Format your response as JSON with "answer" and optional "suggestions" array.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      answer: result.answer || "I'm here to help with music theory questions!",
      suggestions: result.suggestions || []
    };
  } catch (error) {
    console.error('OpenAI API error:', error);
    // Return fallback response instead of throwing error
    return getFallbackResponse(question);
  }
}

// Fallback lessons for when OpenAI is unavailable
const fallbackLessons: Record<string, { title: string; content: string; practiceActivities: string[] }> = {
  'circle of fifths': {
    title: "Understanding the Circle of Fifths",
    content: "The Circle of Fifths is a visual tool that shows the relationship between musical keys. Moving clockwise adds sharps, while moving counterclockwise adds flats. It helps you understand which keys are closely related and which chords naturally work together.\n\nThe Circle of Fifths is incredibly useful for understanding chord progressions. Keys that are next to each other on the circle share many common chords, making transitions between them sound smooth and natural.",
    practiceActivities: [
      "Try playing progressions that move around the circle (like C-G-D)",
      "Pick adjacent keys and compare their scales",
      "Build the vi-ii-V-I progression in different keys"
    ]
  },
  'roman numeral analysis': {
    title: "Roman Numeral Analysis Made Simple",
    content: "Roman numerals help us understand chord function regardless of the key. In major keys: I, IV, V are major; ii, iii, vi are minor; vii° is diminished. This system lets you analyze and understand progressions in any key.\n\nOnce you understand Roman numerals, you can transpose any progression to any key. The emotional effect stays the same because the relationships between chords remain consistent.",
    practiceActivities: [
      "Play the I-V-vi-IV progression in different keys",
      "Identify the Roman numerals of your current chord progression",
      "Try building the ii-V-I jazz progression"
    ]
  },
  'chord inversions': {
    title: "Smooth Voice Leading with Chord Inversions",
    content: "Chord inversions happen when you play a chord with a different note in the bass. Instead of C-E-G (root position), you might play E-G-C (first inversion) or G-C-E (second inversion). This creates smoother bass lines and more interesting harmony.\n\nInversions are key to good voice leading - the smooth movement between chords. By choosing the right inversion, you can create bass lines that step smoothly rather than jumping around.",
    practiceActivities: [
      "Play the same chord in different inversions",
      "Create a progression using inversions for smooth bass movement",
      "Listen to how inversions change the character of chords"
    ]
  }
};

export async function generateMusicTheoryLesson(topic: string): Promise<{
  title: string;
  content: string;
  practiceActivities: string[];
}> {
  try {
    const prompt = `Create a brief music theory lesson about "${topic}" for ChordCraft users. The lesson should be practical and hands-on, focusing on things they can explore in the app.

Format as JSON with:
- "title": A catchy lesson title
- "content": 2-3 paragraphs explaining the concept clearly
- "practiceActivities": Array of 2-3 specific activities they can do in ChordCraft to practice this concept

Keep it beginner-friendly but informative.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      title: result.title || `Learning ${topic}`,
      content: result.content || "Let's explore this music theory concept together!",
      practiceActivities: result.practiceActivities || []
    };
  } catch (error) {
    console.error('OpenAI API error:', error);
    // Return fallback lesson instead of throwing error
    const topicKey = topic.toLowerCase();
    const fallbackLesson = fallbackLessons[topicKey] || {
      title: `Understanding ${topic}`,
      content: `${topic} is an important music theory concept that helps you understand how music works. While the AI service is temporarily unavailable, you can explore this concept by experimenting with different scales and chord combinations in the app.\n\nMusic theory concepts like ${topic} become clearer through hands-on practice. Try building different chord progressions and listening to how they sound together.`,
      practiceActivities: [
        "Experiment with different chord combinations",
        "Try building progressions in different scales",
        "Listen to how different chords create different moods"
      ]
    };
    
    return fallbackLesson;
  }
}