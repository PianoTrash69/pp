// Music app doesn't need user storage currently
// This file is kept for potential future features

export interface IStorage {
  // Storage interface for future features
}

export class MemStorage implements IStorage {
  constructor() {
    // Initialize storage if needed
  }
}

export const storage = new MemStorage();
