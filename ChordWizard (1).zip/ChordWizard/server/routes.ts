import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getMusicTheoryAssistance, generateMusicTheoryLesson } from "./openai";
import { z } from "zod";
import Stripe from "stripe";

// Initialize Stripe - based on javascript_stripe blueprint  
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;

export async function registerRoutes(app: Express): Promise<Server> {
  // Music theory assistant routes
  app.post("/api/music-assistant", async (req, res) => {
    try {
      const { question, context } = req.body;
      
      if (!question || typeof question !== 'string') {
        return res.status(400).json({ error: "Question is required" });
      }

      const result = await getMusicTheoryAssistance(question, context);
      res.json(result);
    } catch (error) {
      console.error('Music assistant error:', error);
      res.status(500).json({ error: "Failed to get music theory assistance" });
    }
  });

  app.post("/api/music-lesson", async (req, res) => {
    try {
      const { topic } = req.body;
      
      if (!topic || typeof topic !== 'string') {
        return res.status(400).json({ error: "Topic is required" });
      }

      const result = await generateMusicTheoryLesson(topic);
      res.json(result);
    } catch (error) {
      console.error('Music lesson error:', error);
      res.status(500).json({ error: "Failed to generate lesson" });
    }
  });

  // Stripe donation route - based on javascript_stripe blueprint
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      if (!stripe) {
        return res.status(503).json({ error: "Donation functionality is not configured." });
      }

      const { amount } = req.body;
      
      // Robust amount validation
      const numAmount = parseFloat(amount);
      if (!amount || isNaN(numAmount) || numAmount < 1 || numAmount > 1000) {
        return res.status(400).json({ error: "Amount must be between $1 and $1000." });
      }
      
      // Convert to integer cents
      const amountInCents = Math.round(numAmount * 100);
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: amountInCents,
        currency: "usd",
        description: "Donation for Piano Teacher App",
        automatic_payment_methods: { enabled: true },
        metadata: {
          type: "donation"
        }
      });
      
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error('Stripe payment intent creation error:', error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
