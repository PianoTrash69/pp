import { useCallback } from 'react';
import { audioEngine } from '@/lib/audio';
import { Chord } from '@/lib/music-theory';
import { useToast } from '@/hooks/use-toast';

export function useAudio() {
  const { toast } = useToast();

  const playNote = useCallback(async (note: string, octave: number = 4) => {
    try {
      await audioEngine.playNote(note, octave);
    } catch (error) {
      console.error('Error playing note:', error);
      toast({
        title: "Audio Error",
        description: "Failed to play note. Please check your audio settings.",
        variant: "destructive"
      });
    }
  }, [toast]);

  const playChord = useCallback(async (chord: Chord, octave: number = 4) => {
    try {
      await audioEngine.playChord(chord.notes, octave);
    } catch (error) {
      console.error('Error playing chord:', error);
      toast({
        title: "Audio Error",
        description: "Failed to play chord. Please check your audio settings.",
        variant: "destructive"
      });
    }
  }, [toast]);

  const playProgression = useCallback(async (chords: Chord[], tempo: number = 120, octave: number = 4) => {
    try {
      const chordNotes = chords.map(chord => chord.notes);
      await audioEngine.playProgression(chordNotes, tempo, octave);
    } catch (error) {
      console.error('Error playing progression:', error);
      toast({
        title: "Audio Error",
        description: "Failed to play progression. Please check your audio settings.",
        variant: "destructive"
      });
    }
  }, [toast]);

  const setVolume = useCallback((volume: number) => {
    audioEngine.setVolume(volume);
  }, []);

  return {
    playNote,
    playChord,
    playProgression,
    setVolume
  };
}
