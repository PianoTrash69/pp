import { useState, useCallback } from 'react';
import { Chord } from '@/lib/music-theory';

export interface ChordProgressionSlot {
  id: number;
  chord: Chord | null;
}

export function useChordProgressions() {
  const [progression, setProgression] = useState<ChordProgressionSlot[]>(() => 
    Array.from({ length: 8 }, (_, i) => ({ id: i, chord: null }))
  );
  const [tempo, setTempo] = useState(120);

  const addChordToSlot = useCallback((slotId: number, chord: Chord) => {
    setProgression(prev => 
      prev.map(slot => 
        slot.id === slotId ? { ...slot, chord } : slot
      )
    );
  }, []);

  const removeChordFromSlot = useCallback((slotId: number) => {
    setProgression(prev => 
      prev.map(slot => 
        slot.id === slotId ? { ...slot, chord: null } : slot
      )
    );
  }, []);

  const clearProgression = useCallback(() => {
    setProgression(prev => 
      prev.map(slot => ({ ...slot, chord: null }))
    );
  }, []);

  const getFilledChords = useCallback(() => {
    return progression.filter(slot => slot.chord !== null).map(slot => slot.chord!);
  }, [progression]);

  const saveProgression = useCallback((name: string) => {
    const filledChords = getFilledChords();
    if (filledChords.length === 0) return false;

    const progressionData = {
      name,
      chords: filledChords.map(chord => chord.name),
      tempo: tempo.toString(),
      timestamp: Date.now()
    };

    const savedProgressions = JSON.parse(localStorage.getItem('chordProgressions') || '[]');
    savedProgressions.push(progressionData);
    localStorage.setItem('chordProgressions', JSON.stringify(savedProgressions));
    
    return true;
  }, [getFilledChords, tempo]);

  const loadProgression = useCallback((progressionData: any, chords: Chord[]) => {
    setProgression(prev => {
      return prev.map((slot, index) => {
        if (index < progressionData.chords.length) {
          const chordName = progressionData.chords[index];
          const chord = chords.find(c => c.name === chordName);
          return { ...slot, chord: chord || null };
        }
        return { ...slot, chord: null };
      });
    });
    setTempo(parseInt(progressionData.tempo) || 120);
  }, []);

  const getSavedProgressions = useCallback(() => {
    return JSON.parse(localStorage.getItem('chordProgressions') || '[]');
  }, []);

  return {
    progression,
    tempo,
    setTempo,
    setProgression,
    addChordToSlot,
    removeChordFromSlot,
    clearProgression,
    getFilledChords,
    saveProgression,
    loadProgression,
    getSavedProgressions
  };
}
