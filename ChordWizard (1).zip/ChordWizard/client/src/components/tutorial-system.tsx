import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { X, ChevronRight, ChevronLeft, SkipForward } from 'lucide-react';

interface TutorialStep {
  id: string;
  title: string;
  content: string;
  target?: string; // CSS selector for highlighting
  position?: 'top' | 'bottom' | 'left' | 'right';
}

interface TutorialSystemProps {
  onComplete: () => void;
  onSkip: () => void;
}

const tutorialSteps: TutorialStep[] = [
  {
    id: 'welcome',
    title: 'Welcome to ChordCraft! 🎵',
    content: 'ChordCraft helps you learn music theory by exploring scales, building chord progressions, and hearing how chords work together. Let\'s take a quick tour!',
  },
  {
    id: 'scale-selector',
    title: 'Choose Your Scale',
    content: 'Start by selecting a musical scale. Each scale contains chords that sound great together. Try different scales to hear how they change the mood of your music.',
    target: '[data-testid="select-scale"]',
    position: 'left'
  },
  {
    id: 'chord-library',
    title: 'Explore Chords',
    content: 'These are all the chords in your selected scale. Click any chord to hear it played or see its diagram. Each chord has different variants like 7ths and sus chords.',
    target: '.chord-library', // will need to add this class
    position: 'left'
  },
  {
    id: 'progression-builder',
    title: 'Build Progressions',
    content: 'Drag chords from the library into these slots to create a chord progression. Hit play to hear your progression in sequence. This is where the magic happens!',
    target: '[data-testid="progression-builder"]',
    position: 'top'
  },
  {
    id: 'quick-progressions',
    title: 'Try Quick Progressions',
    content: 'Not sure where to start? Try these popular chord progressions. They work in any scale and are used in countless songs across all genres.',
    target: '.quick-actions', // will need to add this class
    position: 'left'
  },
  {
    id: 'piano-keyboard',
    title: 'Piano Keyboard',
    content: 'Click notes on the piano to hear them. You can also see which notes make up each chord by clicking on chord buttons.',
    target: '[data-testid="piano-keyboard"]',
    position: 'bottom'
  },
  {
    id: 'music-assistant',
    title: 'Music Theory Assistant',
    content: 'Have questions about music theory? Click here to chat with our AI assistant. It can explain concepts, suggest progressions, and help you learn.',
    target: '[data-testid="button-open-assistant"]',
    position: 'left'
  },
  {
    id: 'complete',
    title: 'You\'re Ready to Create! 🚀',
    content: 'That\'s it! You now know how to use ChordCraft. Experiment with different scales, build progressions, and most importantly - have fun making music!',
  }
];

export function TutorialSystem({ onComplete, onSkip }: TutorialSystemProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  const handleNext = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    setIsVisible(false);
    setTimeout(onComplete, 300); // Allow fade out animation
  };

  const handleSkipTutorial = () => {
    setIsVisible(false);
    setTimeout(onSkip, 300);
  };

  const currentStepData = tutorialSteps[currentStep];

  if (!isVisible) return null;

  return (
    <>
      {/* Overlay */}
      <div className="fixed inset-0 bg-black/50 z-50 transition-opacity duration-300" />
      
      {/* Tutorial Card */}
      <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-[60] w-full max-w-md mx-4">
        <Card className="shadow-2xl border-2 border-primary/20 bg-background">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="text-xs">
                Step {currentStep + 1} of {tutorialSteps.length}
              </Badge>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSkipTutorial}
                className="text-muted-foreground hover:text-foreground"
                data-testid="button-skip-tutorial"
              >
                <SkipForward className="h-4 w-4 mr-1" />
                Skip Tour
              </Button>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleComplete}
              data-testid="button-close-tutorial"
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div>
              <CardTitle className="text-lg mb-3">{currentStepData.title}</CardTitle>
              <p className="text-muted-foreground leading-relaxed">
                {currentStepData.content}
              </p>
            </div>
            
            {/* Progress Bar */}
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentStep + 1) / tutorialSteps.length) * 100}%` }}
              />
            </div>
            
            {/* Navigation */}
            <div className="flex justify-between items-center">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentStep === 0}
                className="flex items-center gap-2"
                data-testid="button-previous-step"
              >
                <ChevronLeft className="h-4 w-4" />
                Previous
              </Button>
              
              <Button
                onClick={handleNext}
                className="flex items-center gap-2"
                data-testid="button-next-step"
              >
                {currentStep === tutorialSteps.length - 1 ? 'Get Started' : 'Next'}
                {currentStep < tutorialSteps.length - 1 && <ChevronRight className="h-4 w-4" />}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}

// Hook to manage tutorial state
export function useTutorial() {
  const [showTutorial, setShowTutorial] = useState(false);

  // Check if user has seen tutorial before
  useEffect(() => {
    const hasSeenTutorial = localStorage.getItem('chordcraft-tutorial-completed');
    if (!hasSeenTutorial) {
      // Show tutorial after a brief delay
      setTimeout(() => setShowTutorial(true), 1000);
    }
  }, []);

  const completeTutorial = () => {
    localStorage.setItem('chordcraft-tutorial-completed', 'true');
    setShowTutorial(false);
  };

  const skipTutorial = () => {
    localStorage.setItem('chordcraft-tutorial-completed', 'true');
    setShowTutorial(false);
  };

  const restartTutorial = () => {
    localStorage.removeItem('chordcraft-tutorial-completed');
    setShowTutorial(true);
  };

  return {
    showTutorial,
    completeTutorial,
    skipTutorial,
    restartTutorial
  };
}