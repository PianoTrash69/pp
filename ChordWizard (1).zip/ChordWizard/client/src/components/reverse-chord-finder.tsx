import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Search, X, Play, RotateCcw } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ReverseChordFinderProps {
  onPlayChord?: (notes: string[]) => void;
  className?: string;
}

interface ChordMatch {
  name: string;
  symbol: string;
  root: string;
  quality: string;
  intervals: string[];
  inversion?: string;
  confidence: number;
}

const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

// Note normalization map for enharmonic equivalents
const noteNormalizations: { [key: string]: string } = {
  'Db': 'C#', 'Eb': 'D#', 'Gb': 'F#', 'Ab': 'G#', 'Bb': 'A#'
};

// Chord patterns with intervals (semitones from root)
const chordPatterns = [
  // Triads
  { name: 'Major', symbol: '', intervals: [0, 4, 7], quality: 'Major Triad' },
  { name: 'Minor', symbol: 'm', intervals: [0, 3, 7], quality: 'Minor Triad' },
  { name: 'Diminished', symbol: '°', intervals: [0, 3, 6], quality: 'Diminished Triad' },
  { name: 'Augmented', symbol: '+', intervals: [0, 4, 8], quality: 'Augmented Triad' },
  
  // Seventh chords
  { name: 'Major 7th', symbol: 'maj7', intervals: [0, 4, 7, 11], quality: 'Major 7th' },
  { name: 'Minor 7th', symbol: 'm7', intervals: [0, 3, 7, 10], quality: 'Minor 7th' },
  { name: 'Dominant 7th', symbol: '7', intervals: [0, 4, 7, 10], quality: 'Dominant 7th' },
  { name: 'Half-Diminished 7th', symbol: 'm7♭5', intervals: [0, 3, 6, 10], quality: 'Half-Diminished 7th' },
  { name: 'Fully Diminished 7th', symbol: '°7', intervals: [0, 3, 6, 9], quality: 'Fully Diminished 7th' },
  { name: 'Minor Major 7th', symbol: 'mMaj7', intervals: [0, 3, 7, 11], quality: 'Minor Major 7th' },
  { name: 'Augmented 7th', symbol: '+7', intervals: [0, 4, 8, 10], quality: 'Augmented 7th' },
  
  // Extended chords
  { name: 'Add 9', symbol: 'add9', intervals: [0, 4, 7, 14], quality: 'Added 9th' },
  { name: 'Minor Add 9', symbol: 'madd9', intervals: [0, 3, 7, 14], quality: 'Minor Added 9th' },
  { name: 'Major 9th', symbol: 'maj9', intervals: [0, 4, 7, 11, 14], quality: 'Major 9th' },
  { name: 'Minor 9th', symbol: 'm9', intervals: [0, 3, 7, 10, 14], quality: 'Minor 9th' },
  { name: 'Dominant 9th', symbol: '9', intervals: [0, 4, 7, 10, 14], quality: 'Dominant 9th' },
  
  // Suspended chords
  { name: 'Suspended 2nd', symbol: 'sus2', intervals: [0, 2, 7], quality: 'Suspended 2nd' },
  { name: 'Suspended 4th', symbol: 'sus4', intervals: [0, 5, 7], quality: 'Suspended 4th' },
  { name: '7sus4', symbol: '7sus4', intervals: [0, 5, 7, 10], quality: 'Dominant 7th Sus 4' },
];

export function ReverseChordFinder({ onPlayChord, className }: ReverseChordFinderProps) {
  const [selectedNotes, setSelectedNotes] = useState<Set<string>>(new Set());
  const [matches, setMatches] = useState<ChordMatch[]>([]);

  // Convert note name to semitone number with enharmonic normalization
  const noteToSemitone = (note: string): number => {
    const normalizedNote = noteNormalizations[note] || note;
    return noteNames.indexOf(normalizedNote);
  };

  // Convert semitone back to note name
  const semitoneToNote = (semitone: number): string => {
    return noteNames[semitone % 12];
  };

  // Normalize intervals to start from 0
  const normalizeIntervals = (intervals: number[]): number[] => {
    if (intervals.length === 0) return [];
    const sorted = [...intervals].sort((a, b) => a - b);
    const root = sorted[0];
    return sorted.map(interval => (interval - root + 12) % 12);
  };

  // Find chord matches for given notes (moved to useEffect to avoid side effects in useMemo)
  const findChordMatches = useCallback(() => {
    if (selectedNotes.size < 2) {
      setMatches([]);
      return;
    }

    const noteArray = Array.from(selectedNotes);
    const semitones = noteArray.map(noteToSemitone).sort((a, b) => a - b);
    
    const foundMatches: ChordMatch[] = [];

    // Try each note as potential root
    noteArray.forEach(rootNote => {
      const rootSemitone = noteToSemitone(rootNote);
      
      // Calculate intervals from this root
      const intervalsFromRoot = semitones.map(semitone => 
        (semitone - rootSemitone + 12) % 12
      ).sort((a, b) => a - b);

      // Check against chord patterns
      chordPatterns.forEach(pattern => {
        if (pattern.intervals.length !== intervalsFromRoot.length) return;

        // Check if intervals match (allowing for octave displacement)
        const normalizedPattern = pattern.intervals.map(interval => interval % 12);
        const normalizedIntervals = intervalsFromRoot.map(interval => interval % 12);
        
        const matches = normalizedPattern.every(interval => 
          normalizedIntervals.includes(interval)
        ) && normalizedIntervals.every(interval =>
          normalizedPattern.includes(interval)
        );

        if (matches) {
          // Determine inversion
          let inversion = '';
          const bassNote = semitoneToNote(semitones[0]);
          if (bassNote !== rootNote) {
            const bassIndex = pattern.intervals.findIndex(interval => 
              semitoneToNote((rootSemitone + interval) % 12) === bassNote
            );
            if (bassIndex === 1) inversion = '1st inversion';
            else if (bassIndex === 2) inversion = '2nd inversion';
            else if (bassIndex === 3) inversion = '3rd inversion';
            else inversion = `/${bassNote}`;
          }

          // Calculate confidence based on how common the chord is
          let confidence = 100;
          if (pattern.intervals.length > 4) confidence -= 10; // Extended chords less common
          if (inversion) confidence -= 15; // Inversions less common
          if (pattern.name.includes('Diminished')) confidence -= 5;
          if (pattern.name.includes('Augmented')) confidence -= 5;

          foundMatches.push({
            name: `${rootNote} ${pattern.name}`,
            symbol: `${rootNote}${pattern.symbol}`,
            root: rootNote,
            quality: pattern.quality,
            intervals: pattern.intervals.map(interval => {
              const note = semitoneToNote((rootSemitone + interval) % 12);
              const intervalNames = ['R', '♭2', '2', '♭3', '3', '4', '♭5', '5', '♭6', '6', '♭7', '7'];
              return `${intervalNames[interval % 12]} (${note})`;
            }),
            inversion,
            confidence
          });
        }
      });
    });

    // Sort by confidence and remove duplicates
    const uniqueMatches = foundMatches
      .filter((match, index, self) => 
        index === self.findIndex(m => m.symbol === match.symbol && m.inversion === match.inversion)
      )
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 5); // Limit to top 5 matches

    setMatches(uniqueMatches);
  }, [selectedNotes]);

  useEffect(() => {
    findChordMatches();
  }, [findChordMatches]);

  const toggleNote = (note: string) => {
    setSelectedNotes(prev => {
      const newSet = new Set(prev);
      if (newSet.has(note)) {
        newSet.delete(note);
      } else {
        newSet.add(note);
      }
      return newSet;
    });
  };

  const clearNotes = () => {
    setSelectedNotes(new Set());
  };

  const playSelectedNotes = () => {
    if (onPlayChord && selectedNotes.size > 0) {
      onPlayChord(Array.from(selectedNotes));
    }
  };

  const playChordMatch = (match: ChordMatch) => {
    if (onPlayChord) {
      const rootSemitone = noteToSemitone(match.root);
      const chordNotes = chordPatterns
        .find(p => match.symbol.includes(p.symbol) || (p.symbol === '' && match.symbol === match.root))
        ?.intervals.map(interval => semitoneToNote((rootSemitone + interval) % 12)) || [];
      onPlayChord(chordNotes);
    }
  };

  return (
    <Card className={cn("reverse-chord-finder", className)}>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Search className="h-5 w-5 text-primary" />
          <span>Reverse Chord Finder</span>
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Select notes to identify chords
        </p>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Note Selection */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <label className="text-sm font-medium">Select Notes</label>
            <div className="flex space-x-2">
              {selectedNotes.size > 0 && (
                <Button
                  onClick={playSelectedNotes}
                  variant="outline"
                  size="sm"
                  data-testid="play-selected-notes"
                >
                  <Play className="h-4 w-4 mr-1" />
                  Play
                </Button>
              )}
              <Button
                onClick={clearNotes}
                variant="outline"
                size="sm"
                disabled={selectedNotes.size === 0}
                data-testid="button-clear-notes"
              >
                <X className="h-4 w-4 mr-1" />
                Clear
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-6 gap-2">
            {noteNames.map((note) => (
              <Button
                key={note}
                onClick={() => toggleNote(note)}
                variant={selectedNotes.has(note) ? "default" : "outline"}
                size="sm"
                className={cn(
                  "h-10 text-sm font-medium",
                  note.includes('#') && "bg-gray-800 text-white border-gray-600 hover:bg-gray-700",
                  selectedNotes.has(note) && note.includes('#') && "bg-blue-600 hover:bg-blue-700"
                )}
                data-testid={`note-${note.replace('#', 'sharp')}`}
              >
                {note}
              </Button>
            ))}
          </div>

          {selectedNotes.size > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              <span className="text-xs text-muted-foreground">Selected:</span>
              {Array.from(selectedNotes).sort((a, b) => noteToSemitone(a) - noteToSemitone(b)).map((note) => (
                <Badge key={note} variant="secondary" className="text-xs">
                  {note}
                </Badge>
              ))}
            </div>
          )}
        </div>

        <Separator />

        {/* Chord Matches */}
        <div className="space-y-4">
          <label className="text-sm font-medium">
            Chord Matches {matches.length > 0 && `(${matches.length})`}
          </label>
          
          {selectedNotes.size < 2 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Search className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Select at least 2 notes to find chord matches</p>
            </div>
          ) : matches.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p className="text-sm">No common chord patterns found for these notes</p>
              <p className="text-xs mt-1">Try different note combinations</p>
            </div>
          ) : (
            <div className="space-y-3">
              {matches.map((match, index) => (
                <Card key={index} className="border-l-4 border-l-blue-500">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-semibold text-lg" data-testid={`chord-match-${index}`}>
                          {match.name}
                        </h3>
                        <p className="text-sm text-muted-foreground font-mono">
                          {match.symbol}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <Badge 
                          variant={match.confidence >= 90 ? "default" : "secondary"}
                          className="text-xs"
                        >
                          {match.confidence}%
                        </Badge>
                        <Button
                          onClick={() => playChordMatch(match)}
                          variant="outline"
                          size="sm"
                          data-testid={`play-chord-${index}`}
                        >
                          <Play className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-2 text-sm">
                      <div>
                        <span className="font-medium">Quality:</span> {match.quality}
                      </div>
                      {match.inversion && (
                        <div>
                          <span className="font-medium">Inversion:</span> {match.inversion}
                        </div>
                      )}
                      <div>
                        <span className="font-medium">Intervals:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {match.intervals.map((interval, i) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {interval}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Quick Examples */}
        <div className="space-y-3">
          <Separator />
          <label className="text-sm font-medium">Quick Examples</label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { name: 'C Major', notes: ['C', 'E', 'G'] },
              { name: 'Am', notes: ['A', 'C', 'E'] },
              { name: 'F7', notes: ['F', 'A', 'C', 'Eb'] },
              { name: 'Dm7♭5', notes: ['D', 'F', 'Ab', 'C'] }
            ].map((example, index) => (
              <Button
                key={index}
                onClick={() => setSelectedNotes(new Set(example.notes))}
                variant="outline"
                size="sm"
                className="text-xs"
                data-testid={`example-${index}`}
              >
                {example.name}
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}