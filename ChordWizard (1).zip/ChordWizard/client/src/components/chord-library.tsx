import { useState } from 'react';
import { Eye, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAudio } from '@/hooks/use-audio';
import { Chord } from '@/lib/music-theory';

interface ChordLibraryProps {
  chords: Chord[];
  onShowDiagram: (chord: Chord) => void;
}

export function ChordLibrary({ chords, onShowDiagram }: ChordLibraryProps) {
  const [draggingChord, setDraggingChord] = useState<string | null>(null);
  const { playChord } = useAudio();

  const handleDragStart = (e: React.DragEvent, chord: Chord) => {
    e.dataTransfer.setData('application/json', JSON.stringify(chord));
    setDraggingChord(chord.name);
  };

  const handleDragEnd = () => {
    setDraggingChord(null);
  };

  const handleChordClick = async (chord: Chord) => {
    await playChord(chord);
  };

  const getQualityColor = (quality: string) => {
    switch (quality) {
      case 'major':
        return 'bg-primary';
      case 'minor':
        return 'bg-destructive';
      case 'diminished':
        return 'bg-muted';
      case 'augmented':
        return 'bg-accent';
      default:
        return 'bg-muted';
    }
  };

  return (
    <div className="bg-card rounded-xl p-4 border border-border shadow-sm chord-library">
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-lg font-semibold text-card-foreground">Chord Library</h3>
        <Button
          variant="ghost"
          size="sm"
          className="text-primary hover:text-primary/80"
          data-testid="button-chord-help"
        >
          <Info className="mr-1 h-3 w-3" />
          Help
        </Button>
      </div>
      
      <ScrollArea className="h-96">
        <div className="space-y-2 pr-4">
          {chords.map((chord, index) => (
            <div
              key={`${chord.name}-${index}`}
              className={`chord-card p-3 bg-secondary rounded-lg border border-border cursor-grab ${
                draggingChord === chord.name ? 'dragging' : ''
              }`}
              draggable
              onDragStart={(e) => handleDragStart(e, chord)}
              onDragEnd={handleDragEnd}
              onClick={() => handleChordClick(chord)}
              data-testid={`chord-card-${chord.root}-${chord.type}`}
            >
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="font-medium text-secondary-foreground">{chord.name}</h4>
                  <p className="text-xs text-muted-foreground">
                    {chord.roman} - {chord.degree === 1 ? 'Tonic' : 
                     chord.degree === 2 ? 'Supertonic' :
                     chord.degree === 3 ? 'Mediant' :
                     chord.degree === 4 ? 'Subdominant' :
                     chord.degree === 5 ? 'Dominant' :
                     chord.degree === 6 ? 'Submediant' :
                     'Leading Tone'}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    onShowDiagram(chord);
                  }}
                  data-testid={`button-show-diagram-${chord.root}-${chord.type}`}
                >
                  <Eye className="h-4 w-4 text-primary" />
                </Button>
              </div>
              <div className="mt-2 flex space-x-1">
                {chord.notes.map((note, noteIndex) => (
                  <div
                    key={noteIndex}
                    className={`w-2 h-2 rounded-full ${getQualityColor(chord.quality)}`}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
