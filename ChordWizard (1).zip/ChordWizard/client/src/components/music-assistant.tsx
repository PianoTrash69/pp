import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Bot, Send, Lightbulb, Book, X } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import type { Scale } from '@/lib/music-theory';

interface AssistantResponse {
  answer: string;
  suggestions?: string[];
}

interface LessonResponse {
  title: string;
  content: string;
  practiceActivities: string[];
}

interface MusicAssistantProps {
  currentScale: Scale;
  currentChords: string[];
  onClose: () => void;
}

export function MusicAssistant({ currentScale, currentChords, onClose }: MusicAssistantProps) {
  const [question, setQuestion] = useState('');
  const [conversation, setConversation] = useState<Array<{
    type: 'question' | 'answer';
    content: string;
    suggestions?: string[];
  }>>([]);

  const askMutation = useMutation({
    mutationFn: async (data: { question: string; context?: any }) => {
      const response = await apiRequest('POST', '/api/music-assistant', data);
      return await response.json() as AssistantResponse;
    },
    onSuccess: (response) => {
      setConversation(prev => [
        ...prev,
        { type: 'answer', content: response.answer, suggestions: response.suggestions }
      ]);
    },
    onError: (error) => {
      setConversation(prev => [
        ...prev,
        { type: 'answer', content: 'Sorry, I encountered an error. Please try again later.' }
      ]);
    }
  });

  const lessonMutation = useMutation({
    mutationFn: async (topic: string) => {
      const response = await apiRequest('POST', '/api/music-lesson', { topic });
      return await response.json() as LessonResponse;
    },
    onSuccess: (response) => {
      setConversation(prev => [
        ...prev,
        { 
          type: 'answer', 
          content: `**${response.title}**\n\n${response.content}\n\n**Practice Activities:**\n${response.practiceActivities.map((activity: string, i: number) => `${i + 1}. ${activity}`).join('\n')}` 
        }
      ]);
    },
    onError: (error) => {
      setConversation(prev => [
        ...prev,
        { type: 'answer', content: 'Sorry, I couldn\'t generate that lesson. Please try again later.' }
      ]);
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    const context = {
      currentScale: `${currentScale.name}`,
      currentChords: currentChords,
      progressions: []
    };

    setConversation(prev => [...prev, { type: 'question', content: question }]);
    askMutation.mutate({ question, context });
    setQuestion('');
  };

  const handleSuggestionClick = (suggestion: string) => {
    setQuestion(suggestion);
  };

  const quickTopics = [
    'Circle of Fifths',
    'Roman Numeral Analysis',
    'Chord Inversions',
    'Voice Leading',
    'Modal Interchange',
    'Secondary Dominants'
  ];

  return (
    <Card className="w-full max-w-2xl mx-auto bg-card border-border shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="flex items-center gap-2 text-card-foreground">
          <Bot className="h-5 w-5 text-primary" />
          Music Theory Assistant
        </CardTitle>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onClose}
          data-testid="button-close-assistant"
        >
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Quick Topics */}
        <div>
          <h4 className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-2">
            <Book className="h-4 w-4" />
            Learn About
          </h4>
          <div className="flex flex-wrap gap-2">
            {quickTopics.map(topic => (
              <Badge 
                key={topic}
                variant="secondary" 
                className="cursor-pointer hover:bg-secondary/80 transition-colors"
                onClick={() => lessonMutation.mutate(topic)}
                data-testid={`badge-topic-${topic.toLowerCase().replace(/\s+/g, '-')}`}
              >
                {topic}
              </Badge>
            ))}
          </div>
        </div>

        <Separator />

        {/* Conversation */}
        <ScrollArea className="h-64 w-full rounded-md border p-4 bg-muted/30">
          {conversation.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              <Bot className="h-12 w-12 mx-auto mb-4 text-primary/50" />
              <p className="text-sm">
                Ask me anything about music theory! I can help explain scales, chords, 
                progressions, and how they work together.
              </p>
              <p className="text-xs mt-2">
                Currently working with: <strong>{currentScale.name}</strong>
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {conversation.map((msg, index) => (
                <div key={index} className={`${msg.type === 'question' ? 'text-right' : 'text-left'}`}>
                  <div className={`inline-block p-3 rounded-lg max-w-[85%] ${
                    msg.type === 'question' 
                      ? 'bg-primary text-primary-foreground ml-auto' 
                      : 'bg-background border border-border'
                  }`}>
                    <div className="text-sm whitespace-pre-wrap">{msg.content}</div>
                    {msg.suggestions && msg.suggestions.length > 0 && (
                      <div className="mt-3 space-y-1">
                        <div className="text-xs text-muted-foreground flex items-center gap-1">
                          <Lightbulb className="h-3 w-3" />
                          Try asking:
                        </div>
                        {msg.suggestions.map((suggestion, i) => (
                          <Button
                            key={i}
                            variant="outline"
                            size="sm"
                            className="block w-full text-left text-xs h-auto py-1 px-2"
                            onClick={() => handleSuggestionClick(suggestion)}
                            data-testid={`button-suggestion-${i}`}
                          >
                            {suggestion}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {(askMutation.isPending || lessonMutation.isPending) && (
                <div className="text-left">
                  <div className="inline-block p-3 rounded-lg bg-background border border-border">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Bot className="h-4 w-4 animate-pulse" />
                      Thinking...
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </ScrollArea>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask about scales, chords, progressions..."
            disabled={askMutation.isPending || lessonMutation.isPending}
            className="flex-1"
            data-testid="input-question"
          />
          <Button 
            type="submit" 
            disabled={!question.trim() || askMutation.isPending || lessonMutation.isPending}
            data-testid="button-send-question"
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}