// Donation component using Stripe - based on javascript_stripe blueprint
import { useState, useEffect } from 'react';
import { useStripe, useElements, PaymentElement, Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Heart, Coffee, Pizza, Star } from 'lucide-react';

// Initialize Stripe outside of component to avoid recreation on renders
const stripePromise = import.meta.env.VITE_STRIPE_PUBLIC_KEY 
  ? loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY)
  : null;

interface DonateModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// Preset donation amounts
const donationAmounts = [
  { amount: 5, label: '☕ Buy me a coffee', icon: Coffee },
  { amount: 15, label: '🍕 Buy me a pizza', icon: Pizza },
  { amount: 25, label: '⭐ Super supporter', icon: Star },
  { amount: 50, label: '💎 Piano enthusiast', icon: Heart },
];

// Checkout form component
function CheckoutForm({ amount, onSuccess, onCancel }: { 
  amount: number; 
  onSuccess: () => void; 
  onCancel: () => void;
}) {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [processing, setProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setProcessing(true);

    try {
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        redirect: 'if_required',
        confirmParams: {
          return_url: window.location.origin,
        },
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      } else if (paymentIntent && paymentIntent.status === 'succeeded') {
        toast({
          title: "Thank You! 💙",
          description: "Your donation helps keep this piano app free for everyone!",
        });
        onSuccess();
      } else {
        toast({
          title: "Payment Processing",
          description: "Your payment is being processed. Thank you!",
        });
        onSuccess();
      }
    } catch (err) {
      toast({
        title: "Payment Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-center py-4">
        <div className="text-2xl font-semibold">${amount}</div>
        <div className="text-sm text-muted-foreground">Thank you for supporting this project!</div>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <PaymentElement />
        <div className="flex gap-2">
          <Button 
            type="button" 
            variant="outline" 
            onClick={onCancel}
            disabled={processing}
            className="flex-1"
          >
            Cancel
          </Button>
          <Button 
            type="submit" 
            disabled={!stripe || processing}
            className="flex-1"
            data-testid="donate-submit-button"
          >
            {processing ? 'Processing...' : `Donate $${amount}`}
          </Button>
        </div>
      </form>
    </div>
  );
}

// Main donation component
function DonationContent({ onClose }: { onClose: () => void }) {
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  const [clientSecret, setClientSecret] = useState('');
  const [showPayment, setShowPayment] = useState(false);
  const { toast } = useToast();

  // Check if Stripe is configured
  if (!stripePromise) {
    return (
      <div className="text-center space-y-4">
        <div className="text-lg font-semibold">Donation Feature Unavailable</div>
        <div className="text-sm text-muted-foreground">
          Stripe is not currently configured for this application.
        </div>
        <Button onClick={onClose} variant="outline">Close</Button>
      </div>
    );
  }

  const handleAmountSelect = async (amount: number) => {
    setSelectedAmount(amount);
    try {
      const response = await apiRequest("POST", "/api/create-payment-intent", { amount });
      const data = await response.json();
      setClientSecret(data.clientSecret);
      setShowPayment(true);
    } catch (error) {
      console.error('Error creating payment intent:', error);
      toast({
        title: "Error",
        description: "Failed to initialize payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleCustomAmount = async () => {
    const amount = parseFloat(customAmount);
    if (amount >= 1 && amount <= 1000) {
      await handleAmountSelect(amount);
    } else {
      toast({
        title: "Invalid Amount",
        description: "Please enter an amount between $1 and $1000.",
        variant: "destructive",
      });
    }
  };

  const handleSuccess = () => {
    setShowPayment(false);
    setSelectedAmount(null);
    setCustomAmount('');
    setClientSecret('');
    onClose();
  };

  const handleCancel = () => {
    setShowPayment(false);
    setSelectedAmount(null);
    setClientSecret('');
  };

  if (showPayment && clientSecret && selectedAmount) {
    const options = { clientSecret };
    return (
      <Elements stripe={stripePromise} options={options}>
        <CheckoutForm 
          amount={selectedAmount}
          onSuccess={handleSuccess}
          onCancel={handleCancel}
        />
      </Elements>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <div className="text-lg font-semibold">Support Your Mobile Piano Teacher 🎹</div>
        <div className="text-sm text-muted-foreground">
          Help keep this app free and support continued development!
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {donationAmounts.map(({ amount, label, icon: Icon }) => (
          <Button
            key={amount}
            variant="outline"
            onClick={() => handleAmountSelect(amount)}
            className="h-auto p-4 flex flex-col items-center gap-2 hover:bg-primary/5"
            data-testid={`donate-amount-${amount}`}
          >
            <Icon className="w-5 h-5" />
            <div className="font-semibold">${amount}</div>
            <div className="text-xs text-center">{label}</div>
          </Button>
        ))}
      </div>

      <div className="border-t pt-4 space-y-3">
        <div className="text-center text-sm font-medium">Custom Amount</div>
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">$</span>
            <input
              type="number"
              min="1"
              max="1000"
              step="0.01"
              placeholder="0.00"
              value={customAmount}
              onChange={(e) => setCustomAmount(e.target.value)}
              className="w-full pl-8 pr-3 py-2 border border-input rounded-md bg-background"
              data-testid="custom-amount-input"
            />
          </div>
          <Button 
            onClick={handleCustomAmount}
            disabled={!customAmount || parseFloat(customAmount) < 1 || parseFloat(customAmount) > 1000}
            data-testid="custom-amount-button"
          >
            Donate
          </Button>
        </div>
      </div>

      <div className="text-xs text-center text-muted-foreground">
        Powered by Stripe • Secure payments
      </div>
    </div>
  );
}

export function DonateModal({ open, onOpenChange }: DonateModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" data-testid="donate-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-500" />
            Donate
          </DialogTitle>
        </DialogHeader>
        <DonationContent onClose={() => onOpenChange(false)} />
      </DialogContent>
    </Dialog>
  );
}