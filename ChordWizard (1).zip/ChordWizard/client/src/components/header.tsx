import { Piano, Save, FolderOpen, Moon, Sun, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/hooks/use-theme';

interface HeaderProps {
  onSave: () => void;
  onLoad: () => void;
  onDonate?: () => void;
}

export function Header({ onSave, onLoad, onDonate }: HeaderProps) {
  const { isDark, toggleTheme } = useTheme();

  return (
    <header className="bg-gradient-to-r from-card via-card to-card border-b border-border sticky top-0 z-50 backdrop-blur-sm bg-card/80 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-18">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Piano className="text-3xl text-primary drop-shadow-lg" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full animate-pulse"></div>
              </div>
              <h1 className="text-xl font-bold text-foreground bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Your Mobile Piano Teacher</h1>
            </div>
          </div>
          <div className="flex items-center space-x-2 sm:space-x-4">
            {onDonate && (
              <Button
                onClick={onDonate}
                variant="outline"
                size="sm"
                className="text-red-500 border-red-200 hover:bg-red-50 dark:hover:bg-red-950 hidden sm:flex"
                data-testid="button-donate"
              >
                <Heart className="mr-1 sm:mr-2 h-3 w-3 sm:h-4 sm:w-4 fill-current" />
                <span className="text-xs sm:text-sm">Donate</span>
              </Button>
            )}
            <Button
              onClick={onSave}
              variant="secondary"
              size="sm"
              data-testid="button-save-progression"
              className="text-xs sm:text-sm"
            >
              <Save className="mr-1 sm:mr-2 h-3 w-3 sm:h-4 sm:w-4" />
              <span className="hidden sm:inline">Save</span>
            </Button>
            <Button
              onClick={onLoad}
              variant="secondary"
              size="sm"
              data-testid="button-load-progression"
              className="text-xs sm:text-sm"
            >
              <FolderOpen className="mr-1 sm:mr-2 h-3 w-3 sm:h-4 sm:w-4" />
              <span className="hidden sm:inline">Load</span>
            </Button>
            <Button
              onClick={toggleTheme}
              variant="secondary"
              size="icon"
              className="h-8 w-8 sm:h-10 sm:w-10"
              data-testid="button-toggle-theme"
            >
              {isDark ? <Sun className="h-3 w-3 sm:h-4 sm:w-4" /> : <Moon className="h-3 w-3 sm:h-4 sm:w-4" />}
            </Button>
            {onDonate && (
              <Button
                onClick={onDonate}
                variant="outline"
                size="icon"
                className="text-red-500 border-red-200 hover:bg-red-50 dark:hover:bg-red-950 sm:hidden h-8 w-8"
                data-testid="button-donate-mobile"
              >
                <Heart className="h-3 w-3 fill-current" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
