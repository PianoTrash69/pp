import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Chord } from '@/lib/music-theory';
import { Share2, Copy, Twitter, Facebook, Link2, Music } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ShareProgressionProps {
  progression: Chord[];
  tempo: number;
  scale: string;
  progressionName?: string;
  className?: string;
}

interface ProgressionData {
  chords: string[];
  tempo: number;
  scale: string;
  name?: string;
}

export function ShareProgression({ 
  progression, 
  tempo, 
  scale, 
  progressionName = '',
  className 
}: ShareProgressionProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [shareUrl, setShareUrl] = useState('');
  const { toast } = useToast();

  const encodeProgressionData = useCallback((data: ProgressionData): string => {
    const compressed = {
      c: data.chords,
      t: data.tempo,
      s: data.scale,
      ...(data.name && { n: data.name })
    };
    return btoa(JSON.stringify(compressed));
  }, []);

  const decodeProgressionData = useCallback((encoded: string): ProgressionData | null => {
    try {
      const compressed = JSON.parse(atob(encoded));
      return {
        chords: compressed.c || [],
        tempo: compressed.t || 120,
        scale: compressed.s || 'C-major',
        name: compressed.n
      };
    } catch (error) {
      console.error('Failed to decode progression data:', error);
      return null;
    }
  }, []);

  const generateShareUrl = useCallback(() => {
    if (progression.length === 0) {
      toast({
        title: "No Progression to Share",
        description: "Please add some chords to your progression first.",
        variant: "destructive"
      });
      return '';
    }

    const progressionData: ProgressionData = {
      chords: progression.map(chord => chord.name),
      tempo,
      scale,
      name: progressionName || undefined
    };

    const encoded = encodeProgressionData(progressionData);
    const baseUrl = window.location.origin + window.location.pathname;
    const url = `${baseUrl}?progression=${encodeURIComponent(encoded)}`;
    setShareUrl(url);
    return url;
  }, [progression, tempo, scale, progressionName, encodeProgressionData, toast]);

  const copyToClipboard = useCallback(async () => {
    const url = shareUrl || generateShareUrl();
    if (!url) return;

    try {
      await navigator.clipboard.writeText(url);
      toast({
        title: "Link Copied!",
        description: "The progression link has been copied to your clipboard.",
      });
    } catch (error) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = url;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      
      toast({
        title: "Link Copied!",
        description: "The progression link has been copied to your clipboard.",
      });
    }
  }, [shareUrl, generateShareUrl, toast]);

  const shareOnTwitter = useCallback(() => {
    const url = shareUrl || generateShareUrl();
    if (!url) return;

    const chordNames = progression.map(c => c.name).join(' - ');
    const text = `Check out this ${chordNames} chord progression I created! 🎵 Tempo: ${tempo} BPM in ${scale}`;
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
    window.open(twitterUrl, '_blank', 'width=600,height=400');
  }, [shareUrl, generateShareUrl, progression, tempo, scale]);

  const shareOnFacebook = useCallback(() => {
    const url = shareUrl || generateShareUrl();
    if (!url) return;

    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
    window.open(facebookUrl, '_blank', 'width=600,height=400');
  }, [shareUrl, generateShareUrl]);

  const handleDialogOpen = useCallback(() => {
    setIsOpen(true);
    generateShareUrl();
  }, [generateShareUrl]);

  if (progression.length === 0) {
    return null;
  }

  const chordNames = progression.map(c => c.name).join(' - ');

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          onClick={handleDialogOpen}
          className={cn("share-progression", className)}
          data-testid="button-share-progression"
        >
          <Share2 className="mr-2 h-4 w-4" />
          Share
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Music className="h-5 w-5 text-primary" />
            <span>Share Your Progression</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Progression Preview */}
          <div className="bg-muted p-4 rounded-lg">
            <div className="text-sm text-muted-foreground mb-1">Progression:</div>
            <div className="font-mono text-lg">{chordNames}</div>
            <div className="text-sm text-muted-foreground mt-1">
              {tempo} BPM • {scale}
              {progressionName && ` • "${progressionName}"`}
            </div>
          </div>

          {/* Share URL */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Share Link</label>
            <div className="flex space-x-2">
              <Input
                value={shareUrl}
                readOnly
                className="font-mono text-xs"
                data-testid="input-share-url"
              />
              <Button
                onClick={copyToClipboard}
                variant="outline"
                size="sm"
                data-testid="button-copy-link"
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Social Media Buttons */}
          <div className="space-y-3">
            <label className="text-sm font-medium">Share on Social Media</label>
            <div className="flex space-x-2">
              <Button
                onClick={shareOnTwitter}
                variant="outline"
                className="flex-1"
                data-testid="button-share-twitter"
              >
                <Twitter className="mr-2 h-4 w-4" />
                Twitter
              </Button>
              <Button
                onClick={shareOnFacebook}
                variant="outline" 
                className="flex-1"
                data-testid="button-share-facebook"
              >
                <Facebook className="mr-2 h-4 w-4" />
                Facebook
              </Button>
            </div>
          </div>

          {/* Quick Copy Button */}
          <Button
            onClick={copyToClipboard}
            className="w-full"
            data-testid="button-copy-full"
          >
            <Link2 className="mr-2 h-4 w-4" />
            Copy Link to Share
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Export decode function for use in URL loading
export { ShareProgression as default };
export type { ProgressionData };