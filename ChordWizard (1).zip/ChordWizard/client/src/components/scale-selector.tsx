import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Scale, getAllScales } from '@/lib/music-theory';

interface ScaleSelectorProps {
  selectedScale: string;
  onScaleChange: (scale: string) => void;
  currentScale: Scale | null;
}

export function ScaleSelector({ selectedScale, onScaleChange, currentScale }: ScaleSelectorProps) {
  const allScales = getAllScales();
  
  // Group scales by root note, maintaining dissonance order within each group
  const scaleGroups = allScales.reduce((groups, scale) => {
    const groupName = scale.root;
    
    if (!groups[groupName]) groups[groupName] = [];
    groups[groupName].push(scale);
    return groups;
  }, {} as Record<string, typeof allScales>);

  // Sort groups by chromatic order (C, C#, D, D#, E, F, F#, G, G#, A, A#, B)
  const chromaticOrder = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const sortedGroupEntries = Object.entries(scaleGroups).sort(([a], [b]) => 
    chromaticOrder.indexOf(a) - chromaticOrder.indexOf(b)
  );

  return (
    <div className="bg-card rounded-xl p-4 border border-border shadow-sm">
      <h3 className="text-lg font-semibold text-card-foreground mb-3">Musical Scale</h3>
      <Select value={selectedScale} onValueChange={onScaleChange}>
        <SelectTrigger className="w-full text-base" data-testid="select-scale">
          <SelectValue />
        </SelectTrigger>
        <SelectContent className="max-h-96 overflow-y-auto">
          {sortedGroupEntries.map(([groupName, scales]) => (
            <div key={groupName}>
              <div className="px-2 py-1 text-xs font-semibold text-muted-foreground bg-muted/50 sticky top-0">
                {groupName}
              </div>
              {scales.map((scale) => (
                <SelectItem key={scale.value} value={scale.value}>
                  {scale.label}
                </SelectItem>
              ))}
            </div>
          ))}
        </SelectContent>
      </Select>
      
      {currentScale && (
        <div className="mt-3 p-3 bg-muted rounded-lg">
          <h4 className="text-sm font-medium text-muted-foreground mb-2">Scale Notes:</h4>
          <div className="flex flex-wrap gap-1" data-testid="scale-notes">
            {currentScale.notes.map((note, index) => (
              <Badge key={index} variant="default" className="text-xs">
                {note}
              </Badge>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
