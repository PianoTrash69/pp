import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Palette, Eye, Download, Upload, RotateCcw } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface ColorPalette {
  name: string;
  description: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    foreground: string;
    card: string;
    cardForeground: string;
    muted: string;
    mutedForeground: string;
    border: string;
  };
}

interface Theme {
  id: string;
  name: string;
  description: string;
  palette: ColorPalette;
  customCSS?: string;
}

const defaultPalettes: ColorPalette[] = [
  {
    name: "Classic Blue",
    description: "Professional blue theme with high contrast",
    colors: {
      primary: "220 90% 50%",
      secondary: "220 30% 95%", 
      accent: "220 90% 95%",
      background: "0 0% 100%",
      foreground: "220 90% 9%",
      card: "0 0% 100%",
      cardForeground: "220 90% 9%",
      muted: "220 30% 95%",
      mutedForeground: "220 30% 40%",
      border: "220 30% 82%"
    }
  },
  {
    name: "Warm Sunset",
    description: "Warm orange and red tones for a creative feel",
    colors: {
      primary: "25 95% 53%",
      secondary: "25 30% 95%",
      accent: "25 95% 95%", 
      background: "0 0% 100%",
      foreground: "25 95% 9%",
      card: "0 0% 100%",
      cardForeground: "25 95% 9%",
      muted: "25 30% 95%",
      mutedForeground: "25 30% 40%",
      border: "25 30% 82%"
    }
  },
  {
    name: "Forest Green",
    description: "Natural green palette for a calming experience",
    colors: {
      primary: "142 70% 45%", 
      secondary: "142 30% 95%",
      accent: "142 70% 95%",
      background: "0 0% 100%",
      foreground: "142 70% 9%",
      card: "0 0% 100%",
      cardForeground: "142 70% 9%",
      muted: "142 30% 95%",
      mutedForeground: "142 30% 40%",
      border: "142 30% 82%"
    }
  },
  {
    name: "Purple Dream",
    description: "Rich purple theme for a luxurious feel",
    colors: {
      primary: "271 81% 56%",
      secondary: "271 30% 95%",
      accent: "271 81% 95%",
      background: "0 0% 100%",
      foreground: "271 81% 9%", 
      card: "0 0% 100%",
      cardForeground: "271 81% 9%",
      muted: "271 30% 95%",
      mutedForeground: "271 30% 40%",
      border: "271 30% 82%"
    }
  },
  {
    name: "Dark Mode",
    description: "Easy on the eyes dark theme",
    colors: {
      primary: "220 90% 50%",
      secondary: "217 33% 17%",
      accent: "217 33% 17%",
      background: "224 71% 4%",
      foreground: "213 31% 91%",
      card: "224 71% 4%",
      cardForeground: "213 31% 91%",
      muted: "223 47% 11%",
      mutedForeground: "215 20% 65%",
      border: "216 34% 17%"
    }
  }
];

interface ThemeCustomizerProps {
  className?: string;
}

export function ThemeCustomizer({ className }: ThemeCustomizerProps) {
  const [currentTheme, setCurrentTheme] = useState<Theme | null>(null);
  const [selectedPalette, setSelectedPalette] = useState<ColorPalette>(defaultPalettes[0]);
  const [customColors, setCustomColors] = useState(defaultPalettes[0].colors);
  const [previewMode, setPreviewMode] = useState(false);
  const [savedThemes, setSavedThemes] = useState<Theme[]>([]);
  const { toast } = useToast();

  // Load saved themes from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('customThemes');
    if (saved) {
      try {
        setSavedThemes(JSON.parse(saved));
      } catch (error) {
        console.error('Failed to load saved themes:', error);
      }
    }
  }, []);

  // Load current theme from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('currentTheme');
    if (savedTheme) {
      try {
        const theme = JSON.parse(savedTheme);
        setCurrentTheme(theme);
        setSelectedPalette(theme.palette);
        setCustomColors(theme.palette.colors);
      } catch (error) {
        console.error('Failed to load current theme:', error);
      }
    }
  }, []);

  const applyTheme = (theme: Theme) => {
    const root = document.documentElement;
    
    Object.entries(theme.palette.colors).forEach(([key, value]) => {
      const cssVar = `--${key.replace(/([A-Z])/g, '-$1').toLowerCase()}`;
      root.style.setProperty(cssVar, value);
    });

    // Store theme
    localStorage.setItem('currentTheme', JSON.stringify(theme));
    setCurrentTheme(theme);
    
    toast({
      title: "Theme Applied!",
      description: `${theme.name} theme is now active.`,
    });
  };

  const previewTheme = (palette: ColorPalette) => {
    if (!previewMode) return;
    
    const root = document.documentElement;
    Object.entries(palette.colors).forEach(([key, value]) => {
      const cssVar = `--${key.replace(/([A-Z])/g, '-$1').toLowerCase()}`;
      root.style.setProperty(cssVar, value);
    });
  };

  const stopPreview = () => {
    if (currentTheme) {
      applyTheme(currentTheme);
    }
    setPreviewMode(false);
  };

  const saveTheme = () => {
    const theme: Theme = {
      id: `custom-${Date.now()}`,
      name: `Custom Theme ${savedThemes.length + 1}`,
      description: "User created custom theme",
      palette: {
        name: "Custom",
        description: "Custom color palette",
        colors: customColors
      }
    };

    const newThemes = [...savedThemes, theme];
    setSavedThemes(newThemes);
    localStorage.setItem('customThemes', JSON.stringify(newThemes));
    
    toast({
      title: "Theme Saved!",
      description: "Your custom theme has been saved.",
    });
  };

  const exportTheme = () => {
    if (!currentTheme) return;
    
    const dataStr = JSON.stringify(currentTheme, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `${currentTheme.name.replace(/\s+/g, '-').toLowerCase()}-theme.json`;
    link.click();
    
    URL.revokeObjectURL(url);
    
    toast({
      title: "Theme Exported!",
      description: "Theme file has been downloaded.",
    });
  };

  const resetToDefault = () => {
    const defaultTheme: Theme = {
      id: 'default',
      name: 'Default',
      description: 'Default application theme',
      palette: defaultPalettes[0]
    };
    
    applyTheme(defaultTheme);
    setSelectedPalette(defaultPalettes[0]);
    setCustomColors(defaultPalettes[0].colors);
  };

  const updateCustomColor = (colorKey: string, value: string) => {
    const newColors = { ...customColors, [colorKey]: value };
    setCustomColors(newColors);
    
    if (previewMode) {
      const tempPalette = { ...selectedPalette, colors: newColors };
      previewTheme(tempPalette);
    }
  };

  return (
    <Card className={cn("theme-customizer", className)}>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Palette className="h-5 w-5 text-primary" />
          <span>Theme Customizer</span>
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Customize the look and feel of your music teacher app
        </p>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="presets" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="presets">Presets</TabsTrigger>
            <TabsTrigger value="custom">Custom</TabsTrigger>
            <TabsTrigger value="saved">Saved</TabsTrigger>
          </TabsList>

          <TabsContent value="presets" className="space-y-4">
            <div className="space-y-3">
              <Label>Choose a preset theme</Label>
              <div className="grid grid-cols-1 gap-3">
                {defaultPalettes.map((palette, index) => (
                  <div
                    key={index}
                    className={cn(
                      "p-3 rounded-lg border cursor-pointer transition-colors",
                      selectedPalette === palette 
                        ? "border-primary bg-primary/5" 
                        : "border-border hover:border-primary/50"
                    )}
                    onClick={() => {
                      setSelectedPalette(palette);
                      setCustomColors(palette.colors);
                    }}
                    data-testid={`theme-preset-${palette.name.replace(/\s+/g, '-').toLowerCase()}`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{palette.name}</h4>
                      <div className="flex space-x-1">
                        {Object.values(palette.colors).slice(0, 4).map((color, colorIndex) => (
                          <div
                            key={colorIndex}
                            className="w-4 h-4 rounded-full border"
                            style={{ backgroundColor: `hsl(${color})` }}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">{palette.description}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex space-x-2">
              <Button
                onClick={() => {
                  const theme: Theme = {
                    id: selectedPalette.name.toLowerCase().replace(/\s+/g, '-'),
                    name: selectedPalette.name,
                    description: selectedPalette.description,
                    palette: selectedPalette
                  };
                  applyTheme(theme);
                }}
                data-testid="apply-preset-theme"
              >
                Apply Theme
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setPreviewMode(!previewMode);
                  if (!previewMode) {
                    previewTheme(selectedPalette);
                  } else {
                    stopPreview();
                  }
                }}
                data-testid="preview-theme"
              >
                <Eye className="h-4 w-4 mr-2" />
                {previewMode ? 'Stop Preview' : 'Preview'}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="custom" className="space-y-4">
            <div className="space-y-4">
              <Label>Customize individual colors</Label>
              
              {Object.entries(customColors).map(([key, value]) => (
                <div key={key} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="capitalize">
                      {key.replace(/([A-Z])/g, ' $1').trim()}
                    </Label>
                    <div
                      className="w-8 h-8 rounded border"
                      style={{ backgroundColor: `hsl(${value})` }}
                    />
                  </div>
                  <input
                    type="text"
                    value={value}
                    onChange={(e) => updateCustomColor(key, e.target.value)}
                    className="w-full px-3 py-2 border rounded-md text-sm font-mono"
                    placeholder="e.g., 220 90% 50%"
                    data-testid={`color-input-${key}`}
                  />
                </div>
              ))}
            </div>

            <div className="flex space-x-2">
              <Button
                onClick={() => {
                  const theme: Theme = {
                    id: 'custom-current',
                    name: 'Custom Theme',
                    description: 'User customized theme',
                    palette: {
                      name: 'Custom',
                      description: 'Custom colors',
                      colors: customColors
                    }
                  };
                  applyTheme(theme);
                }}
                data-testid="apply-custom-theme"
              >
                Apply Custom
              </Button>
              <Button variant="outline" onClick={saveTheme}>
                Save Theme
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setPreviewMode(!previewMode);
                  if (!previewMode) {
                    const tempPalette = { ...selectedPalette, colors: customColors };
                    previewTheme(tempPalette);
                  } else {
                    stopPreview();
                  }
                }}
              >
                <Eye className="h-4 w-4 mr-2" />
                {previewMode ? 'Stop Preview' : 'Preview'}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="saved" className="space-y-4">
            {savedThemes.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                <Palette className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No saved themes yet</p>
                <p className="text-sm mt-2">Create and save custom themes in the Custom tab</p>
              </div>
            ) : (
              <div className="space-y-3">
                {savedThemes.map((theme) => (
                  <div
                    key={theme.id}
                    className="p-3 rounded-lg border hover:border-primary/50 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{theme.name}</h4>
                      <div className="flex space-x-1">
                        <Button
                          size="sm"
                          onClick={() => applyTheme(theme)}
                          data-testid={`apply-saved-theme-${theme.id}`}
                        >
                          Apply
                        </Button>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">{theme.description}</p>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        <div className="mt-6 pt-4 border-t border-border">
          <div className="flex space-x-2">
            <Button variant="outline" onClick={resetToDefault} data-testid="reset-theme">
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset to Default
            </Button>
            <Button variant="outline" onClick={exportTheme} disabled={!currentTheme}>
              <Download className="h-4 w-4 mr-2" />
              Export Theme
            </Button>
          </div>
          
          {currentTheme && (
            <div className="mt-3 p-2 bg-muted rounded text-sm">
              <strong>Current:</strong> {currentTheme.name}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}