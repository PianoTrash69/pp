import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Music, Play, RotateCcw, Lightbulb, Clock, Star } from 'lucide-react';
import { getChordOfTheDay, getRandomChord, type ChordOfTheDay } from '@/lib/chord-of-the-day';
import { cn } from '@/lib/utils';

interface ChordOfTheDayProps {
  onPlayChord?: (notes: string[]) => void;
  className?: string;
}

export function ChordOfTheDayComponent({ onPlayChord, className }: ChordOfTheDayProps) {
  const [currentChord, setCurrentChord] = useState<ChordOfTheDay>(() => getChordOfTheDay());
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlayChord = async () => {
    if (onPlayChord && !isPlaying) {
      setIsPlaying(true);
      try {
        await onPlayChord(currentChord.notes);
      } catch (error) {
        console.error('Error playing chord:', error);
      } finally {
        setTimeout(() => setIsPlaying(false), 1000);
      }
    }
  };

  const handleNewChord = () => {
    setCurrentChord(getRandomChord());
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'Advanced': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  return (
    <Card className={cn("chord-of-the-day", className)}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Music className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">Chord of the Day</CardTitle>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleNewChord}
            className="h-8 w-8 p-0"
            data-testid="button-new-chord"
            title="Get new random chord"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Chord Header */}
        <div className="text-center space-y-2">
          <div className="space-y-1">
            <h3 className="text-2xl font-bold text-foreground" data-testid="chord-name">
              {currentChord.name}
            </h3>
            <div className="text-lg text-muted-foreground font-mono">
              {currentChord.symbol}
            </div>
          </div>
          
          <div className="flex justify-center items-center space-x-2 flex-wrap">
            <Badge className={getDifficultyColor(currentChord.difficulty)}>
              {currentChord.difficulty}
            </Badge>
            <Badge variant="outline">{currentChord.quality}</Badge>
          </div>
        </div>

        {/* Notes and Play Button */}
        <div className="text-center space-y-3">
          <div className="space-y-1">
            <div className="text-sm font-medium text-muted-foreground">Notes:</div>
            <div className="text-lg font-mono font-semibold" data-testid="chord-notes">
              {currentChord.notes.join(' - ')}
            </div>
          </div>
          
          <Button
            onClick={handlePlayChord}
            disabled={isPlaying}
            variant="default"
            className="w-full"
            data-testid="button-play-chord"
          >
            <Play className={cn("h-4 w-4 mr-2", isPlaying && "animate-pulse")} />
            {isPlaying ? 'Playing...' : 'Play Chord'}
          </Button>
        </div>

        <Separator />

        {/* Intervals */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Star className="h-4 w-4 text-muted-foreground" />
            <div className="text-sm font-medium">Intervals:</div>
          </div>
          <div className="text-sm text-muted-foreground">
            {currentChord.intervals.join(', ')}
          </div>
        </div>

        {/* Mood */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Lightbulb className="h-4 w-4 text-muted-foreground" />
            <div className="text-sm font-medium">Mood & Character:</div>
          </div>
          <div className="text-sm text-muted-foreground italic">
            {currentChord.mood}
          </div>
        </div>

        <Separator />

        {/* History */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <div className="text-sm font-medium">History:</div>
          </div>
          <div className="text-sm text-muted-foreground leading-relaxed">
            {currentChord.history}
          </div>
        </div>

        {/* Musical Properties */}
        <div className="space-y-2">
          <div className="text-sm font-medium">Musical Properties:</div>
          <div className="text-sm text-muted-foreground leading-relaxed">
            {currentChord.musicalProperties}
          </div>
        </div>

        {/* Famous Uses */}
        {currentChord.famousUses.length > 0 && (
          <div className="space-y-2">
            <div className="text-sm font-medium">Famous Examples:</div>
            <ul className="text-sm text-muted-foreground space-y-1">
              {currentChord.famousUses.map((use, index) => (
                <li key={index} className="flex items-start space-x-2">
                  <span className="text-primary">•</span>
                  <span>{use}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Fun Facts */}
        {currentChord.funFacts.length > 0 && (
          <div className="space-y-2">
            <div className="text-sm font-medium">Fun Facts:</div>
            <ul className="text-sm text-muted-foreground space-y-1">
              {currentChord.funFacts.map((fact, index) => (
                <li key={index} className="flex items-start space-x-2">
                  <span className="text-primary">💡</span>
                  <span>{fact}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}