import { useState, useCallback, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Play, Music } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Chord } from '@/lib/music-theory';

interface ChordVoicing {
  name: string;
  description: string;
  notes: Array<{ note: string; octave: number }>;
  type: 'root' | 'first' | 'second' | 'third' | 'spread' | 'close' | 'open' | 'drop2' | 'drop3';
}

interface ChordVoicingExplorerProps {
  selectedChord?: Chord | null;
  onPlayVoicing?: (notes: Array<{ note: string; octave: number }>) => void;
  className?: string;
}

export function ChordVoicingExplorer({ 
  selectedChord, 
  onPlayVoicing,
  className 
}: ChordVoicingExplorerProps) {
  const [selectedVoicing, setSelectedVoicing] = useState<ChordVoicing | null>(null);
  const [octaveRange, setOctaveRange] = useState<'2-4' | '3-5' | '4-6' | '5-7'>('3-5');

  // Generate chord voicings for the selected chord
  const voicings = useMemo(() => {
    if (!selectedChord) return [];

    const baseOctave = parseInt(octaveRange.split('-')[0]);
    const maxOctave = parseInt(octaveRange.split('-')[1]);
    
    // Get chord notes (remove octave information)
    const chordNotes = selectedChord.notes.map(note => note.replace(/\d+$/, ''));
    
    const voicingList: ChordVoicing[] = [];

    // Root position voicing (close)
    voicingList.push({
      name: 'Root Position (Close)',
      description: 'Basic chord with root in bass, notes stacked closely',
      notes: chordNotes.map((note, index) => ({
        note,
        octave: baseOctave + Math.floor(index / 4) // Spread across octaves when needed
      })),
      type: 'root'
    });

    // First inversion
    if (chordNotes.length >= 3) {
      const inverted = [chordNotes[1], chordNotes[2], ...chordNotes.slice(3), chordNotes[0]];
      voicingList.push({
        name: 'First Inversion',
        description: 'Third in bass, creates a different harmonic color',
        notes: inverted.map((note, index) => ({
          note,
          octave: baseOctave + Math.floor(index / 4)
        })),
        type: 'first'
      });
    }

    // Second inversion
    if (chordNotes.length >= 3) {
      const inverted = [chordNotes[2], ...chordNotes.slice(3), chordNotes[0], chordNotes[1]];
      voicingList.push({
        name: 'Second Inversion',
        description: 'Fifth in bass, often used for smooth voice leading',
        notes: inverted.map((note, index) => ({
          note,
          octave: baseOctave + Math.floor(index / 4)
        })),
        type: 'second'
      });
    }

    // Third inversion (for 7th chords)
    if (chordNotes.length >= 4) {
      const inverted = [chordNotes[3], chordNotes[0], chordNotes[1], chordNotes[2]];
      voicingList.push({
        name: 'Third Inversion',
        description: 'Seventh in bass, creates tension and forward motion',
        notes: inverted.map((note, index) => ({
          note,
          octave: baseOctave + Math.floor(index / 4)
        })),
        type: 'third'
      });
    }

    // Open voicing (spread out)
    voicingList.push({
      name: 'Open Voicing',
      description: 'Notes spread across multiple octaves for fuller sound',
      notes: chordNotes.map((note, index) => ({
        note,
        octave: baseOctave + Math.floor(index / 2) + (index % 2) // Alternate octaves
      })),
      type: 'open'
    });

    // Drop 2 voicing (for 4+ note chords)
    if (chordNotes.length >= 4) {
      const drop2Notes = [
        { note: chordNotes[0], octave: baseOctave },     // Root
        { note: chordNotes[2], octave: baseOctave },     // Fifth (dropped)
        { note: chordNotes[1], octave: baseOctave + 1 }, // Third
        { note: chordNotes[3], octave: baseOctave + 1 }  // Seventh
      ];
      voicingList.push({
        name: 'Drop 2',
        description: 'Second highest note dropped an octave, jazz standard',
        notes: drop2Notes,
        type: 'drop2'
      });
    }

    // Drop 3 voicing (for 4+ note chords)
    if (chordNotes.length >= 4) {
      const drop3Notes = [
        { note: chordNotes[0], octave: baseOctave },     // Root
        { note: chordNotes[1], octave: baseOctave },     // Third (dropped)
        { note: chordNotes[2], octave: baseOctave + 1 }, // Fifth
        { note: chordNotes[3], octave: baseOctave + 1 }  // Seventh
      ];
      voicingList.push({
        name: 'Drop 3',
        description: 'Third highest note dropped an octave, alternative jazz voicing',
        notes: drop3Notes,
        type: 'drop3'
      });
    }

    // Bass + melody voicing
    voicingList.push({
      name: 'Bass + Melody',
      description: 'Root in bass with melody note on top',
      notes: [
        { note: chordNotes[0], octave: baseOctave - 1 }, // Bass root
        ...chordNotes.slice(1).map((note, index) => ({
          note,
          octave: baseOctave + 1 + Math.floor(index / 3)
        }))
      ],
      type: 'spread'
    });

    return voicingList;
  }, [selectedChord, octaveRange]);

  const handlePlayVoicing = useCallback((voicing: ChordVoicing) => {
    if (onPlayVoicing) {
      onPlayVoicing(voicing.notes);
    }
    setSelectedVoicing(voicing);
  }, [onPlayVoicing]);

  const getVoicingTypeColor = (type: ChordVoicing['type']) => {
    const colors = {
      root: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      first: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      second: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
      third: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
      spread: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
      close: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200',
      open: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
      drop2: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
      drop3: 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200'
    };
    return colors[type] || colors.close;
  };

  if (!selectedChord) {
    return (
      <Card className={cn("chord-voicing-explorer", className)}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Music className="h-5 w-5 text-primary" />
            <span>Chord Voicing Explorer</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-8">
            <Music className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>Select a chord to explore different voicings</p>
            <p className="text-sm mt-2">Click on any chord in the Chord Library to see its voicings</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn("chord-voicing-explorer", className)}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Music className="h-5 w-5 text-primary" />
            <span>Chord Voicing Explorer</span>
          </CardTitle>
          <Select value={octaveRange} onValueChange={(value) => setOctaveRange(value as any)}>
            <SelectTrigger className="w-20" data-testid="select-octave-range">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2-4">2-4</SelectItem>
              <SelectItem value="3-5">3-5</SelectItem>
              <SelectItem value="4-6">4-6</SelectItem>
              <SelectItem value="5-7">5-7</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="text-sm text-muted-foreground">
          Exploring voicings for <span className="font-semibold text-foreground">{selectedChord.name}</span>
        </div>
      </CardHeader>

      <CardContent>
        <ScrollArea className="h-80">
          <div className="space-y-3">
            {voicings.map((voicing, index) => (
              <div
                key={index}
                className={cn(
                  "p-4 rounded-lg border transition-colors cursor-pointer",
                  selectedVoicing === voicing 
                    ? "border-primary bg-primary/5" 
                    : "border-border hover:border-primary/50 hover:bg-muted/50"
                )}
                onClick={() => setSelectedVoicing(voicing)}
                data-testid={`voicing-${voicing.type}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <h4 className="font-medium">{voicing.name}</h4>
                    <Badge className={getVoicingTypeColor(voicing.type)}>
                      {voicing.type}
                    </Badge>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePlayVoicing(voicing);
                    }}
                    data-testid={`play-voicing-${voicing.type}`}
                  >
                    <Play className="h-3 w-3" />
                  </Button>
                </div>
                
                <p className="text-sm text-muted-foreground mb-3">
                  {voicing.description}
                </p>
                
                <div className="flex flex-wrap gap-2">
                  {voicing.notes.map((note, noteIndex) => (
                    <div
                      key={noteIndex}
                      className="px-2 py-1 bg-secondary text-secondary-foreground rounded text-xs font-mono"
                      data-testid={`note-${note.note}${note.octave}`}
                    >
                      {note.note}{note.octave}
                    </div>
                  ))}
                </div>
                
                {selectedVoicing === voicing && (
                  <div className="mt-3 pt-3 border-t border-border">
                    <div className="text-xs text-muted-foreground">
                      <strong>Notes:</strong> {voicing.notes.map(n => `${n.note}${n.octave}`).join(' - ')}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>
        
        {selectedVoicing && (
          <div className="mt-4 p-3 bg-muted rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">{selectedVoicing.name}</h4>
                <p className="text-sm text-muted-foreground">
                  {selectedVoicing.notes.length} notes • {selectedVoicing.description}
                </p>
              </div>
              <Button
                onClick={() => handlePlayVoicing(selectedVoicing)}
                data-testid="play-selected-voicing"
              >
                <Play className="h-4 w-4 mr-2" />
                Play
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}