import { useState, useEffect, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Play, Pause, Volume2, VolumeX } from 'lucide-react';
import { cn } from '@/lib/utils';
import * as Tone from 'tone';

interface MetronomeProps {
  className?: string;
}

type MetronomeSound = 'classic' | 'woodblock' | 'beep' | 'mute';

export function Metronome({ className }: MetronomeProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [bpm, setBpm] = useState(120); // Default to 120 BPM (Moderato)
  const [currentBeat, setCurrentBeat] = useState(0);
  const [sound, setSound] = useState<MetronomeSound>('classic');
  const [mutedBeats, setMutedBeats] = useState<Set<number>>(new Set());
  
  // Audio setup
  const synthRef = useRef<Tone.Synth | null>(null);
  const woodblockRef = useRef<Tone.NoiseSynth | null>(null);
  const intervalRef = useRef<number | null>(null);
  const lastBeatTimeRef = useRef<number>(0);

  // Initialize audio on first play
  const initializeAudio = useCallback(async () => {
    if (Tone.context.state !== 'running') {
      await Tone.start();
    }

    if (!synthRef.current) {
      synthRef.current = new Tone.Synth({
        oscillator: { type: 'square' },
        envelope: { attack: 0.01, decay: 0.1, sustain: 0, release: 0.1 }
      }).toDestination();
    }

    if (!woodblockRef.current) {
      woodblockRef.current = new Tone.NoiseSynth({
        noise: { type: 'brown' },
        envelope: { attack: 0.001, decay: 0.2, sustain: 0, release: 0.1 }
      }).toDestination();
    }
  }, []);

  const playClick = useCallback((beat: number) => {
    if (sound === 'mute' || mutedBeats.has(beat)) return;

    const isDownbeat = beat === 1;

    switch (sound) {
      case 'classic':
        if (synthRef.current) {
          const frequency = isDownbeat ? 800 : 600;
          synthRef.current.triggerAttackRelease(frequency, '32n');
        }
        break;
      case 'woodblock':
        if (woodblockRef.current) {
          const volume = isDownbeat ? 0.8 : 0.6;
          woodblockRef.current.volume.value = Tone.gainToDb(volume);
          woodblockRef.current.triggerAttackRelease('32n');
        }
        break;
      case 'beep':
        if (synthRef.current) {
          const frequency = isDownbeat ? 1000 : 800;
          synthRef.current.triggerAttackRelease(frequency, '16n');
        }
        break;
    }
  }, [sound, mutedBeats]);

  const startMetronome = useCallback(async () => {
    try {
      await initializeAudio();
      
      const interval = 60000 / bpm; // ms per beat
      let beat = 1;
      
      setCurrentBeat(beat);
      playClick(beat);
      lastBeatTimeRef.current = Date.now();
      
      const tick = () => {
        const now = Date.now();
        const expectedTime = lastBeatTimeRef.current + interval;
        
        // Adjust for timing drift
        const drift = now - expectedTime;
        const nextInterval = Math.max(10, interval - drift);
        
        beat = beat >= 4 ? 1 : beat + 1;
        setCurrentBeat(beat);
        playClick(beat);
        lastBeatTimeRef.current = expectedTime;
        
        intervalRef.current = window.setTimeout(tick, nextInterval);
      };
      
      intervalRef.current = window.setTimeout(tick, interval);
      setIsPlaying(true);
    } catch (error) {
      console.error('Error starting metronome:', error);
    }
  }, [bpm, playClick, initializeAudio]);

  const stopMetronome = useCallback(() => {
    if (intervalRef.current) {
      clearTimeout(intervalRef.current);
      intervalRef.current = null;
    }
    setIsPlaying(false);
    setCurrentBeat(0);
  }, []);

  const toggleMetronome = useCallback(() => {
    if (isPlaying) {
      stopMetronome();
    } else {
      startMetronome();
    }
  }, [isPlaying, stopMetronome, startMetronome]);

  // Update metronome when BPM changes
  useEffect(() => {
    if (isPlaying) {
      stopMetronome();
      startMetronome();
    }
  }, [bpm, isPlaying, stopMetronome, startMetronome]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopMetronome();
      if (synthRef.current) {
        synthRef.current.dispose();
      }
      if (woodblockRef.current) {
        woodblockRef.current.dispose();
      }
    };
  }, [stopMetronome]);

  const toggleBeatMute = useCallback((beatNumber: number) => {
    setMutedBeats(prev => {
      const newSet = new Set(prev);
      if (newSet.has(beatNumber)) {
        newSet.delete(beatNumber);
      } else {
        newSet.add(beatNumber);
      }
      return newSet;
    });
  }, []);

  const getBeatIndicator = (beatNumber: number) => {
    const isActive = currentBeat === beatNumber;
    const isDownbeat = beatNumber === 1;
    const isMuted = mutedBeats.has(beatNumber);
    
    return (
      <div key={beatNumber} className="flex flex-col items-center space-y-2">
        <div
          className={cn(
            "w-12 h-12 rounded-full border-2 flex items-center justify-center font-bold transition-all duration-150",
            isActive && isDownbeat && !isMuted && "bg-red-500 border-red-500 text-white scale-110",
            isActive && !isDownbeat && !isMuted && "bg-blue-500 border-blue-500 text-white scale-110",
            isActive && isMuted && "bg-gray-400 border-gray-400 text-white scale-110",
            !isActive && isDownbeat && !isMuted && "border-red-300 text-red-600 dark:border-red-700 dark:text-red-400",
            !isActive && !isDownbeat && !isMuted && "border-blue-300 text-blue-600 dark:border-blue-700 dark:text-blue-400",
            !isActive && isMuted && "border-gray-300 text-gray-500 dark:border-gray-600 dark:text-gray-400"
          )}
          data-testid={`beat-indicator-${beatNumber}`}
        >
          {beatNumber}
        </div>
        <Button
          variant={isMuted ? "default" : "outline"}
          size="sm"
          onClick={() => toggleBeatMute(beatNumber)}
          className="w-12 h-6 text-xs p-0"
          data-testid={`beat-mute-${beatNumber}`}
        >
          {isMuted ? "ON" : "OFF"}
        </Button>
      </div>
    );
  };

  return (
    <Card className={cn("metronome", className)}>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <div className="w-4 h-4 rounded-full bg-current animate-pulse" />
          <span>Metronome</span>
          <span className="text-sm font-normal text-muted-foreground">4/4</span>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* BPM Control */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <label className="text-sm font-medium">Tempo</label>
            <div className="text-2xl font-bold font-mono min-w-[80px] text-center">
              {bpm} <span className="text-sm font-normal text-muted-foreground">BPM</span>
            </div>
          </div>
          <Slider
            value={[bpm]}
            onValueChange={(value) => setBpm(value[0])}
            min={33}
            max={300}
            step={1}
            className="w-full"
            data-testid="bpm-slider"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>33</span>
            <span>300</span>
          </div>
        </div>

        {/* Beat Indicators */}
        <div className="space-y-3">
          <label className="text-sm font-medium">Beats</label>
          <div className="flex justify-center space-x-4">
            {[1, 2, 3, 4].map(getBeatIndicator)}
          </div>
          <div className="text-center text-xs text-muted-foreground">
            Toggle individual beats ON/OFF to mute them
          </div>
        </div>

        {/* Sound Selection */}
        <div className="space-y-3">
          <label className="text-sm font-medium">Sound</label>
          <Select value={sound} onValueChange={(value) => setSound(value as MetronomeSound)}>
            <SelectTrigger data-testid="sound-select">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="classic" data-testid="sound-classic">
                Classic Click
              </SelectItem>
              <SelectItem value="woodblock" data-testid="sound-woodblock">
                Woodblock
              </SelectItem>
              <SelectItem value="beep" data-testid="sound-beep">
                Electronic Beep
              </SelectItem>
              <SelectItem value="mute" data-testid="sound-mute">
                <div className="flex items-center space-x-2">
                  <VolumeX className="h-4 w-4" />
                  <span>Mute</span>
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Play/Stop Button */}
        <Button
          onClick={toggleMetronome}
          size="lg"
          className="w-full h-12"
          data-testid="metronome-toggle"
        >
          {isPlaying ? (
            <>
              <Pause className="h-5 w-5 mr-2" />
              Stop
            </>
          ) : (
            <>
              <Play className="h-5 w-5 mr-2" />
              Start
            </>
          )}
        </Button>

        {/* Quick BPM Presets */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Quick Tempos</label>
          <div className="grid grid-cols-6 gap-2">
            {[60, 80, 100, 120, 140, 180].map((tempo) => (
              <Button
                key={tempo}
                variant={bpm === tempo ? "default" : "outline"}
                size="sm"
                onClick={() => setBpm(tempo)}
                data-testid={`tempo-preset-${tempo}`}
                className="text-xs"
              >
                {tempo}
              </Button>
            ))}
          </div>
          <div className="text-xs text-muted-foreground text-center">
            Andante • Moderato • Allegro • Vivace • Presto • Prestissimo
          </div>
        </div>
      </CardContent>
    </Card>
  );
}