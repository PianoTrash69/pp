import { Button } from '@/components/ui/button';
import { commonProgressions, getProgressionChords, Scale } from '@/lib/music-theory';

interface QuickActionsProps {
  scale: Scale;
  onLoadProgression: (chords: string[]) => void;
}

export function QuickActions({ scale, onLoadProgression }: QuickActionsProps) {
  const handleLoadProgression = (progressionKey: keyof typeof commonProgressions) => {
    const chords = getProgressionChords(progressionKey, scale);
    onLoadProgression(chords.map(chord => chord.name));
  };

  const progressionDescriptions = {
    'vi-IV-I-V': 'Pop progression',
    'I-V-vi-IV': 'Classic pop',
    'ii-V-I': 'Jazz turnaround',
    'I-vi-IV-V': '50s progression',
    'vi-ii-V-I': 'Circle of fifths',
    'iii-vi-ii-V': 'Jazz sequence',
    'I-iii-vi-IV': 'Ballad progression',
    'vi-V-IV-V': 'Strong resolution',
    'I-IV-vi-V': 'Folk progression',
    'ii-vi-I-V': 'Jazz standard',
    'I-vi-ii-V': 'Classic jazz',
    'iii-IV-I-vi': 'Modal progression'
  };

  return (
    <div className="bg-card rounded-xl p-4 border border-border shadow-sm quick-actions">
      <h3 className="text-lg font-semibold text-card-foreground mb-3">Quick Progressions</h3>
      <div className="space-y-2 max-h-64 overflow-y-auto">
        {(Object.keys(commonProgressions) as Array<keyof typeof commonProgressions>).map((progressionKey) => {
          const chords = getProgressionChords(progressionKey, scale);
          const chordNames = chords.map(chord => chord.root).join('-');
          
          return (
            <Button
              key={progressionKey}
              onClick={() => handleLoadProgression(progressionKey)}
              variant="secondary"
              className="w-full p-3 h-auto text-left justify-start"
              data-testid={`button-quick-progression-${progressionKey}`}
            >
              <div>
                <div className="font-medium text-sm">{progressionKey}</div>
                <div className="text-xs text-muted-foreground">
                  {chordNames} ({progressionDescriptions[progressionKey as keyof typeof progressionDescriptions] || 'Progression'})
                </div>
              </div>
            </Button>
          );
        })}
      </div>
    </div>
  );
}
