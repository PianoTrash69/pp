import { Play, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { useAudio } from '@/hooks/use-audio';
import { Chord } from '@/lib/music-theory';
import { ChordProgressionSlot } from '@/hooks/use-chord-progressions';
import { cn } from '@/lib/utils';
import { ShareProgression } from '@/components/share-progression';

interface ChordProgressionBuilderProps {
  progression: ChordProgressionSlot[];
  tempo: number;
  setTempo: (tempo: number) => void;
  clearProgression: () => void;
  onDrop: (slotId: number, chord: Chord) => void;
  scale?: string;
  progressionName?: string;
}

export function ChordProgressionBuilder({ 
  progression, 
  tempo, 
  setTempo, 
  clearProgression, 
  onDrop,
  scale = 'C-major',
  progressionName = ''
}: ChordProgressionBuilderProps) {
  const { playProgression } = useAudio();

  const getFilledChords = () => {
    return progression.filter(slot => slot.chord !== null).map(slot => slot.chord!);
  };

  const handlePlay = async () => {
    const chords = getFilledChords();
    if (chords.length === 0) return;
    
    await playProgression(chords, tempo);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, slotId: number) => {
    e.preventDefault();
    const chordData = e.dataTransfer.getData('application/json');
    if (chordData) {
      const chord = JSON.parse(chordData) as Chord;
      onDrop(slotId, chord);
    }
  };

  const handleSlotClick = (slotId: number) => {
    // Remove chord from slot if it has one
    const slot = progression.find(s => s.id === slotId);
    if (slot?.chord) {
      onDrop(slotId, slot.chord); // This will be handled by parent to remove
    }
  };

  return (
    <div className="bg-card rounded-xl p-6 border border-border shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-card-foreground">Chord Progression Builder</h2>
        <div className="flex items-center space-x-2">
          <ShareProgression
            progression={getFilledChords()}
            tempo={tempo}
            scale={scale}
            progressionName={progressionName}
          />
          <Button
            onClick={handlePlay}
            disabled={getFilledChords().length === 0}
            data-testid="button-play-progression"
          >
            <Play className="mr-2 h-4 w-4" />
            Play
          </Button>
          <Button
            onClick={clearProgression}
            variant="destructive"
            data-testid="button-clear-progression"
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Clear
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 mb-4">
        {progression.slice(0, 6).map((slot) => (
          <div
            key={slot.id}
            className={cn(
              "progression-slot rounded-lg flex items-center justify-center min-h-[80px] p-3 cursor-pointer transition-colors",
              slot.chord ? "filled" : "bg-muted/50"
            )}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, slot.id)}
            onClick={() => handleSlotClick(slot.id)}
            data-testid={`progression-slot-${slot.id}`}
          >
            {slot.chord ? (
              <div className="text-center">
                <div className="font-medium text-sm text-foreground">{slot.chord.name}</div>
                <div className="text-xs text-muted-foreground">{slot.chord.roman}</div>
              </div>
            ) : (
              <span className="text-sm text-muted-foreground">Drop chord here</span>
            )}
          </div>
        ))}
      </div>
      
      <div className="p-3 bg-muted rounded-lg">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Tempo:</span>
          <div className="flex items-center space-x-3 flex-1 max-w-64 ml-4">
            <Slider
              value={[tempo]}
              onValueChange={(values) => setTempo(values[0])}
              min={60}
              max={180}
              step={1}
              className="flex-1"
              data-testid="slider-tempo"
            />
            <span className="font-medium w-16 text-right" data-testid="text-tempo-value">
              {tempo} BPM
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
