import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAudio } from '@/hooks/use-audio';
import { cn } from '@/lib/utils';

const chromaticNotes = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

const getKeyColor = (note: string) => {
  return note.includes('#') ? 'black' : 'white';
};

export function PianoKeyboard() {
  const [selectedOctave, setSelectedOctave] = useState(4);
  const [activeKeys, setActiveKeys] = useState<Set<string>>(new Set());
  const { playNote } = useAudio();

  const handleKeyPress = async (note: string) => {
    const keyId = `${note}${selectedOctave}`;
    setActiveKeys(prev => new Set(prev).add(keyId));
    
    await playNote(note, selectedOctave);
    
    // Remove active state after animation
    setTimeout(() => {
      setActiveKeys(prev => {
        const next = new Set(prev);
        next.delete(keyId);
        return next;
      });
    }, 150);
  };

  return (
    <div className="bg-card rounded-xl p-6 border border-border shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-card-foreground">Piano Keyboard</h2>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-muted-foreground">Octave:</span>
          <Select value={selectedOctave.toString()} onValueChange={(value) => setSelectedOctave(parseInt(value))}>
            <SelectTrigger className="w-20" data-testid="select-octave">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="3">3</SelectItem>
              <SelectItem value="4">4</SelectItem>
              <SelectItem value="5">5</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="keyboard-container">
        <div className="grid grid-cols-12 gap-1 max-w-4xl mx-auto">
          {chromaticNotes.map((note) => {
            const keyId = `${note}${selectedOctave}`;
            const isActive = activeKeys.has(keyId);
            const isSharp = getKeyColor(note) === 'black';
            
            return (
              <Button
                key={note}
                className={cn(
                  "keyboard-key h-16 flex flex-col justify-center items-center text-xs font-medium transition-all",
                  isSharp 
                    ? "bg-slate-800 dark:bg-slate-900 text-white hover:bg-slate-700 dark:hover:bg-slate-800 border-slate-600" 
                    : "bg-white dark:bg-slate-100 text-slate-900 hover:bg-slate-50 dark:hover:bg-slate-200 border-slate-300",
                  isActive && (isSharp ? "bg-slate-600 dark:bg-slate-700" : "bg-slate-200 dark:bg-slate-300")
                )}
                variant="outline"
                onClick={() => handleKeyPress(note)}
                data-testid={`key-${note.replace('#', 'sharp')}`}
              >
                <span className={cn(
                  "font-semibold",
                  isSharp ? "text-white" : "text-slate-700 dark:text-slate-900"
                )}>
                  {note}
                </span>
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
