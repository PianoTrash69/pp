import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';

// Generate all 88 piano keys from A0 to C8
const generatePianoKeys = () => {
  const keys = [];
  const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  
  // Start from A0 (MIDI note 21)
  let midiNote = 21;
  let whiteKeyIndex = 0;
  
  // A0, A#0, B0
  keys.push({ note: 'A', octave: 0, midi: midiNote++, isBlack: false, whiteIndex: whiteKeyIndex++ });
  keys.push({ note: 'A#', octave: 0, midi: midiNote++, isBlack: true, whiteIndex: -1 });
  keys.push({ note: 'B', octave: 0, midi: midiNote++, isBlack: false, whiteIndex: whiteKeyIndex++ });
  
  // C1 to B7
  for (let octave = 1; octave <= 7; octave++) {
    for (let i = 0; i < 12; i++) {
      const note = noteNames[i];
      const isBlack = note.includes('#');
      keys.push({
        note,
        octave,
        midi: midiNote++,
        isBlack,
        whiteIndex: isBlack ? -1 : whiteKeyIndex++
      });
    }
  }
  
  // C8 (final key)
  keys.push({ note: 'C', octave: 8, midi: midiNote, isBlack: false, whiteIndex: whiteKeyIndex });
  
  return keys;
};

interface FullPianoKeyboardProps {
  onNoteOn?: (note: string, octave: number, velocity: number) => void;
  onNoteOff?: (note: string, octave: number) => void;
  sustainEnabled?: boolean;
  autoSustainMs?: number;
  onSustainEnabledChange?: (enabled: boolean) => void;
  onAutoSustainMsChange?: (ms: number) => void;
  className?: string;
}

export function FullPianoKeyboard({ 
  onNoteOn, 
  onNoteOff, 
  sustainEnabled = false,
  autoSustainMs = 500,
  onSustainEnabledChange,
  onAutoSustainMsChange,
  className 
}: FullPianoKeyboardProps) {
  const [activeKeys, setActiveKeys] = useState<Set<string>>(new Set());
  const [sustainedKeys, setSustainedKeys] = useState<Set<string>>(new Set());
  const [manualSustain, setManualSustain] = useState(false);
  const [autoSustain, setAutoSustain] = useState(autoSustainMs);
  const [sustainMode, setSustainMode] = useState<'momentary' | 'toggle'>('momentary');
  const [selectedOctave, setSelectedOctave] = useState(4);
  const [localSustainEnabled, setLocalSustainEnabled] = useState(sustainEnabled);
  
  // Track pressed keys to prevent stuck notes when octave changes
  const pressedKeysMap = useRef<Map<string, {note: string, octave: number}>>(new Map());
  
  // Sync props with internal state
  useEffect(() => {
    setAutoSustain(autoSustainMs);
  }, [autoSustainMs]);

  useEffect(() => {
    setLocalSustainEnabled(sustainEnabled);
  }, [sustainEnabled]);

  // Helper functions for sustain
  const activePointers = useRef<Map<number, string>>(new Map());
  const sustainTimeouts = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());
  const pianoKeys = useMemo(() => generatePianoKeys(), []);

  // Dynamic keyboard mapping - chromatic sequence C to C
  const getKeyboardMap = useMemo(() => {
    const keyMappings: [string, {note: string, octave: number}][] = [
      ['z', {note: 'C', octave: selectedOctave}],      // 1. C
      ['s', {note: 'C#', octave: selectedOctave}],     // 2. C#
      ['x', {note: 'D', octave: selectedOctave}],      // 3. D  
      ['d', {note: 'D#', octave: selectedOctave}],     // 4. D#
      ['c', {note: 'E', octave: selectedOctave}],      // 5. E
      ['v', {note: 'F', octave: selectedOctave}],      // 6. F
      ['g', {note: 'F#', octave: selectedOctave}],     // 7. F#
      ['b', {note: 'G', octave: selectedOctave}],      // 8. G
      ['h', {note: 'G#', octave: selectedOctave}],     // 9. G#
      ['n', {note: 'A', octave: selectedOctave}],      // 10. A
      ['j', {note: 'A#', octave: selectedOctave}],     // 11. A#
      ['m', {note: 'B', octave: selectedOctave}],      // 12. B
      [',', {note: 'C', octave: selectedOctave + 1}]  // 13. C (next octave)
    ];

    return new Map(keyMappings);
  }, [selectedOctave]);
  const whiteKeys = pianoKeys.filter(key => !key.isBlack);
  
  // Helper refs to track sustain state and play octaves
  const sustainedKeysRef = useRef<Set<string>>(new Set());
  const playOctaveByKeyId = useRef<Map<string, number>>(new Map());
  useEffect(() => {
    sustainedKeysRef.current = sustainedKeys;
  }, [sustainedKeys]);
  
  // Handle sustain pedal release
  const releaseSustainedNotes = useCallback(() => {
    sustainedKeysRef.current.forEach(keyId => {
      const [note, octaveStr] = keyId.split('-');
      // Use the play octave that was stored when the note was pressed
      const playOctave = playOctaveByKeyId.current.get(keyId) ?? selectedOctave;
      onNoteOff?.(note, playOctave);
      playOctaveByKeyId.current.delete(keyId);
    });
    setSustainedKeys(new Set());
  }, [onNoteOff, selectedOctave]);

  // Sustain pedal handlers
  const handleSustainPress = useCallback(() => {
    if (sustainMode === 'momentary') {
      setManualSustain(true);
    } else {
      setManualSustain(prev => !prev);
    }
  }, [sustainMode]);
  
  const handleSustainRelease = useCallback(() => {
    if (sustainMode === 'momentary') {
      setManualSustain(false);
      releaseSustainedNotes();
    }
  }, [sustainMode, releaseSustainedNotes]);
  
  // Watch for manual sustain changes in toggle mode
  const prevManualSustain = useRef(manualSustain);
  useEffect(() => {
    // If manual sustain was turned off (true -> false), release sustained notes
    if (prevManualSustain.current && !manualSustain) {
      // Clear any auto-release timeouts
      sustainTimeouts.current.forEach(timeout => clearTimeout(timeout));
      sustainTimeouts.current.clear();
      // Release all sustained notes
      releaseSustainedNotes();
    }
    prevManualSustain.current = manualSustain;
  }, [manualSustain, releaseSustainedNotes]);

  // Combined keyboard handler for both piano notes and sustain
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if focus is on input elements or modifiers are pressed
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || 
          target.tagName === 'SELECT' || target.tagName === 'BUTTON' || 
          target.contentEditable === 'true' || e.ctrlKey || e.metaKey || e.altKey) {
        return;
      }
      
      // Additional check for dropdown/select components (shadcn/ui Select creates complex DOM structures)
      if (target.closest('[role="combobox"]') || target.closest('[role="listbox"]') || 
          target.closest('[role="option"]') || target.closest('.select-trigger') ||
          target.closest('.select-content') || target.getAttribute('data-radix-collection-item') !== null) {
        return;
      }
      
      if (e.repeat) return; // Ignore key repeat
      
      const key = e.key.toLowerCase();
      
      // Handle sustain pedal (spacebar)
      if (e.code === 'Space') {
        e.preventDefault();
        handleSustainPress();
        return;
      }
      
      // Handle piano keys
      // Use e.code for physical key tracking to prevent octave change bugs
      if (!pressedKeysMap.current.has(e.code)) {
        const keyMapping = getKeyboardMap.get(key);
        if (keyMapping && onNoteOn) {
          e.preventDefault();
          // Store the mapping for this physical key
          pressedKeysMap.current.set(e.code, keyMapping);
          const keyId = `${keyMapping.note}-${keyMapping.octave}`;
          setActiveKeys(prev => new Set(prev).add(keyId));
          onNoteOn(keyMapping.note, keyMapping.octave, 0.8);
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      // Ignore if focus is on input elements or modifiers are pressed
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || 
          target.tagName === 'SELECT' || target.tagName === 'BUTTON' || 
          target.contentEditable === 'true' || e.ctrlKey || e.metaKey || e.altKey) {
        return;
      }
      
      // Additional check for dropdown/select components (shadcn/ui Select creates complex DOM structures)
      if (target.closest('[role="combobox"]') || target.closest('[role="listbox"]') || 
          target.closest('[role="option"]') || target.closest('.select-trigger') ||
          target.closest('.select-content') || target.getAttribute('data-radix-collection-item') !== null) {
        return;
      }
      
      const key = e.key.toLowerCase();
      
      // Handle sustain pedal release (spacebar)
      if (e.code === 'Space') {
        e.preventDefault();
        handleSustainRelease();
        return;
      }
      
      // Handle piano key release - use stored mapping to prevent octave change bugs
      const keyMapping = pressedKeysMap.current.get(e.code);
      if (keyMapping && onNoteOff) {
        e.preventDefault();
        const keyId = `${keyMapping.note}-${keyMapping.octave}`;
        setActiveKeys(prev => {
          const newSet = new Set(prev);
          newSet.delete(keyId);
          return newSet;
        });
        onNoteOff(keyMapping.note, keyMapping.octave);
        // Remove the mapping since key is released
        pressedKeysMap.current.delete(e.code);
      }
    };

    // Add keyboard listeners for all devices (mobile devices can have keyboards too)
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [onNoteOn, onNoteOff, getKeyboardMap, handleSustainPress, handleSustainRelease]); // Include all dependencies
  
  // Note on handler
  const handleNoteOn = useCallback((key: typeof pianoKeys[0], velocity: number = 0.8, pointerId?: number) => {
    // Apply octave offset to the played note while keeping visual reference to original key
    const playOctave = selectedOctave;
    const keyId = `${key.note}-${key.octave}`; // Visual key ID stays the same
    
    // Store the play octave for this key press for proper sustain release
    playOctaveByKeyId.current.set(keyId, playOctave);
    
    // Track pointer for multi-touch
    if (pointerId !== undefined) {
      activePointers.current.set(pointerId, keyId);
    }
    
    setActiveKeys(prev => new Set(prev).add(keyId));
    onNoteOn?.(key.note, playOctave, velocity); // Play in selected octave
    
    // Clear any pending auto-release
    const existingTimeout = sustainTimeouts.current.get(keyId);
    if (existingTimeout) {
      clearTimeout(existingTimeout);
      sustainTimeouts.current.delete(keyId);
    }
  }, [onNoteOn, selectedOctave]);
  
  // Note off handler
  const handleNoteOff = useCallback((key: typeof pianoKeys[0], pointerId?: number) => {
    // Apply octave offset to the played note while keeping visual reference to original key
    const playOctave = selectedOctave;
    const keyId = `${key.note}-${key.octave}`; // Visual key ID stays the same
    
    // Remove from active pointers
    if (pointerId !== undefined) {
      activePointers.current.delete(pointerId);
    }
    
    setActiveKeys(prev => {
      const next = new Set(prev);
      next.delete(keyId);
      return next;
    });
    
    // Handle sustain logic - only sustain if manual sustain is active OR auto-sustain is enabled
    if (manualSustain || (localSustainEnabled && autoSustain > 0)) {
      // Add to sustained notes if sustain is enabled
      setSustainedKeys(prev => new Set(prev).add(keyId));
      
      // Set auto-release timeout if not manually sustained
      if (!manualSustain && localSustainEnabled && autoSustain > 0) {
        const timeout = setTimeout(() => {
          setSustainedKeys(prev => {
            const next = new Set(prev);
            next.delete(keyId);
            return next;
          });
          // Use stored play octave for correct release
          const playOctave = playOctaveByKeyId.current.get(keyId) ?? selectedOctave;
          onNoteOff?.(key.note, playOctave);
          playOctaveByKeyId.current.delete(keyId);
          sustainTimeouts.current.delete(keyId);
        }, autoSustain);
        sustainTimeouts.current.set(keyId, timeout);
      }
    } else {
      // Immediate release - use stored play octave
      const playOctave = playOctaveByKeyId.current.get(keyId) ?? selectedOctave;
      onNoteOff?.(key.note, playOctave);
      playOctaveByKeyId.current.delete(keyId);
    }
  }, [manualSustain, localSustainEnabled, autoSustain, onNoteOff, selectedOctave]);
  
  // Clear sustain timeouts and play octave tracking on unmount
  useEffect(() => {
    return () => {
      sustainTimeouts.current.forEach(timeout => clearTimeout(timeout));
      sustainTimeouts.current.clear();
      playOctaveByKeyId.current.clear();
    };
  }, []);
  
  // Enhanced pointer event handlers for smoother touch
  const handlePointerDown = useCallback((e: React.PointerEvent, key: typeof pianoKeys[0]) => {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    
    // Enhanced velocity calculation with better touch sensitivity
    let velocity = 0.8; // Default velocity
    
    if (e.pressure > 0) {
      // Use pressure if available (stylus/force touch)
      velocity = Math.max(0.2, Math.min(1, e.pressure * 1.2));
    } else if (e.pointerType === 'touch') {
      // For regular touch, use a slightly softer default
      velocity = 0.7;
    } else if (e.pointerType === 'mouse') {
      // Mouse clicks can be more dynamic
      velocity = 0.8;
    }
    
    // Add slight randomization for more natural feel
    velocity += (Math.random() - 0.5) * 0.05;
    velocity = Math.max(0.1, Math.min(1, velocity));
    
    handleNoteOn(key, velocity, e.pointerId);
    
    // Haptic feedback for mobile devices (if available)
    if (e.pointerType === 'touch' && 'vibrate' in navigator) {
      // Light vibration for touch feedback
      navigator.vibrate(10);
    }
  }, [handleNoteOn]);
  
  const handlePointerUp = useCallback((e: React.PointerEvent, key: typeof pianoKeys[0]) => {
    e.preventDefault();
    e.stopPropagation();
    handleNoteOff(key, e.pointerId);
  }, [handleNoteOff]);
  
  const handlePointerCancel = useCallback((e: React.PointerEvent, key: typeof pianoKeys[0]) => {
    e.preventDefault();
    handleNoteOff(key, e.pointerId);
  }, [handleNoteOff]);
  
  const handlePointerLeave = useCallback((e: React.PointerEvent, key: typeof pianoKeys[0]) => {
    // Only handle if this pointer is not captured by the element
    if (!activePointers.current.has(e.pointerId)) {
      return;
    }
    // Don't immediately release on leave - let pointer move handle it for better sliding
  }, []);
  
  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    // Enhanced drag/glissando with smoother transitions
    if (activePointers.current.has(e.pointerId)) {
      // Use the original coordinates to find the element under the pointer
      const element = document.elementFromPoint(e.clientX, e.clientY);
      let newKeyData = element?.getAttribute('data-key');
      
      // If we didn't hit a key directly, try to find a parent with data-key
      if (!newKeyData && element) {
        const keyElement = element.closest('[data-key]');
        newKeyData = keyElement?.getAttribute('data-key') || null;
      }
      
      if (newKeyData) {
        const currentKey = activePointers.current.get(e.pointerId);
        if (currentKey !== newKeyData) {
          // Smooth transition between keys
          const [oldNote, oldOctave] = currentKey!.split('-');
          const [newNote, newOctave] = newKeyData.split('-');
          
          const oldKey = pianoKeys.find(k => k.note === oldNote && k.octave === parseInt(oldOctave));
          const newKey = pianoKeys.find(k => k.note === newNote && k.octave === parseInt(newOctave));
          
          if (oldKey && newKey) {
            // For smoother glissando, release old note immediately
            handleNoteOff(oldKey, e.pointerId);
            
            // Calculate velocity based on movement speed and pressure
            let velocity = 0.6; // Base velocity for sliding
            
            if (e.pressure > 0) {
              velocity = Math.max(0.3, Math.min(0.9, e.pressure * 1.1));
            } else {
              // Use slightly reduced velocity for sliding to sound more natural
              velocity = 0.5 + Math.random() * 0.2;
            }
            
            // Immediate note start for responsive feel
            handleNoteOn(newKey, velocity, e.pointerId);
          }
        }
      } else {
        // If we're not over any key, release the current one with a brief fade
        const currentKey = activePointers.current.get(e.pointerId);
        if (currentKey) {
          const [oldNote, oldOctave] = currentKey.split('-');
          const oldKey = pianoKeys.find(k => k.note === oldNote && k.octave === parseInt(oldOctave));
          if (oldKey) {
            // Small delay before release to prevent accidental stops during fast glissando
            setTimeout(() => {
              if (activePointers.current.get(e.pointerId) === currentKey) {
                handleNoteOff(oldKey, e.pointerId);
              }
            }, 50);
          }
        }
      }
    }
  }, [pianoKeys, handleNoteOn, handleNoteOff]);
  
  return (
    <Card className={cn("full-piano-container card-mobile", className)}>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg sm:text-xl">88-Key Piano</CardTitle>
        
        {/* Keyboard Controls - Mobile Optimized */}
        <div className="flex flex-col gap-3 sm:flex-row sm:gap-4 sm:items-center">
          {/* Octave Selector for Computer Keyboard */}
          <div className="flex items-center gap-3">
            <label className="text-sm font-medium min-w-0 flex-shrink-0">Piano & Keys (C{selectedOctave}-C{selectedOctave + 1}):</label>
            <Select value={selectedOctave.toString()} onValueChange={(value) => setSelectedOctave(parseInt(value))}>
              <SelectTrigger className="w-24 h-10 text-sm touch-friendly" data-testid="select-keyboard-octave">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">C1-C2</SelectItem>
                <SelectItem value="2">C2-C3</SelectItem>
                <SelectItem value="3">C3-C4</SelectItem>
                <SelectItem value="4">C4-C5</SelectItem>
                <SelectItem value="5">C5-C6</SelectItem>
                <SelectItem value="6">C6-C7</SelectItem>
                <SelectItem value="7">C7-C8</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {/* Sustain Controls - Mobile Friendly */}
          <div className="flex items-center gap-3 flex-wrap">
            <Button
              className={cn("sustain-pedal touch-friendly min-h-[40px]", manualSustain && "active")}
              variant={manualSustain ? "default" : "outline"}
              size="sm"
              onPointerDown={handleSustainPress}
              onPointerUp={handleSustainRelease}
              onPointerLeave={handleSustainRelease}
              data-testid="sustain-pedal"
            >
              🎹 <span className="ml-1">Sustain</span>
            </Button>
            
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium">Mode:</label>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSustainMode(prev => prev === 'momentary' ? 'toggle' : 'momentary')}
                className="h-8 px-3 text-sm touch-friendly"
                data-testid="sustain-mode"
              >
                {sustainMode === 'momentary' ? 'Hold' : 'Toggle'}
              </Button>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch
              checked={localSustainEnabled}
              onCheckedChange={(checked) => {
                setLocalSustainEnabled(checked);
                onSustainEnabledChange?.(checked);
                if (!checked) {
                  // Clear sustain timeouts and release sustained notes
                  sustainTimeouts.current.forEach(timeout => clearTimeout(timeout));
                  sustainTimeouts.current.clear();
                  releaseSustainedNotes();
                }
              }}
              data-testid="auto-sustain-toggle"
            />
            <label className="text-xs">Auto Sustain:</label>
            <div className="w-20">
              <Slider
                value={[autoSustain]}
                onValueChange={([value]) => {
                  setAutoSustain(value);
                  onAutoSustainMsChange?.(value);
                }}
                max={2000}
                min={0}
                step={100}
                className="w-full"
                data-testid="auto-sustain-slider"
              />
            </div>
            <span className="text-xs text-muted-foreground w-12">{autoSustain}ms</span>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pb-4">
        <ScrollArea className="w-full overflow-x-auto full-piano-container">
          <div 
            className="relative flex h-full flex-shrink-0"
            onPointerMove={handlePointerMove}
            style={{ 
              width: `calc(var(--white-key-w) * ${whiteKeys.length})`,
              minHeight: '200px'
            }}
          >
            {/* White Keys */}
            {whiteKeys.map((key) => {
              // Visual piano keys should always use their true octave, not adjusted
              const keyId = `${key.note}-${key.octave}`;
              const isActive = activeKeys.has(keyId);
              const isSustained = sustainedKeys.has(keyId);
              
              return (
                <div
                  key={keyId}
                  className={cn(
                    "piano-white-key transition-all duration-75 ease-out",
                    isActive && "active scale-[0.98] shadow-inner",
                    isSustained && "sustained opacity-80",
                    "hover:bg-gray-50 dark:hover:bg-gray-800 active:bg-gray-100 dark:active:bg-gray-700"
                  )}
                  style={{ order: key.whiteIndex }}
                  onPointerDown={(e) => handlePointerDown(e, key)}
                  onPointerUp={(e) => handlePointerUp(e, key)}
                  onPointerCancel={(e) => handlePointerCancel(e, key)}
                  onPointerLeave={(e) => handlePointerLeave(e, key)}
                  data-key={keyId}
                  data-testid={`piano-key-${key.note}${key.octave}`}
                  role="button"
                  aria-label={`Piano key ${key.note} ${selectedOctave}`}
                  aria-pressed={isActive}
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handlePointerDown(e as any, key);
                    }
                  }}
                  onKeyUp={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handlePointerUp(e as any, key);
                    }
                  }}
                >
                  <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-xs text-gray-600 dark:text-gray-400 font-medium">
                    {key.note}{selectedOctave}
                  </div>
                </div>
              );
            })}
            
            {/* Black Keys */}
            {pianoKeys.filter(key => key.isBlack).map((key) => {
              // Visual piano keys should always use their true octave, not adjusted
              const keyId = `${key.note}-${key.octave}`;
              const isActive = activeKeys.has(keyId);
              const isSustained = sustainedKeys.has(keyId);
              
              // Find the white key to the left of this black key
              const leftWhiteKey = whiteKeys.find(wk => wk.midi === key.midi - 1);
              if (!leftWhiteKey) return null;
              
              // Calculate proper positioning based on note type
              let offset = 0.75; // Default offset from left white key
              
              // Adjust offset based on black key position in the octave for better centering
              const noteInOctave = key.note;
              if (noteInOctave === 'C#') {
                offset = 0.65; // C# positioned between C and D
              } else if (noteInOctave === 'D#') {
                offset = 0.65; // D# positioned between D and E  
              } else if (noteInOctave === 'F#') {
                offset = 0.65; // F# positioned between F and G
              } else if (noteInOctave === 'G#') {
                offset = 0.65; // G# positioned between G and A
              } else if (noteInOctave === 'A#') {
                offset = 0.65; // A# positioned between A and B
              }
              
              return (
                <div
                  key={keyId}
                  className={cn(
                    "piano-black-key transition-all duration-75 ease-out",
                    isActive && "active scale-[0.96] shadow-inner",
                    isSustained && "sustained opacity-80",
                    "hover:bg-gray-700 dark:hover:bg-gray-600 active:bg-gray-800 dark:active:bg-gray-500"
                  )}
                  style={{ left: `calc(var(--white-key-w) * ${leftWhiteKey.whiteIndex} + var(--white-key-w) * ${offset})` }}
                  onPointerDown={(e) => handlePointerDown(e, key)}
                  onPointerUp={(e) => handlePointerUp(e, key)}
                  onPointerCancel={(e) => handlePointerCancel(e, key)}
                  onPointerLeave={(e) => handlePointerLeave(e, key)}
                  data-key={keyId}
                  data-testid={`piano-key-${key.note.replace('#', 'sharp')}${key.octave}`}
                  role="button"
                  aria-label={`Piano key ${key.note.replace('#', ' sharp')} ${selectedOctave}`}
                  aria-pressed={isActive}
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handlePointerDown(e as any, key);
                    }
                  }}
                  onKeyUp={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handlePointerUp(e as any, key);
                    }
                  }}
                >
                  <div className="absolute top-2 left-1/2 transform -translate-x-1/2 text-xs text-white font-medium">
                    {key.note}{selectedOctave}
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
        
        <div className="mt-2 text-xs text-muted-foreground text-center px-2">
          <div className="hidden md:block">
            Z-S-X-D-C-V-G-B-H-N-J-M-, = C-C#-D-D#-E-F-F#-G-G#-A-A#-B-C (chromatic) • Spacebar = sustain • {activeKeys.size} active
            {sustainedKeys.size > 0 && ` • ${sustainedKeys.size} sustained`}
          </div>
          <div className="md:hidden">
            Touch keys to play • Swipe for glissando • {activeKeys.size} active
            {sustainedKeys.size > 0 && ` • ${sustainedKeys.size} sustained`}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}