import { useState, useCallback, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Play, CheckCircle, XCircle, Headphones, Trophy, RotateCcw, Volume2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Chord, generateScale, scales, parseScaleValue } from '@/lib/music-theory';
import { useToast } from '@/hooks/use-toast';

interface Exercise {
  id: string;
  type: 'interval' | 'chord-quality' | 'chord-progression' | 'scale-degree';
  name: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

interface Question {
  id: string;
  type: Exercise['type'];
  question: string;
  correctAnswer: string;
  options: string[];
  audioData?: {
    notes: Array<{ note: string; octave: number }>;
    isChord?: boolean;
    interval?: number;
  };
}

interface PracticeModeProps {
  onPlayNotes?: (notes: Array<{ note: string; octave: number }>, isChord?: boolean) => void;
  scale?: string;
  className?: string;
}

const exercises: Exercise[] = [
  {
    id: 'intervals-basic',
    type: 'interval',
    name: 'Basic Intervals',
    description: 'Identify common intervals: unison, octave, perfect fifth, major third',
    difficulty: 'beginner'
  },
  {
    id: 'intervals-advanced',
    type: 'interval', 
    name: 'All Intervals',
    description: 'Identify all intervals including augmented and diminished',
    difficulty: 'advanced'
  },
  {
    id: 'chord-triads',
    type: 'chord-quality',
    name: 'Basic Triads',
    description: 'Identify major, minor, diminished, and augmented triads',
    difficulty: 'beginner'
  },
  {
    id: 'chord-sevenths',
    type: 'chord-quality',
    name: 'Seventh Chords',
    description: 'Identify major 7th, minor 7th, dominant 7th, and diminished 7th chords',
    difficulty: 'intermediate'
  },
  {
    id: 'progressions-basic',
    type: 'chord-progression',
    name: 'Common Progressions',
    description: 'Identify I-V-vi-IV, ii-V-I, and other common progressions',
    difficulty: 'intermediate'
  },
  {
    id: 'scale-degrees',
    type: 'scale-degree',
    name: 'Scale Degrees',
    description: 'Identify the scale degree of played notes',
    difficulty: 'beginner'
  }
];

const intervalNames = [
  'Unison', 'Minor 2nd', 'Major 2nd', 'Minor 3rd', 'Major 3rd', 'Perfect 4th', 
  'Tritone', 'Perfect 5th', 'Minor 6th', 'Major 6th', 'Minor 7th', 'Major 7th', 'Octave'
];

const chordQualities = [
  'Major', 'Minor', 'Diminished', 'Augmented', 'Major 7th', 'Minor 7th', 
  'Dominant 7th', 'Diminished 7th', 'Half-diminished 7th'
];

export function PracticeMode({ onPlayNotes, scale = 'C-major', className }: PracticeModeProps) {
  const [currentExercise, setCurrentExercise] = useState<Exercise | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState({ correct: 0, total: 0 });
  const [questionsRemaining, setQuestionsRemaining] = useState(10);
  const [sessionComplete, setSessionComplete] = useState(false);
  const questionCountRef = useRef(0);
  const { toast } = useToast();

  // Generate a random question based on the exercise type
  const generateQuestion = useCallback((exercise: Exercise): Question => {
    questionCountRef.current += 1;
    
    const baseOctave = 4;
    
    let currentScale;
    try {
      const { root, mode } = parseScaleValue(scale);
      currentScale = generateScale(root, mode);
    } catch (error) {
      currentScale = generateScale('C', 'major');
    }

    switch (exercise.type) {
      case 'interval': {
        const intervals = exercise.difficulty === 'beginner' 
          ? [0, 4, 7, 12] // Unison, major 3rd, perfect 5th, octave
          : [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]; // All intervals
        
        const interval = intervals[Math.floor(Math.random() * intervals.length)];
        const rootNote = currentScale.notes[Math.floor(Math.random() * currentScale.notes.length)];
        const rootNoteClean = rootNote.replace(/\d+$/, '');
        
        // Calculate the second note
        const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
        const rootIndex = noteNames.indexOf(rootNoteClean);
        const secondNoteIndex = (rootIndex + interval) % 12;
        const secondNote = noteNames[secondNoteIndex];
        const secondOctave = baseOctave + Math.floor((rootIndex + interval) / 12);
        
        return {
          id: `interval-${questionCountRef.current}`,
          type: 'interval',
          question: 'What interval do you hear?',
          correctAnswer: intervalNames[interval],
          options: exercise.difficulty === 'beginner' 
            ? ['Unison', 'Major 3rd', 'Perfect 5th', 'Octave']
            : intervalNames.slice(0, 13),
          audioData: {
            notes: [
              { note: rootNoteClean, octave: baseOctave },
              { note: secondNote, octave: secondOctave }
            ],
            isChord: false,
            interval
          }
        };
      }

      case 'chord-quality': {
        const availableChords = exercise.difficulty === 'beginner'
          ? currentScale.chords.filter(chord => 
              chord.quality === 'major' || chord.quality === 'minor' || 
              chord.quality === 'diminished' || chord.quality === 'augmented'
            )
          : currentScale.chords;
        
        const randomChord = availableChords[Math.floor(Math.random() * availableChords.length)];
        const chordNotes = randomChord.notes.map(note => {
          const noteClean = note.replace(/\d+$/, '');
          return { note: noteClean, octave: baseOctave };
        });

        const qualityMap: { [key: string]: string } = {
          'major': 'Major',
          'minor': 'Minor', 
          'diminished': 'Diminished',
          'augmented': 'Augmented',
          'major7': 'Major 7th',
          'minor7': 'Minor 7th',
          'dominant7': 'Dominant 7th',
          'diminished7': 'Diminished 7th',
          'half-diminished7': 'Half-diminished 7th'
        };

        const options = exercise.difficulty === 'beginner'
          ? ['Major', 'Minor', 'Diminished', 'Augmented']
          : chordQualities;

        return {
          id: `chord-${questionCountRef.current}`,
          type: 'chord-quality',
          question: 'What type of chord do you hear?',
          correctAnswer: qualityMap[randomChord.quality] || randomChord.quality,
          options,
          audioData: {
            notes: chordNotes,
            isChord: true
          }
        };
      }

      case 'scale-degree': {
        const scaleNote = currentScale.notes[Math.floor(Math.random() * currentScale.notes.length)];
        const noteClean = scaleNote.replace(/\d+$/, '');
        const degreeNames = ['1st (Do)', '2nd (Re)', '3rd (Mi)', '4th (Fa)', '5th (Sol)', '6th (La)', '7th (Ti)'];
        const degree = currentScale.notes.findIndex(n => n.replace(/\d+$/, '') === noteClean);
        
        return {
          id: `degree-${questionCountRef.current}`,
          type: 'scale-degree',
          question: `What scale degree is this note in ${scale}?`,
          correctAnswer: degreeNames[degree],
          options: degreeNames,
          audioData: {
            notes: [{ note: noteClean, octave: baseOctave }],
            isChord: false
          }
        };
      }

      default:
        throw new Error(`Unknown exercise type: ${exercise.type}`);
    }
  }, [scale]);

  const startExercise = useCallback((exercise: Exercise) => {
    setCurrentExercise(exercise);
    setScore({ correct: 0, total: 0 });
    setQuestionsRemaining(10);
    setSessionComplete(false);
    questionCountRef.current = 0;
    setCurrentQuestion(generateQuestion(exercise));
    setSelectedAnswer('');
    setShowResult(false);
  }, [generateQuestion]);

  const playQuestion = useCallback(() => {
    if (currentQuestion?.audioData && onPlayNotes) {
      onPlayNotes(currentQuestion.audioData.notes, currentQuestion.audioData.isChord);
    }
  }, [currentQuestion, onPlayNotes]);

  const handleAnswer = useCallback((answer: string) => {
    setSelectedAnswer(answer);
    setShowResult(true);
    
    const isCorrect = answer === currentQuestion?.correctAnswer;
    setScore(prev => ({
      correct: prev.correct + (isCorrect ? 1 : 0),
      total: prev.total + 1
    }));

    if (isCorrect) {
      toast({
        title: "Correct!",
        description: "Well done! That's the right answer.",
      });
    } else {
      toast({
        title: "Not quite",
        description: `The correct answer was: ${currentQuestion?.correctAnswer}`,
        variant: "destructive"
      });
    }

    // Auto-advance after 2 seconds
    setTimeout(() => {
      nextQuestion();
    }, 2000);
  }, [currentQuestion, toast]);

  const nextQuestion = useCallback(() => {
    if (questionsRemaining <= 1) {
      setSessionComplete(true);
      return;
    }

    if (currentExercise) {
      setQuestionsRemaining(prev => prev - 1);
      setCurrentQuestion(generateQuestion(currentExercise));
      setSelectedAnswer('');
      setShowResult(false);
    }
  }, [questionsRemaining, currentExercise, generateQuestion]);

  const restartExercise = useCallback(() => {
    if (currentExercise) {
      startExercise(currentExercise);
    }
  }, [currentExercise, startExercise]);

  // Auto-play question when it's generated
  useEffect(() => {
    if (currentQuestion && !showResult) {
      const timer = setTimeout(() => {
        playQuestion();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [currentQuestion, showResult, playQuestion]);

  if (!currentExercise) {
    return (
      <Card className={cn("practice-mode", className)}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Headphones className="h-5 w-5 text-primary" />
            <span>Ear Training Practice</span>
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Improve your musical ear with guided exercises
          </p>
        </CardHeader>
        
        <CardContent>
          <ScrollArea className="h-80">
            <div className="space-y-3">
              {exercises.map((exercise) => (
                <Card 
                  key={exercise.id} 
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => startExercise(exercise)}
                  data-testid={`exercise-${exercise.id}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium">{exercise.name}</h3>
                      <Badge variant={
                        exercise.difficulty === 'beginner' ? 'default' :
                        exercise.difficulty === 'intermediate' ? 'secondary' : 'destructive'
                      }>
                        {exercise.difficulty}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {exercise.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    );
  }

  if (sessionComplete) {
    const percentage = Math.round((score.correct / score.total) * 100);
    return (
      <Card className={cn("practice-mode", className)}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            <span>Session Complete!</span>
          </CardTitle>
        </CardHeader>
        
        <CardContent className="text-center space-y-4">
          <div className="text-6xl font-bold text-primary">
            {percentage}%
          </div>
          <div className="text-lg">
            You scored {score.correct} out of {score.total}
          </div>
          <div className="text-sm text-muted-foreground">
            {percentage >= 80 ? "Excellent work!" :
             percentage >= 60 ? "Good job!" : "Keep practicing!"}
          </div>
          
          <div className="flex gap-2 justify-center">
            <Button onClick={restartExercise} data-testid="restart-exercise">
              <RotateCcw className="h-4 w-4 mr-2" />
              Try Again
            </Button>
            <Button variant="outline" onClick={() => setCurrentExercise(null)}>
              Choose New Exercise
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn("practice-mode", className)}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Headphones className="h-5 w-5 text-primary" />
            <span>{currentExercise.name}</span>
          </CardTitle>
          <Badge variant="outline">
            {score.correct}/{score.total}
          </Badge>
        </div>
        <Progress value={((10 - questionsRemaining) / 10) * 100} className="w-full" />
        <p className="text-sm text-muted-foreground">
          Question {10 - questionsRemaining + 1} of 10
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {currentQuestion && (
          <>
            <div className="text-center space-y-4">
              <h3 className="text-lg font-medium">{currentQuestion.question}</h3>
              
              <Button 
                onClick={playQuestion}
                variant="outline"
                size="lg"
                data-testid="play-question"
              >
                <Volume2 className="h-4 w-4 mr-2" />
                Play Again
              </Button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {currentQuestion.options.map((option) => (
                <Button
                  key={option}
                  variant={showResult 
                    ? (option === currentQuestion.correctAnswer ? "default" : 
                       option === selectedAnswer && option !== currentQuestion.correctAnswer ? "destructive" : "outline")
                    : selectedAnswer === option ? "default" : "outline"
                  }
                  className={cn(
                    "h-auto p-4 text-left justify-start",
                    showResult && option === currentQuestion.correctAnswer && "bg-green-500 hover:bg-green-600",
                    showResult && option === selectedAnswer && option !== currentQuestion.correctAnswer && "bg-red-500 hover:bg-red-600"
                  )}
                  onClick={() => !showResult && handleAnswer(option)}
                  disabled={showResult}
                  data-testid={`answer-${option.replace(/\s+/g, '-').toLowerCase()}`}
                >
                  <div className="flex items-center space-x-2">
                    {showResult && option === currentQuestion.correctAnswer && (
                      <CheckCircle className="h-4 w-4" />
                    )}
                    {showResult && option === selectedAnswer && option !== currentQuestion.correctAnswer && (
                      <XCircle className="h-4 w-4" />
                    )}
                    <span>{option}</span>
                  </div>
                </Button>
              ))}
            </div>
            
            {showResult && (
              <div className="text-center text-sm text-muted-foreground">
                {questionsRemaining > 1 ? "Next question in 2 seconds..." : "Session complete!"}
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}