import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Play, Pause, Square, Circle, Trash2, Download, Upload } from 'lucide-react';
import { audioEngine } from '@/lib/audio';
import { useToast } from '@/hooks/use-toast';
import { FullPianoKeyboard } from '@/components/full-piano-keyboard';

interface MelodyNote {
  note: string;
  octave: number;
  duration: string;
  time: number;
  velocity: number;
}

interface CompositionSection {
  id: string;
  name: string;
  chords: string[][];
  melody: MelodyNote[];
}

export function MusicComposer() {
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSection, setCurrentSection] = useState<CompositionSection>({
    id: '1',
    name: 'Section 1',
    chords: [],
    melody: []
  });
  const [tempo, setTempo] = useState([120]);
  const [currentOctave, setCurrentOctave] = useState(4);
  const [recordingStartTime, setRecordingStartTime] = useState<number | null>(null);
  const [compositionSections, setCompositionSections] = useState<CompositionSection[]>([]);
  
  const { toast } = useToast();
  const recordingTimeRef = useRef<number>(0);
  const recordingBeatRef = useRef<number>(0);

  // Audio sustain settings  
  const [sustainEnabled, setSustainEnabled] = useState(false);
  const [autoSustainMs, setAutoSustainMs] = useState(500);
  
  // Update audio engine sustain settings
  useEffect(() => {
    audioEngine.setSustainEnabled(sustainEnabled);
    audioEngine.setAutoSustainMs(autoSustainMs);
  }, [sustainEnabled, autoSustainMs]);

  // Store recording note starts for duration calculation
  const recordingNotes = useRef<Map<string, {startTime: number, startBeat: number}>>(new Map());

  // Handle note on/off events from the full piano
  const handleNoteOn = async (note: string, octave: number, velocity: number) => {
    try {
      audioEngine.noteOn(note, octave, velocity);
      
      // If recording, track note start time for duration calculation
      if (isRecording && recordingStartTime !== null) {
        const currentTime = Date.now();
        const elapsedSeconds = (currentTime - recordingStartTime) / 1000;
        const beatsPerSecond = tempo[0] / 60;
        const beatTime = elapsedSeconds * beatsPerSecond;
        
        const noteKey = `${note}-${octave}`;
        recordingNotes.current.set(noteKey, {
          startTime: currentTime,
          startBeat: beatTime
        });
      }
    } catch (error) {
      console.error('Error playing note:', error);
    }
  };
  
  const handleNoteOff = (note: string, octave: number) => {
    try {
      audioEngine.noteOff(note, octave);
      
      // If recording, calculate duration and add note to melody
      if (isRecording && recordingStartTime !== null) {
        const noteKey = `${note}-${octave}`;
        const noteStart = recordingNotes.current.get(noteKey);
        
        if (noteStart) {
          const currentTime = Date.now();
          const noteDurationMs = currentTime - noteStart.startTime;
          const beatsPerSecond = tempo[0] / 60;
          const noteDurationBeats = (noteDurationMs / 1000) * beatsPerSecond;
          
          // Determine duration based on note length (quantize to common note values)
          let duration = '8n'; // Default eighth note
          if (noteDurationBeats >= 3.5) duration = '1n';
          else if (noteDurationBeats >= 1.5) duration = '2n';
          else if (noteDurationBeats >= 0.75) duration = '4n';
          else if (noteDurationBeats >= 0.375) duration = '8n';
          else duration = '16n';
          
          const newNote: MelodyNote = {
            note,
            octave,
            duration,
            time: noteStart.startBeat,
            velocity: 0.8
          };
          
          setCurrentSection(prev => ({
            ...prev,
            melody: [...prev.melody, newNote]
          }));
          
          recordingNotes.current.delete(noteKey);
        }
      }
    } catch (error) {
      console.error('Error releasing note:', error);
    }
  };

  const handleNotePlay = async (note: string, isChord: boolean = false) => {
    try {
      if (isChord) {
        // Play as chord
        await audioEngine.playNote(note, currentOctave);
      } else {
        // Play as melody note
        await audioEngine.playMelodyNote(note, currentOctave);
        
        // If recording, add to melody with proper timing
        if (isRecording && recordingStartTime !== null) {
          const currentTime = Date.now();
          const elapsedSeconds = (currentTime - recordingStartTime) / 1000;
          
          // Convert to beats using current tempo: beats = seconds * (BPM / 60)
          const beatsPerSecond = tempo[0] / 60;
          const beatTime = elapsedSeconds * beatsPerSecond;
          
          const newNote: MelodyNote = {
            note,
            octave: currentOctave,
            duration: '8n',
            time: beatTime,
            velocity: 0.8
          };
          
          setCurrentSection(prev => ({
            ...prev,
            melody: [...prev.melody, newNote]
          }));
        }
      }
    } catch (error) {
      console.error('Error playing note:', error);
    }
  };

  const startRecording = () => {
    setIsRecording(true);
    setRecordingStartTime(Date.now());
    setCurrentSection(prev => ({
      ...prev,
      melody: [] // Clear previous melody
    }));
    
    toast({
      title: "Recording Started",
      description: "Play notes on the keyboard to record your melody",
    });
  };

  const stopRecording = () => {
    setIsRecording(false);
    setRecordingStartTime(null);
    
    toast({
      title: "Recording Stopped",
      description: `Recorded ${currentSection.melody.length} notes`,
    });
  };

  const playComposition = async () => {
    if (currentSection.melody.length === 0 && currentSection.chords.length === 0) {
      toast({
        title: "Nothing to Play",
        description: "Record some notes or add chords first",
        variant: "destructive"
      });
      return;
    }

    setIsPlaying(true);
    
    try {
      // Use the unified composition playback method - now waits for completion
      await audioEngine.playComposition(
        currentSection.melody, 
        currentSection.chords, 
        tempo[0], 
        currentOctave - 1
      );
    } catch (error) {
      console.error('Error playing composition:', error);
      toast({
        title: "Playback Error",
        description: "There was an error playing your composition",
        variant: "destructive"
      });
    } finally {
      setIsPlaying(false);
    }
  };

  const stopPlayback = () => {
    audioEngine.stopAll();
    setIsPlaying(false);
  };

  const clearComposition = () => {
    setCurrentSection(prev => ({
      ...prev,
      melody: [],
      chords: []
    }));
    
    toast({
      title: "Composition Cleared",
      description: "All notes and chords have been removed",
    });
  };

  const saveComposition = () => {
    const compositionData = {
      sections: [currentSection],
      tempo: tempo[0],
      timestamp: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(compositionData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `composition-${Date.now()}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    toast({
      title: "Composition Saved",
      description: "Your composition has been downloaded as a JSON file",
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Music Composer
            <Circle className="h-4 w-4" />
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Transport Controls */}
          <div className="flex items-center gap-4">
            <Button
              onClick={isRecording ? stopRecording : startRecording}
              variant={isRecording ? "destructive" : "default"}
              data-testid={isRecording ? "button-stop-recording" : "button-start-recording"}
            >
              {isRecording ? <Square className="h-4 w-4 mr-2" /> : <Circle className="h-4 w-4 mr-2" />}
              {isRecording ? 'Stop Recording' : 'Start Recording'}
            </Button>
            
            <Button
              onClick={isPlaying ? stopPlayback : playComposition}
              variant={isPlaying ? "secondary" : "default"}
              disabled={currentSection.melody.length === 0 && currentSection.chords.length === 0}
              data-testid={isPlaying ? "button-stop-playback" : "button-play-composition"}
            >
              {isPlaying ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
              {isPlaying ? 'Stop' : 'Play'}
            </Button>
            
            <Button
              onClick={clearComposition}
              variant="outline"
              data-testid="button-clear-composition"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Clear
            </Button>
            
            <Button
              onClick={saveComposition}
              variant="outline"
              disabled={currentSection.melody.length === 0 && currentSection.chords.length === 0}
              data-testid="button-save-composition"
            >
              <Download className="h-4 w-4 mr-2" />
              Save
            </Button>
          </div>

          {/* Recording Status */}
          {isRecording && (
            <div className="bg-red-100 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3">
              <div className="flex items-center gap-2 text-red-700 dark:text-red-300">
                <Circle className="h-3 w-3 fill-current animate-pulse" />
                <span className="text-sm font-medium">Recording in progress...</span>
                <span className="text-xs">Notes recorded: {currentSection.melody.length}</span>
              </div>
            </div>
          )}

          {/* Tempo and Octave Controls */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Tempo: {tempo[0]} BPM</label>
              <Slider
                value={tempo}
                onValueChange={setTempo}
                min={60}
                max={200}
                step={1}
                className="w-full"
                data-testid="slider-tempo"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Octave</label>
              <Select value={currentOctave.toString()} onValueChange={(value) => setCurrentOctave(parseInt(value))}>
                <SelectTrigger data-testid="select-octave">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[2, 3, 4, 5, 6, 7].map(octave => (
                    <SelectItem key={octave} value={octave.toString()}>
                      Octave {octave}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* 88-Key Piano Keyboard */}
          <div className="space-y-4">
            <FullPianoKeyboard
              onNoteOn={handleNoteOn}
              onNoteOff={handleNoteOff}
              sustainEnabled={false}
              autoSustainMs={autoSustainMs}
              className="w-full"
            />
            
            {/* Sustain Control Panel */}
            <div className="flex flex-wrap gap-4 items-center justify-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium">Auto Sustain:</label>
                <input
                  type="checkbox"
                  checked={sustainEnabled}
                  onChange={(e) => setSustainEnabled(e.target.checked)}
                  className="rounded"
                />
              </div>
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium">Duration:</label>
                <input
                  type="range"
                  min="0"
                  max="2000"
                  step="100"
                  value={autoSustainMs}
                  onChange={(e) => setAutoSustainMs(parseInt(e.target.value))}
                  className="w-20"
                />
                <span className="text-xs text-muted-foreground w-12">{autoSustainMs}ms</span>
              </div>
            </div>
          </div>

          {/* Composition Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Melody</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  {currentSection.melody.length === 0 
                    ? "No melody recorded" 
                    : `${currentSection.melody.length} notes recorded`}
                </p>
                {currentSection.melody.length > 0 && (
                  <div className="mt-2 text-xs text-muted-foreground">
                    Duration: ~{(Math.max(...currentSection.melody.map(n => n.time)) * 60 / tempo[0]).toFixed(1)}s
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Chords</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  {currentSection.chords.length === 0 
                    ? "No chords added" 
                    : `${currentSection.chords.length} chords in progression`}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Use the chord progression builder to add chords
                </p>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}