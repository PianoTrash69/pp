import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Music, Play, RotateCcw, Trophy, BookOpen, Target, Eye } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Note {
  name: string;
  octave: number;
  position: number; // Staff line position (0 = middle C)
  accidental?: 'sharp' | 'flat' | 'natural';
}

interface MusicReadingTeacherProps {
  onPlayNote?: (note: string, octave: number) => void;
  className?: string;
}

const trebleStaffNotes: Note[] = [
  // Treble clef notes
  { name: 'C', octave: 4, position: 0 }, // Middle C (below staff)
  { name: 'D', octave: 4, position: 1 },
  { name: 'E', octave: 4, position: 2 }, // First line
  { name: 'F', octave: 4, position: 3 },
  { name: 'G', octave: 4, position: 4 }, // Second line
  { name: 'A', octave: 4, position: 5 },
  { name: 'B', octave: 4, position: 6 }, // Third line
  { name: 'C', octave: 5, position: 7 },
  { name: 'D', octave: 5, position: 8 }, // Fourth line
  { name: 'E', octave: 5, position: 9 },
  { name: 'F', octave: 5, position: 10 }, // Fifth line
  { name: 'G', octave: 5, position: 11 },
  { name: 'A', octave: 5, position: 12 }, // Above staff
];

const bassStaffNotes: Note[] = [
  // Bass clef notes
  { name: 'E', octave: 2, position: 0 }, // Below staff
  { name: 'F', octave: 2, position: 1 },
  { name: 'G', octave: 2, position: 2 }, // First line
  { name: 'A', octave: 2, position: 3 },
  { name: 'B', octave: 2, position: 4 }, // Second line
  { name: 'C', octave: 3, position: 5 },
  { name: 'D', octave: 3, position: 6 }, // Third line
  { name: 'E', octave: 3, position: 7 },
  { name: 'F', octave: 3, position: 8 }, // Fourth line (F line)
  { name: 'G', octave: 3, position: 9 },
  { name: 'A', octave: 3, position: 10 }, // Fifth line
  { name: 'B', octave: 3, position: 11 },
  { name: 'C', octave: 4, position: 12 }, // Above staff
];

const musicalSymbols = [
  {
    name: 'Whole Note',
    symbol: '○',
    description: 'Lasts for 4 beats in 4/4 time',
    duration: '1n'
  },
  {
    name: 'Half Note',
    symbol: '♩',
    description: 'Lasts for 2 beats in 4/4 time',
    duration: '2n'
  },
  {
    name: 'Quarter Note',
    symbol: '♪',
    description: 'Lasts for 1 beat in 4/4 time',
    duration: '4n'
  },
  {
    name: 'Eighth Note',
    symbol: '♫',
    description: 'Lasts for 1/2 beat in 4/4 time',
    duration: '8n'
  },
  {
    name: 'Treble Clef',
    symbol: '𝄞',
    description: 'Indicates higher pitches, used for right hand piano',
    duration: ''
  },
  {
    name: 'Bass Clef',
    symbol: '𝄢',
    description: 'Indicates lower pitches, used for left hand piano',
    duration: ''
  },
  {
    name: 'Sharp',
    symbol: '♯',
    description: 'Raises the pitch by a semitone',
    duration: ''
  },
  {
    name: 'Flat',
    symbol: '♭',
    description: 'Lowers the pitch by a semitone',
    duration: ''
  },
  {
    name: 'Natural',
    symbol: '♮',
    description: 'Cancels sharps or flats',
    duration: ''
  }
];

const staffLinePositions = [2, 4, 6, 8, 10]; // E, G, B, D, F
const ledgerLinePositions = [0, 12]; // Middle C, high A

export function MusicReadingTeacher({ onPlayNote, className }: MusicReadingTeacherProps) {
  const [currentExercise, setCurrentExercise] = useState<'identification' | 'sight-reading' | 'symbols'>('identification');
  const [currentClef, setCurrentClef] = useState<'treble' | 'bass'>('treble');
  const [currentNote, setCurrentNote] = useState<Note>(trebleStaffNotes[4]); // Start with G
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [score, setScore] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('easy');
  const [currentSymbol, setCurrentSymbol] = useState(musicalSymbols[0]);

  const generateRandomNote = useCallback(() => {
    const staffNotes = currentClef === 'treble' ? trebleStaffNotes : bassStaffNotes;
    let availableNotes = staffNotes;
    
    if (difficulty === 'easy') {
      // Only line notes (E, G, B, D, F for treble; G, B, D, F, A for bass)
      availableNotes = staffNotes.filter(note => 
        [2, 4, 6, 8, 10].includes(note.position)
      );
    } else if (difficulty === 'medium') {
      // Lines and spaces, no accidentals
      availableNotes = staffNotes.filter(note => 
        note.position >= 2 && note.position <= 10
      );
    }
    // Hard includes all notes including ledger lines
    
    const randomNote = availableNotes[Math.floor(Math.random() * availableNotes.length)];
    setCurrentNote(randomNote);
    setSelectedAnswer('');
    setShowAnswer(false);
  }, [difficulty, currentClef]);

  const generateRandomSymbol = useCallback(() => {
    const randomSymbol = musicalSymbols[Math.floor(Math.random() * musicalSymbols.length)];
    setCurrentSymbol(randomSymbol);
    setSelectedAnswer('');
    setShowAnswer(false);
  }, []);

  useEffect(() => {
    generateRandomNote();
  }, [generateRandomNote]);

  const handleAnswer = (answer: string) => {
    setSelectedAnswer(answer);
    setAttempts(prev => prev + 1);
    
    const isCorrect = currentExercise === 'symbols' 
      ? answer === currentSymbol.name
      : answer === currentNote.name;
    
    if (isCorrect) {
      setScore(prev => prev + 1);
    }
    setShowAnswer(true);
    
    // Auto-advance after 2 seconds
    setTimeout(() => {
      if (currentExercise === 'symbols') {
        generateRandomSymbol();
      } else {
        generateRandomNote();
      }
    }, 2000);
  };

  const playCurrentNote = () => {
    if (onPlayNote && currentExercise !== 'symbols') {
      onPlayNote(currentNote.name, currentNote.octave);
    }
  };

  const renderStaffNote = (note: Note) => {
    const staffHeight = 120;
    const staffTop = 20;
    const lineSpacing = 20;
    
    // Calculate Y position (higher positions = lower on screen)
    const noteY = staffTop + (10 - note.position) * (lineSpacing / 2);
    
    return (
      <div className="relative w-full h-40 bg-white dark:bg-gray-800 border rounded-lg overflow-hidden">
        <svg width="100%" height="160" className="absolute inset-0">
          {/* Staff lines */}
          {staffLinePositions.map((_, index) => (
            <line
              key={index}
              x1="40"
              y1={staffTop + index * lineSpacing}
              x2="360"
              y2={staffTop + index * lineSpacing}
              stroke="currentColor"
              strokeWidth="2"
              className="text-gray-700 dark:text-gray-300"
            />
          ))}
          
          {/* Ledger lines for middle C and high notes */}
          {note.position === 0 && (
            <line
              x1="140"
              y1={noteY}
              x2="180"
              y2={noteY}
              stroke="currentColor"
              strokeWidth="2"
              className="text-gray-700 dark:text-gray-300"
            />
          )}
          {note.position === 12 && (
            <line
              x1="140"
              y1={noteY}
              x2="180"
              y2={noteY}
              stroke="currentColor"
              strokeWidth="2"
              className="text-gray-700 dark:text-gray-300"
            />
          )}
          
          {/* Clef symbol */}
          <text
            x="50"
            y={currentClef === 'treble' ? staffTop + 1 * lineSpacing + 8 : staffTop + 3 * lineSpacing + 6}
            className="text-3xl font-bold text-blue-600 dark:text-blue-400"
            style={{ fontFamily: 'serif' }}
          >
            {currentClef === 'treble' ? '𝄞' : '𝄢'}
          </text>
          
          {/* Note */}
          <circle
            cx="160"
            cy={noteY}
            r="8"
            fill="currentColor"
            className="text-red-600 dark:text-red-400"
          />
          
          {/* Note stem */}
          {note.position <= 6 ? (
            <line
              x1="168"
              y1={noteY}
              x2="168"
              y2={noteY - 30}
              stroke="currentColor"
              strokeWidth="2"
              className="text-red-600 dark:text-red-400"
            />
          ) : (
            <line
              x1="152"
              y1={noteY}
              x2="152"
              y2={noteY + 30}
              stroke="currentColor"
              strokeWidth="2"
              className="text-red-600 dark:text-red-400"
            />
          )}
        </svg>
      </div>
    );
  };

  const renderSymbolDisplay = (symbol: typeof musicalSymbols[0]) => {
    return (
      <div className="relative w-full h-40 bg-white dark:bg-gray-800 border rounded-lg flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl font-bold text-blue-600 dark:text-blue-400 mb-4">
            {symbol.symbol}
          </div>
          <div className="text-sm text-muted-foreground">
            What is this musical symbol?
          </div>
        </div>
      </div>
    );
  };

  const noteNames = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
  const symbolNames = musicalSymbols.map(s => s.name);

  return (
    <Card className={cn("music-reading-teacher", className)}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <BookOpen className="h-5 w-5 text-primary" />
            <CardTitle>Music Reading Teacher</CardTitle>
          </div>
          <div className="flex items-center space-x-2">
            <Trophy className="h-4 w-4 text-yellow-500" />
            <span className="text-sm font-medium">
              {attempts > 0 ? Math.round((score / attempts) * 100) : 0}%
            </span>
            <span className="text-xs text-muted-foreground">
              ({score}/{attempts})
            </span>
          </div>
        </div>
        <Progress value={attempts > 0 ? (score / attempts) * 100 : 0} className="h-2" />
      </CardHeader>

      <CardContent className="space-y-6">
        <Tabs value={currentExercise} onValueChange={(value) => setCurrentExercise(value as any)}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="identification" data-testid="tab-note-identification">
              <Target className="h-4 w-4 mr-2" />
              Note ID
            </TabsTrigger>
            <TabsTrigger value="sight-reading" data-testid="tab-sight-reading">
              <Eye className="h-4 w-4 mr-2" />
              Sight Reading
            </TabsTrigger>
            <TabsTrigger value="symbols" data-testid="tab-symbols">
              <Music className="h-4 w-4 mr-2" />
              Symbols
            </TabsTrigger>
          </TabsList>

          <TabsContent value="identification" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Note Identification</h3>
              <div className="flex space-x-2">
                <Select value={currentClef} onValueChange={(value) => setCurrentClef(value as 'treble' | 'bass')}>
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="treble">Treble</SelectItem>
                    <SelectItem value="bass">Bass</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={difficulty} onValueChange={(value) => setDifficulty(value as any)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="easy">Easy</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="hard">Hard</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {renderStaffNote(currentNote)}

            <div className="text-center">
              <Button
                onClick={playCurrentNote}
                variant="outline"
                className="mb-4"
                data-testid="button-play-note"
              >
                <Play className="h-4 w-4 mr-2" />
                Play Note
              </Button>
            </div>

            <div className="text-center space-y-3">
              <p className="text-sm text-muted-foreground">What note is this?</p>
              <div className="grid grid-cols-7 gap-2">
                {noteNames.map((name) => (
                  <Button
                    key={name}
                    onClick={() => handleAnswer(name)}
                    variant={selectedAnswer === name ? "default" : "outline"}
                    disabled={showAnswer}
                    className={cn(
                      showAnswer && name === currentNote.name && "bg-green-500 hover:bg-green-600",
                      showAnswer && selectedAnswer === name && name !== currentNote.name && "bg-red-500 hover:bg-red-600"
                    )}
                    data-testid={`button-note-${name}`}
                  >
                    {name}
                  </Button>
                ))}
              </div>
              
              {showAnswer && (
                <div className="mt-4 space-y-2">
                  <Badge variant={selectedAnswer === currentNote.name ? "default" : "destructive"}>
                    {selectedAnswer === currentNote.name ? "Correct!" : "Incorrect"}
                  </Badge>
                  {selectedAnswer !== currentNote.name && (
                    <p className="text-sm text-muted-foreground">
                      The correct answer is {currentNote.name}
                    </p>
                  )}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="sight-reading" className="space-y-4">
            <h3 className="text-lg font-semibold">Sight Reading Practice</h3>
            <p className="text-sm text-muted-foreground">
              Practice reading musical notation at tempo. Play the note shown on the staff.
            </p>
            
            {renderStaffNote(currentNote)}
            
            <div className="text-center space-y-4">
              <div className="text-sm text-muted-foreground">
                Play this note on your keyboard: <strong>{currentNote.name}{currentNote.octave}</strong>
              </div>
              <Button
                onClick={generateRandomNote}
                variant="outline"
                data-testid="button-next-note"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Next Note
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="symbols" className="space-y-4">
            <h3 className="text-lg font-semibold">Musical Symbols</h3>
            
            {renderSymbolDisplay(currentSymbol)}
            
            <div className="text-center space-y-3">
              <p className="text-sm text-muted-foreground">What is this musical symbol?</p>
              <div className="grid grid-cols-2 gap-2 max-w-md mx-auto">
                {symbolNames.map((name) => (
                  <Button
                    key={name}
                    onClick={() => handleAnswer(name)}
                    variant={selectedAnswer === name ? "default" : "outline"}
                    disabled={showAnswer}
                    className={cn(
                      "text-xs",
                      showAnswer && name === currentSymbol.name && "bg-green-500 hover:bg-green-600",
                      showAnswer && selectedAnswer === name && name !== currentSymbol.name && "bg-red-500 hover:bg-red-600"
                    )}
                    data-testid={`button-symbol-${name.replace(/\s+/g, '-').toLowerCase()}`}
                  >
                    {name}
                  </Button>
                ))}
              </div>
              
              {showAnswer && (
                <div className="mt-4 space-y-2">
                  <Badge variant={selectedAnswer === currentSymbol.name ? "default" : "destructive"}>
                    {selectedAnswer === currentSymbol.name ? "Correct!" : "Incorrect"}
                  </Badge>
                  <div className="text-sm text-muted-foreground max-w-md mx-auto">
                    <p><strong>{currentSymbol.name}:</strong> {currentSymbol.description}</p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        <div className="border-t pt-4">
          <h4 className="text-sm font-semibold mb-2">Quick Reference</h4>
          {currentClef === 'treble' ? (
            <div className="grid grid-cols-2 gap-4 text-xs text-muted-foreground">
              <div>
                <p><strong>Staff Lines (bottom to top):</strong></p>
                <p>E - G - B - D - F</p>
                <p><em>"Every Good Boy Does Fine"</em></p>
              </div>
              <div>
                <p><strong>Staff Spaces (bottom to top):</strong></p>
                <p>F - A - C - E</p>
                <p><em>"FACE"</em></p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 text-xs text-muted-foreground">
              <div>
                <p><strong>Staff Lines (bottom to top):</strong></p>
                <p>G - B - D - F - A</p>
                <p><em>"Good Boys Do Fine Always"</em></p>
              </div>
              <div>
                <p><strong>Staff Spaces (bottom to top):</strong></p>
                <p>A - C - E - G</p>
                <p><em>"All Cows Eat Grass"</em></p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}