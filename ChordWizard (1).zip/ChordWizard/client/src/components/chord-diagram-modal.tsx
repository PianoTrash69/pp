import { X, Play, Plus } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAudio } from '@/hooks/use-audio';
import { Chord } from '@/lib/music-theory';

interface ChordDiagramModalProps {
  chord: Chord | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToProgression: (chord: Chord) => void;
}

export function ChordDiagramModal({ chord, isOpen, onClose, onAddToProgression }: ChordDiagramModalProps) {
  const { playChord } = useAudio();

  if (!chord) return null;

  const handlePlayChord = async () => {
    await playChord(chord);
  };

  const handleAddToProgression = () => {
    onAddToProgression(chord);
    onClose();
  };

  const getFingerSuggestion = (chordNotes: string[]) => {
    // Simple finger suggestions for common chords
    if (chordNotes.length === 3) {
      return [
        `Thumb (1) - ${chordNotes[0]}`,
        `Middle (3) - ${chordNotes[1]}`,
        `Pinky (5) - ${chordNotes[2]}`
      ];
    }
    return chordNotes.map((note, index) => `${index + 1} - ${note}`);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md" data-testid="chord-diagram-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span data-testid="modal-chord-name">{chord.name} Chord</span>
            <Button variant="ghost" size="sm" onClick={onClose} data-testid="button-close-modal">
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <h4 className="text-sm font-medium text-muted-foreground mb-2">Piano Notes:</h4>
            <div className="flex space-x-2 text-sm">
              {chord.notes.map((note, index) => (
                <Badge key={index} variant="default">
                  {note}
                </Badge>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-muted-foreground mb-2">Suggested Fingering:</h4>
            <div className="text-sm text-card-foreground space-y-1">
              {getFingerSuggestion(chord.notes).map((suggestion, index) => (
                <div key={index}>{suggestion}</div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium text-muted-foreground mb-2">Chord Information:</h4>
            <div className="text-sm text-card-foreground space-y-1">
              <div>Root: {chord.root}</div>
              <div>Quality: {chord.quality}</div>
              <div>Roman Numeral: {chord.roman}</div>
              <div>Scale Degree: {chord.degree}</div>
            </div>
          </div>
          
          <div className="flex space-x-2 pt-2">
            <Button 
              onClick={handlePlayChord} 
              className="flex-1"
              data-testid="button-play-chord-modal"
            >
              <Play className="mr-2 h-4 w-4" />
              Play Chord
            </Button>
            <Button 
              onClick={handleAddToProgression} 
              variant="secondary" 
              className="flex-1"
              data-testid="button-add-to-progression-modal"
            >
              <Plus className="mr-2 h-4 w-4" />
              Add to Progression
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
