import { useState, useCallback, useEffect } from 'react';
import { Header } from '@/components/header';
import { FullPianoKeyboard } from '@/components/full-piano-keyboard';
import { useAudio } from '@/hooks/use-audio';
import { audioEngine } from '@/lib/audio';
import { ChordProgressionBuilder } from '@/components/chord-progression-builder';
import { ScaleSelector } from '@/components/scale-selector';
import { ChordLibrary } from '@/components/chord-library';
import { ChordDiagramModal } from '@/components/chord-diagram-modal';
import { QuickActions } from '@/components/quick-actions';
import { MusicAssistant } from '@/components/music-assistant';
import { TutorialSystem, useTutorial } from '@/components/tutorial-system';
import { MusicComposer } from '@/components/music-composer';
import { ChordOfTheDayComponent } from '@/components/chord-of-the-day';
import { MusicReadingTeacher } from '@/components/music-reading-teacher';
import { Metronome } from '@/components/metronome';
import { ReverseChordFinder } from '@/components/reverse-chord-finder';
import { ChordVoicingExplorer } from '@/components/chord-voicing-explorer';
import { PracticeMode } from '@/components/practice-mode';
import { useChordProgressions, ChordProgressionSlot } from '@/hooks/use-chord-progressions';
import { generateScale, Chord, scales, parseScaleValue } from '@/lib/music-theory';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Bot, Music, Heart, BookOpen, Headphones } from 'lucide-react';
import { DonateModal } from '@/components/donate-modal';

// Decode function for shared progressions
const decodeProgressionData = (encoded: string) => {
  try {
    // Handle URL decoding and normalize spaces back to plus for legacy compatibility
    const normalized = encoded.replace(/\s/g, '+');
    const compressed = JSON.parse(atob(normalized));
    return {
      chords: compressed.c || [],
      tempo: compressed.t || 120,
      scale: compressed.s || 'C-major',
      name: compressed.n
    };
  } catch (error) {
    console.error('Failed to decode progression data:', error);
    return null;
  }
};

export default function Home() {
  const [selectedScale, setSelectedScale] = useState('C-major');
  const [selectedChord, setSelectedChord] = useState<Chord | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [loadDialogOpen, setLoadDialogOpen] = useState(false);
  const [progressionName, setProgressionName] = useState('');
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [donateOpen, setDonateOpen] = useState(false);
  const [sharedProgressionName, setSharedProgressionName] = useState('');
  
  const { showTutorial, completeTutorial, skipTutorial } = useTutorial();
  
  const { 
    progression, 
    tempo,
    setTempo,
    addChordToSlot, 
    removeChordFromSlot,
    clearProgression,
    getFilledChords,
    saveProgression, 
    loadProgression, 
    getSavedProgressions,
    setProgression
  } = useChordProgressions();
  
  const { toast } = useToast();
  const { playNote } = useAudio();

  // Handle shared progressions from URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const progressionParam = urlParams.get('progression');
    
    if (progressionParam) {
      const progressionData = decodeProgressionData(progressionParam);
      if (progressionData) {
        try {
          // Set the scale to match the shared progression
          setSelectedScale(progressionData.scale);
          setSharedProgressionName(progressionData.name || 'Shared Progression');
          
          // Parse the scale and load progression synchronously
          const { root, mode } = parseScaleValue(progressionData.scale);
          const scale = generateScale(root, mode);
          
          // Convert chord names to Chord objects with fallback handling
          const chordObjects: Chord[] = [];
          const failedChords: string[] = [];
          
          progressionData.chords.forEach((chordName: string) => {
            const chord = scale.chords.find(c => c.name === chordName);
            if (chord) {
              chordObjects.push(chord);
            } else {
              failedChords.push(chordName);
            }
          });
          
          if (chordObjects.length > 0) {
            // Load the progression into the builder
            setProgression(prev => {
              return prev.map((slot, index) => {
                if (index < chordObjects.length) {
                  return { ...slot, chord: chordObjects[index] };
                }
                return { ...slot, chord: null };
              });
            });
            
            // Set the tempo
            setTempo(progressionData.tempo);
            
            const description = failedChords.length > 0 
              ? `${progressionData.name || 'Progression'} loaded. Some chords (${failedChords.join(', ')}) couldn't be mapped to the scale.`
              : `${progressionData.name || 'Progression'} has been loaded from the shared link.`;
            
            toast({
              title: "Shared Progression Loaded!",
              description,
              ...(failedChords.length > 0 && { variant: "default" })
            });
          } else {
            toast({
              title: "Error Loading Progression",
              description: `None of the chords in the shared progression (${progressionData.chords.join(', ')}) could be mapped to the ${progressionData.scale} scale.`,
              variant: "destructive"
            });
          }
        } catch (error) {
          console.error('Error loading shared progression:', error);
          toast({
            title: "Error Loading Progression",
            description: "The shared progression link appears to be invalid.",
            variant: "destructive"
          });
        }
        
        // Clean up URL
        const newUrl = window.location.pathname;
        window.history.replaceState({}, document.title, newUrl);
      } else {
        toast({
          title: "Invalid Link",
          description: "The shared progression link appears to be corrupted.",
          variant: "destructive"
        });
        
        // Clean up URL even on failure
        const newUrl = window.location.pathname;
        window.history.replaceState({}, document.title, newUrl);
      }
    }
  }, [setSelectedScale, setProgression, setTempo, toast]);

  let currentScale;
  try {
    const { root, mode } = parseScaleValue(selectedScale);
    currentScale = generateScale(root, mode);
  } catch (error) {
    console.error('Error parsing scale:', selectedScale, error);
    // Fallback to C Major
    currentScale = generateScale('C', 'major');
  }
  const savedProgressions = getSavedProgressions();

  const handleChordDrop = useCallback((slotId: number, chord: Chord) => {
    const slot = progression.find(s => s.id === slotId);
    if (slot?.chord) {
      // If slot has chord, remove it
      removeChordFromSlot(slotId);
    } else {
      // If slot is empty, add chord
      addChordToSlot(slotId, chord);
    }
  }, [progression, addChordToSlot, removeChordFromSlot]);

  const handleShowDiagram = (chord: Chord) => {
    setSelectedChord(chord);
    setIsModalOpen(true);
  };

  const handleAddToProgression = (chord: Chord) => {
    // Find first empty slot
    const emptySlot = progression.find(slot => slot.chord === null);
    if (emptySlot) {
      addChordToSlot(emptySlot.id, chord);
      toast({
        title: "Chord Added",
        description: `${chord.name} added to progression`,
      });
    } else {
      toast({
        title: "Progression Full",
        description: "All slots are filled. Remove a chord first.",
        variant: "destructive"
      });
    }
  };

  const handleSaveProgression = () => {
    setSaveDialogOpen(true);
  };

  const handleConfirmSave = () => {
    if (!progressionName.trim()) {
      toast({
        title: "Name Required",
        description: "Please enter a name for your progression",
        variant: "destructive"
      });
      return;
    }

    const success = saveProgression(progressionName);
    if (success) {
      toast({
        title: "Progression Saved",
        description: `"${progressionName}" has been saved successfully`,
      });
      setProgressionName('');
      setSaveDialogOpen(false);
    } else {
      toast({
        title: "Save Failed",
        description: "No chords in progression to save",
        variant: "destructive"
      });
    }
  };

  const handleLoadProgression = () => {
    setLoadDialogOpen(true);
  };

  const handleConfirmLoad = (progressionData: any) => {
    loadProgression(progressionData, currentScale.chords);
    toast({
      title: "Progression Loaded",
      description: `"${progressionData.name}" has been loaded`,
    });
    setLoadDialogOpen(false);
  };

  const handleQuickProgression = (chordNames: string[]) => {
    // Get the actual chord objects from the current scale
    const progressionChords: (Chord | null)[] = chordNames.map(chordName => {
      const found = currentScale.chords.find(c => c.name === chordName);
      if (!found) {
        // Try to find by root note and basic type as fallback
        const fallback = currentScale.chords.find(c => 
          c.root === chordName.split(' ')[0] && c.variant === 'triad'
        );
        if (fallback) {
          return fallback;
        }
      }
      return found || null;
    });

    // Update progression state directly using atomic update
    setProgression((prev: ChordProgressionSlot[]) => {
      return prev.map((slot: ChordProgressionSlot, index: number) => {
        if (index < progressionChords.length && progressionChords[index]) {
          return { ...slot, chord: progressionChords[index] };
        }
        return { ...slot, chord: null };
      });
    });

    const actualChordNames = progressionChords
      .filter(c => c !== null)
      .map(c => c!.name);

    toast({
      title: "Quick Progression Loaded",
      description: `${actualChordNames.join(' - ')} progression loaded`,
    });
  };

  const handlePlayChordOfTheDay = async (notes: string[]) => {
    try {
      await audioEngine.playChord(notes, 4, '2n');
    } catch (error) {
      console.error('Error playing chord:', error);
      toast({
        title: "Audio Error",
        description: "Failed to play chord. Try clicking to enable audio.",
        variant: "destructive"
      });
    }
  };

  const handlePlayReadingNote = async (note: string, octave: number) => {
    try {
      audioEngine.noteOn(note, octave, 0.8);
      setTimeout(() => {
        audioEngine.noteOff(note, octave);
      }, 1000);
    } catch (error) {
      console.error('Error playing note:', error);
      toast({
        title: "Audio Error",
        description: "Failed to play note. Try clicking to enable audio.",
        variant: "destructive"
      });
    }
  };

  const handlePlayChordFromFinder = async (notes: string[]) => {
    try {
      await audioEngine.playChord(notes, 4, '2n');
    } catch (error) {
      console.error('Error playing chord:', error);
      toast({
        title: "Audio Error",
        description: "Failed to play chord. Try clicking to enable audio.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="mobile-container mobile-full-height bg-background">
      <div className="mobile-sticky-header">
        <Header 
          onSave={handleSaveProgression} 
          onLoad={handleLoadProgression}
          onDonate={() => setDonateOpen(true)}
        />
      </div>
      
      <main className="mobile-container p-4 sm:p-6 flex-1 overflow-hidden">
        <div className="mobile-layout h-full">
          <Tabs defaultValue="chord-builder" className="mobile-tabs w-full h-full flex flex-col">
            <TabsList className="grid w-full grid-cols-5 shrink-0">
              <TabsTrigger value="chord-builder" data-testid="tab-chord-builder" className="text-xs sm:text-sm">
                🎵 <span className="hidden sm:inline">Chord Builder</span><span className="sm:hidden">Chords</span>
              </TabsTrigger>
              <TabsTrigger value="composer" data-testid="tab-composer" className="text-xs sm:text-sm">
                <Music className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">Composer</span><span className="sm:hidden">Piano</span>
              </TabsTrigger>
              <TabsTrigger value="reading" data-testid="tab-reading" className="text-xs sm:text-sm">
                <BookOpen className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">Music Reading</span><span className="sm:hidden">Reading</span>
              </TabsTrigger>
              <TabsTrigger value="practice" data-testid="tab-practice" className="text-xs sm:text-sm">
                <Headphones className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">Practice</span><span className="sm:hidden">Practice</span>
              </TabsTrigger>
              <TabsTrigger value="assistant" data-testid="tab-assistant" className="text-xs sm:text-sm">
                <Bot className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">AI Assistant</span><span className="sm:hidden">AI</span>
              </TabsTrigger>
            </TabsList>
          
          <TabsContent value="chord-builder" className="flex-1 overflow-auto mt-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Piano and Progression Section */}
              <div className="lg:col-span-2 space-y-6">
                <FullPianoKeyboard 
                  onNoteOn={async (note, octave, velocity) => {
                    try {
                      audioEngine.noteOn(note, octave, velocity);
                    } catch (error) {
                      console.error('Error playing note:', error);
                      toast({
                        title: "Audio Error",
                        description: "Failed to play note. Try clicking to enable audio.",
                        variant: "destructive"
                      });
                    }
                  }}
                  onNoteOff={(note, octave) => {
                    audioEngine.noteOff(note, octave);
                  }}
                  sustainEnabled={false}
                  autoSustainMs={500}
                  onSustainEnabledChange={(enabled) => {
                    audioEngine.setSustainEnabled(enabled);
                  }}
                  onAutoSustainMsChange={(ms) => {
                    audioEngine.setAutoSustainMs(ms);
                  }}
                />
                <ChordProgressionBuilder 
                  progression={progression}
                  tempo={tempo}
                  setTempo={setTempo}
                  clearProgression={clearProgression}
                  onDrop={handleChordDrop}
                  scale={selectedScale}
                  progressionName={sharedProgressionName || progressionName}
                />
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                <ScaleSelector
                  selectedScale={selectedScale}
                  onScaleChange={setSelectedScale}
                  currentScale={currentScale}
                />
                
                <ChordLibrary
                  chords={currentScale.chords}
                  onShowDiagram={handleShowDiagram}
                />
                
                <ChordVoicingExplorer
                  selectedChord={selectedChord}
                  onPlayVoicing={async (notes) => {
                    try {
                      for (const note of notes) {
                        audioEngine.noteOn(note.note, note.octave, 0.7);
                      }
                      setTimeout(() => {
                        for (const note of notes) {
                          audioEngine.noteOff(note.note, note.octave);
                        }
                      }, 2000);
                    } catch (error) {
                      console.error('Error playing voicing:', error);
                      toast({
                        title: "Audio Error",
                        description: "Failed to play voicing. Try clicking to enable audio.",
                        variant: "destructive"
                      });
                    }
                  }}
                />
                
                <QuickActions
                  scale={currentScale}
                  onLoadProgression={handleQuickProgression}
                />
                
                {/* Chord of the Day */}
                <ChordOfTheDayComponent 
                  onPlayChord={handlePlayChordOfTheDay}
                  className="chord-of-the-day-card"
                />
                
                {/* Metronome */}
                <Metronome className="metronome-card" />
                
                {/* Reverse Chord Finder */}
                <ReverseChordFinder 
                  onPlayChord={handlePlayChordFromFinder}
                  className="reverse-chord-finder-card"
                />
                
                {/* Music Assistant Button */}
                <div className="bg-card rounded-xl p-4 border border-border shadow-sm">
                  <h3 className="text-lg font-semibold text-card-foreground mb-3">Music Theory Helper</h3>
                  <Button 
                    onClick={() => setAssistantOpen(true)}
                    className="w-full"
                    data-testid="button-open-assistant"
                  >
                    <Bot className="h-4 w-4 mr-2" />
                    Ask Music Theory Questions
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="composer" className="flex-1 overflow-auto mt-4">
            <MusicComposer />
          </TabsContent>
          
          <TabsContent value="reading" className="flex-1 overflow-auto mt-4">
            <MusicReadingTeacher 
              onPlayNote={handlePlayReadingNote}
              className="max-w-4xl mx-auto"
            />
          </TabsContent>
          
          <TabsContent value="practice" className="flex-1 overflow-auto mt-4">
            <PracticeMode
              onPlayNotes={async (notes, isChord = false) => {
                try {
                  if (isChord) {
                    for (const note of notes) {
                      audioEngine.noteOn(note.note, note.octave, 0.7);
                    }
                    setTimeout(() => {
                      for (const note of notes) {
                        audioEngine.noteOff(note.note, note.octave);
                      }
                    }, 2000);
                  } else {
                    for (const note of notes) {
                      audioEngine.noteOn(note.note, note.octave, 0.8);
                      setTimeout(() => {
                        audioEngine.noteOff(note.note, note.octave);
                      }, 1000);
                    }
                  }
                } catch (error) {
                  console.error('Error playing notes:', error);
                  toast({
                    title: "Audio Error",
                    description: "Failed to play notes. Try clicking to enable audio.",
                    variant: "destructive"
                  });
                }
              }}
              scale={selectedScale}
              className="max-w-4xl mx-auto"
            />
          </TabsContent>
          
          
          <TabsContent value="assistant" className="flex-1 overflow-auto mt-4">
            <MusicAssistant 
              currentScale={currentScale}
              currentChords={getFilledChords().map(chord => chord.name)}
              onClose={() => {}}
            />
          </TabsContent>
        </Tabs>
        </div>
      </main>

      {/* Chord Diagram Modal */}
      <ChordDiagramModal
        chord={selectedChord}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAddToProgression={handleAddToProgression}
      />

      {/* Save Dialog */}
      <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Chord Progression</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Enter progression name..."
              value={progressionName}
              onChange={(e) => setProgressionName(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleConfirmSave()}
              data-testid="input-progression-name"
            />
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setSaveDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleConfirmSave} data-testid="button-confirm-save">
                Save
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Load Dialog */}
      <Dialog open={loadDialogOpen} onOpenChange={setLoadDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Load Chord Progression</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {savedProgressions.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                No saved progressions found
              </p>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {savedProgressions.map((prog: any, index: number) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="w-full text-left justify-start h-auto p-3"
                    onClick={() => handleConfirmLoad(prog)}
                    data-testid={`button-load-progression-${index}`}
                  >
                    <div>
                      <div className="font-medium">{prog.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {prog.chords.join(' - ')} • {prog.tempo} BPM
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            )}
            <div className="flex justify-end">
              <Button variant="outline" onClick={() => setLoadDialogOpen(false)}>
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Music Assistant Dialog */}
      <Dialog open={assistantOpen} onOpenChange={setAssistantOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
          <MusicAssistant
            currentScale={currentScale}
            currentChords={getFilledChords().map(chord => chord.name)}
            onClose={() => setAssistantOpen(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Donation Modal */}
      <DonateModal 
        open={donateOpen} 
        onOpenChange={setDonateOpen} 
      />

      {/* Tutorial System */}
      {showTutorial && (
        <TutorialSystem
          onComplete={completeTutorial}
          onSkip={skipTutorial}
        />
      )}
    </div>
  );
}
