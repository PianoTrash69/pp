export interface Chord {
  name: string;
  root: string;
  type: string;
  notes: string[];
  roman: string;
  degree: number;
  quality: 'major' | 'minor' | 'diminished' | 'augmented';
  variant: 'triad' | 'seventh' | 'sus2' | 'sus4' | 'add9' | 'sixth';
}

export interface Scale {
  name: string;
  notes: string[];
  chords: Chord[];
  mode: string;
}

const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

const scaleIntervals = {
  major: [2, 2, 1, 2, 2, 2, 1],
  minor: [2, 1, 2, 2, 1, 2, 2],
  dorian: [2, 1, 2, 2, 2, 1, 2],
  phrygian: [1, 2, 2, 2, 1, 2, 2],
  lydian: [2, 2, 2, 1, 2, 2, 1],
  mixolydian: [2, 2, 1, 2, 2, 1, 2],
  locrian: [1, 2, 2, 1, 2, 2, 2],
  'harmonic-minor': [2, 1, 2, 2, 1, 3, 1],
  'melodic-minor': [2, 1, 2, 2, 2, 2, 1]
};

const chordQualities = {
  major: ['major', 'minor', 'minor', 'major', 'major', 'minor', 'diminished'],
  minor: ['minor', 'diminished', 'major', 'minor', 'minor', 'major', 'major'],
  dorian: ['minor', 'minor', 'major', 'major', 'minor', 'diminished', 'major'],
  phrygian: ['minor', 'major', 'major', 'minor', 'diminished', 'major', 'minor'],
  lydian: ['major', 'major', 'minor', 'diminished', 'major', 'minor', 'minor'],
  mixolydian: ['major', 'minor', 'diminished', 'major', 'minor', 'minor', 'major'],
  locrian: ['diminished', 'major', 'minor', 'minor', 'major', 'major', 'minor'],
  'harmonic-minor': ['minor', 'diminished', 'augmented', 'minor', 'major', 'major', 'diminished'],
  'melodic-minor': ['minor', 'minor', 'augmented', 'major', 'major', 'diminished', 'diminished']
};

const romanNumerals = {
  major: ['I', 'ii', 'iii', 'IV', 'V', 'vi', 'vii°'],
  minor: ['i', 'ii°', 'III', 'iv', 'v', 'VI', 'VII'],
  dorian: ['i', 'ii', 'III', 'IV', 'v', 'vi°', 'VII'],
  phrygian: ['i', 'II', 'III', 'iv', 'v°', 'VI', 'vii'],
  lydian: ['I', 'II', 'iii', 'iv°', 'V', 'vi', 'vii'],
  mixolydian: ['I', 'ii', 'iii°', 'IV', 'v', 'vi', 'VII'],
  locrian: ['i°', 'II', 'iii', 'iv', 'V', 'VI', 'vii'],
  'harmonic-minor': ['i', 'ii°', 'III+', 'iv', 'V', 'VI', 'vii°'],
  'melodic-minor': ['i', 'ii', 'III+', 'IV', 'V', 'vi°', 'vii°']
};

function getNoteIndex(note: string): number {
  return noteNames.indexOf(note);
}

function getNoteName(index: number): string {
  return noteNames[index % 12];
}

function buildDiatonicChord(scaleNotes: string[], degree: number, degreeOffsets: number[]): string[] {
  return degreeOffsets.map(offset => scaleNotes[(degree + offset) % scaleNotes.length]);
}

export function generateScale(root: string, mode: keyof typeof scaleIntervals): Scale {
  const intervals = scaleIntervals[mode];
  const qualities = chordQualities[mode];
  const romans = romanNumerals[mode];
  
  const notes: string[] = [];
  const chords: Chord[] = [];
  
  let currentIndex = getNoteIndex(root);
  notes.push(getNoteName(currentIndex));
  
  // Generate scale notes
  for (let i = 0; i < intervals.length - 1; i++) {
    currentIndex = (currentIndex + intervals[i]) % 12;
    notes.push(getNoteName(currentIndex));
  }
  
  // Generate chords organized by type: triads first, then 7ths, then 9ths, etc.
  
  // 1. Generate all triads in scale order
  notes.forEach((note, degree) => {
    const quality = qualities[degree];
    const roman = romans[degree];
    const triadNotes = generateChordNotes(note, quality);
    chords.push({
      name: `${note} ${quality.charAt(0).toUpperCase() + quality.slice(1)}`,
      root: note,
      type: quality,
      notes: triadNotes,
      roman: roman,
      degree: degree + 1,
      quality: quality as 'major' | 'minor' | 'diminished' | 'augmented',
      variant: 'triad'
    });
  });
  
  // 2. Generate all 7th chords in scale order
  notes.forEach((note, degree) => {
    const quality = qualities[degree];
    const roman = romans[degree];
    const seventhNotes = buildDiatonicChord(notes, degree, [0, 2, 4, 6]);
    const seventhType = getSeventhType(quality, note, seventhNotes[3]);
    const seventhRoman = seventhType === 'maj7' ? `${roman}maj7` : 
                         seventhType === 'mMaj7' ? `${roman}maj7` :
                         seventhType === 'm7b5' ? `${roman.replace('°', 'ø')}7` : 
                         seventhType === 'dim7' ? `${roman.replace('°', '')}°7` :
                         seventhType === '+maj7' ? `${roman.endsWith('+') ? roman : roman + '+'}maj7` :
                         seventhType === '+7' ? `${roman.endsWith('+') ? roman : roman + '+'}7` :
                         `${roman}7`;
    chords.push({
      name: `${note}${seventhType}`,
      root: note,
      type: seventhType,
      notes: seventhNotes,
      roman: seventhRoman,
      degree: degree + 1,
      quality: quality as 'major' | 'minor' | 'diminished' | 'augmented',
      variant: 'seventh'
    });
  });
  
  // 3. Generate all add9 chords in scale order
  notes.forEach((note, degree) => {
    const quality = qualities[degree];
    const roman = romans[degree];
    const add9Notes = buildDiatonicChord(notes, degree, [0, 2, 4, 1]);
    chords.push({
      name: `${note}add9`,
      root: note,
      type: 'add9',
      notes: add9Notes,
      roman: `${roman}add9`,
      degree: degree + 1,
      quality: quality as 'major' | 'minor' | 'diminished' | 'augmented',
      variant: 'add9'
    });
  });
  
  // 4. Generate other chord variants in scale order
  notes.forEach((note, degree) => {
    const quality = qualities[degree];
    const roman = romans[degree];
    
    // Sus2 chords
    const sus2Notes = buildDiatonicChord(notes, degree, [0, 1, 4]);
    chords.push({
      name: `${note}sus2`,
      root: note,
      type: 'sus2',
      notes: sus2Notes,
      roman: `${roman}sus2`,
      degree: degree + 1,
      quality: quality as 'major' | 'minor' | 'diminished' | 'augmented',
      variant: 'sus2'
    });
    
    // Sus4 chords
    const sus4Notes = buildDiatonicChord(notes, degree, [0, 3, 4]);
    chords.push({
      name: `${note}sus4`,
      root: note,
      type: 'sus4',
      notes: sus4Notes,
      roman: `${roman}sus4`,
      degree: degree + 1,
      quality: quality as 'major' | 'minor' | 'diminished' | 'augmented',
      variant: 'sus4'
    });
    
    // 6th chords
    const sixthNotes = buildDiatonicChord(notes, degree, [0, 2, 4, 5]);
    chords.push({
      name: `${note}6`,
      root: note,
      type: '6',
      notes: sixthNotes,
      roman: `${roman}6`,
      degree: degree + 1,
      quality: quality as 'major' | 'minor' | 'diminished' | 'augmented',
      variant: 'sixth'
    });
  });
  
  return {
    name: `${root} ${mode.charAt(0).toUpperCase() + mode.slice(1)}`,
    notes,
    chords,
    mode
  };
}

function generateChordNotes(root: string, quality: string): string[] {
  const rootIndex = getNoteIndex(root);
  const notes = [root];
  
  switch (quality) {
    case 'major':
      notes.push(getNoteName((rootIndex + 4) % 12));
      notes.push(getNoteName((rootIndex + 7) % 12));
      break;
    case 'minor':
      notes.push(getNoteName((rootIndex + 3) % 12));
      notes.push(getNoteName((rootIndex + 7) % 12));
      break;
    case 'diminished':
      notes.push(getNoteName((rootIndex + 3) % 12));
      notes.push(getNoteName((rootIndex + 6) % 12));
      break;
    case 'augmented':
      notes.push(getNoteName((rootIndex + 4) % 12));
      notes.push(getNoteName((rootIndex + 8) % 12));
      break;
  }
  
  return notes;
}


function getSeventhType(triadQuality: string, rootNote: string, seventhNote: string): string {
  // Calculate the actual semitone distance between root and seventh
  const rootIndex = getNoteIndex(rootNote);
  const seventhIndex = getNoteIndex(seventhNote);
  const semitoneDistance = (seventhIndex - rootIndex + 12) % 12;
  
  // Determine seventh type based on triad quality and actual 7th interval
  switch (triadQuality) {
    case 'major':
      return semitoneDistance === 11 ? 'maj7' : '7'; // maj7 for major 7th, 7 for minor 7th
    case 'minor':
      return semitoneDistance === 11 ? 'mMaj7' : 'm7'; // minor-major 7th vs minor 7th
    case 'diminished':
      return semitoneDistance === 10 ? 'm7b5' : 'dim7'; // half-dim vs fully diminished
    case 'augmented':
      return semitoneDistance === 11 ? '+maj7' : '+7';
    default:
      return '7';
  }
}

export const commonProgressions = {
  'vi-IV-I-V': ['vi', 'IV', 'I', 'V'],
  'I-V-vi-IV': ['I', 'V', 'vi', 'IV'],
  'ii-V-I': ['ii', 'V', 'I'],
  'I-vi-IV-V': ['I', 'vi', 'IV', 'V'],
  'vi-ii-V-I': ['vi', 'ii', 'V', 'I'],
  'iii-vi-ii-V': ['iii', 'vi', 'ii', 'V'],
  'I-iii-vi-IV': ['I', 'iii', 'vi', 'IV'],
  'vi-V-IV-V': ['vi', 'V', 'IV', 'V'],
  'I-IV-vi-V': ['I', 'IV', 'vi', 'V'],
  'ii-vi-I-V': ['ii', 'vi', 'I', 'V'],
  'I-vi-ii-V': ['I', 'vi', 'ii', 'V'],
  'iii-IV-I-vi': ['iii', 'IV', 'I', 'vi']
};

export function getChordFromRoman(roman: string, scale: Scale): Chord | undefined {
  return scale.chords.find(chord => chord.roman === roman);
}

// Helper function to extract scale degree from Roman numeral
function getScaleDegree(roman: string): number {
  const romanNumerals = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];
  // Handle both uppercase and lowercase, remove quality indicators
  const cleanRoman = roman.replace(/[^IVXivx]/g, '').toUpperCase();
  
  // Map roman numerals to degrees
  const degreeMap: { [key: string]: number } = {
    'I': 1, 'II': 2, 'III': 3, 'IV': 4, 'V': 5, 'VI': 6, 'VII': 7
  };
  
  return degreeMap[cleanRoman] || 0;
}

// Smart chord mapping that finds the best available chord at each scale degree
export function getChordFromRomanSmart(roman: string, scale: Scale): Chord | undefined {
  // First try exact match
  let found = scale.chords.find(chord => chord.roman === roman);
  if (found) return found;
  
  // If no exact match, find chord at the same scale degree
  const targetDegree = getScaleDegree(roman);
  if (targetDegree > 0) {
    // Look for any chord (triad variant preferred) at this scale degree
    found = scale.chords.find(chord => 
      chord.degree === targetDegree && chord.variant === 'triad'
    );
    if (found) return found;
    
    // Fallback: any chord at this degree
    found = scale.chords.find(chord => chord.degree === targetDegree);
    if (found) return found;
  }
  
  return undefined;
}

export function getProgressionChords(progressionKey: keyof typeof commonProgressions, scale: Scale): Chord[] {
  const romans = commonProgressions[progressionKey];
  
  const chords = romans.map(roman => {
    const found = getChordFromRomanSmart(roman, scale);
    if (!found) {
      console.warn(`No chord found for degree ${getScaleDegree(roman)} (${roman}) in scale`);
    }
    return found;
  }).filter(Boolean) as Chord[];
  
  return chords;
}

export const scales = Object.keys(scaleIntervals) as Array<keyof typeof scaleIntervals>;

// Dissonance ordering from least to most dissonant
const dissonanceOrder = [
  'major',           // Most consonant
  'minor', 
  'dorian',
  'mixolydian',
  'lydian',
  'phrygian',
  'melodic-minor',
  'harmonic-minor',
  'locrian'          // Most dissonant
] as const;

// Generate all scales for all 12 chromatic notes, ordered by dissonance
export function getAllScales(): Array<{value: string, label: string, root: string, mode: string, dissonance: number}> {
  const allScales: Array<{value: string, label: string, root: string, mode: string, dissonance: number}> = [];
  
  // For each dissonance level (least to most dissonant)
  dissonanceOrder.forEach((mode, dissonanceLevel) => {
    // For each chromatic note
    noteNames.forEach(root => {
      const modeName = mode === 'harmonic-minor' ? 'Harmonic Minor' :
                       mode === 'melodic-minor' ? 'Melodic Minor' :
                       mode.charAt(0).toUpperCase() + mode.slice(1);
      
      allScales.push({
        value: `${root}-${mode}`,
        label: `${root} ${modeName}`,
        root,
        mode,
        dissonance: dissonanceLevel
      });
    });
  });
  
  return allScales;
}

// Helper function to parse scale value back to root and mode
export function parseScaleValue(scaleValue: string): {root: string, mode: keyof typeof scaleIntervals} {
  const parts = scaleValue.split('-');
  const root = parts[0];
  const mode = parts.slice(1).join('-') as keyof typeof scaleIntervals;
  return { root, mode };
}
