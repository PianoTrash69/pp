export interface ChordOfTheDay {
  id: string;
  name: string;
  symbol: string;
  notes: string[];
  intervals: string[];
  quality: string;
  mood: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  history: string;
  musicalProperties: string;
  famousUses: string[];
  funFacts: string[];
}

export const interestingChords: ChordOfTheDay[] = [
  {
    id: 'cmaj7',
    name: 'C Major 7th',
    symbol: 'Cmaj7',
    notes: ['C', 'E', 'G', 'B'],
    intervals: ['Root', 'Major 3rd', 'Perfect 5th', 'Major 7th'],
    quality: 'Major 7th',
    mood: 'Dreamy, sophisticated, jazzy',
    difficulty: 'Intermediate',
    history: 'The major 7th chord became prominent in jazz during the 1920s and 1930s. It was revolutionary because it added color and sophistication to traditional major chords, creating a more modern sound that defined the jazz age.',
    musicalProperties: 'Contains no tritone, making it very stable and consonant. The major 7th interval (11 semitones) creates a gentle dissonance that resolves beautifully.',
    famousUses: [
      '"Girl from Ipanema" by Antonio Carlos Jobim',
      '"Fly Me to the Moon" by Frank Sinatra',
      '"Just the Way You Are" by Billy Joel'
    ],
    funFacts: [
      'Often called the "dreamy chord" in jazz circles',
      'The Beatles used it extensively in their later albums',
      'Creates an "unfinished" feeling that keeps listeners engaged'
    ]
  },
  {
    id: 'dm7b5',
    name: 'D Half-Diminished 7th',
    symbol: 'Dm7♭5',
    notes: ['D', 'F', 'Ab', 'C'],
    intervals: ['Root', 'Minor 3rd', 'Diminished 5th', 'Minor 7th'],
    quality: 'Half-Diminished 7th',
    mood: 'Mysterious, dark, contemplative',
    difficulty: 'Advanced',
    history: 'This chord gained prominence in classical harmony during the Romantic era (1800s) and became essential in jazz as the ii chord in minor keys. Chopin and Liszt used it to create emotional depth.',
    musicalProperties: 'Contains a tritone between the 3rd and 7th, creating harmonic tension. The diminished 5th gives it an unstable, searching quality that demands resolution.',
    famousUses: [
      'Chopin\'s "Ballade No. 1"',
      '"Autumn Leaves" (jazz standard)',
      '"The Girl from Ipanema" (bridge section)'
    ],
    funFacts: [
      'Often called the "Locrian chord" in modal jazz',
      'Essential for playing jazz ballads convincingly',
      'Creates the perfect "question" that needs an "answer" chord'
    ]
  },
  {
    id: 'gsus4',
    name: 'G Suspended 4th',
    symbol: 'Gsus4',
    notes: ['G', 'C', 'D'],
    intervals: ['Root', 'Perfect 4th', 'Perfect 5th'],
    quality: 'Suspended',
    mood: 'Hopeful, anticipatory, open',
    difficulty: 'Beginner',
    history: 'Suspended chords date back to medieval times and were originally called "retardation." They became popular in folk and rock music in the 1960s, creating that "hanging" feeling that made songs more emotionally engaging.',
    musicalProperties: 'Lacks a third, making it neither major nor minor. The 4th creates tension that naturally wants to resolve down to the 3rd, making it perfect for creating anticipation.',
    famousUses: [
      '"Pinball Wizard" by The Who',
      '"Here Comes the Sun" by The Beatles',
      '"Free Fallin\'" by Tom Petty'
    ],
    funFacts: [
      'The word "sus" comes from "suspended"',
      'Creates instant emotional pull in pop songs',
      'Used heavily in Celtic and folk music for centuries'
    ]
  },
  {
    id: 'eaug',
    name: 'E Augmented',
    symbol: 'E+',
    notes: ['E', 'G#', 'C'],
    intervals: ['Root', 'Major 3rd', 'Augmented 5th'],
    quality: 'Augmented',
    mood: 'Mysterious, unsettling, dreamlike',
    difficulty: 'Intermediate',
    history: 'Debussy and other Impressionist composers (1890s-1920s) used augmented chords to create dreamy, floating harmonies. They break traditional harmonic rules, creating music that sounds like it\'s "suspended in air."',
    musicalProperties: 'Symmetrical structure - every note is a major third apart. This creates harmonic ambiguity as any of the three notes can be heard as the root.',
    famousUses: [
      'Debussy\'s "Clair de Lune"',
      '"Oh Darling" by The Beatles',
      'Many Disney villain songs'
    ],
    funFacts: [
      'Can be built from any of its three notes',
      'Only 4 unique augmented chords exist due to symmetry',
      'Often used in film scores to suggest magic or mystery'
    ]
  },
  {
    id: 'f7',
    name: 'F Dominant 7th',
    symbol: 'F7',
    notes: ['F', 'A', 'C', 'Eb'],
    intervals: ['Root', 'Major 3rd', 'Perfect 5th', 'Minor 7th'],
    quality: 'Dominant 7th',
    mood: 'Bluesy, driving, authoritative',
    difficulty: 'Intermediate',
    history: 'The dominant 7th chord is the backbone of blues music, dating back to the early 1900s. It creates the characteristic "blues sound" and became essential in jazz, rock, and countless other genres.',
    musicalProperties: 'Contains a tritone between the 3rd and 7th (the "devil\'s interval"), creating strong harmonic tension that demands resolution. This tension-release cycle drives most Western music.',
    famousUses: [
      'Traditional 12-bar blues progression',
      '"Sweet Home Chicago" by Robert Johnson',
      '"I Got Rhythm" by George Gershwin'
    ],
    funFacts: [
      'The tritone was banned by the Catholic Church in medieval times',
      'Essential for authentic blues and jazz playing',
      'Creates the strongest harmonic pull in tonal music'
    ]
  },
  {
    id: 'amaj9',
    name: 'A Major 9th',
    symbol: 'Amaj9',
    notes: ['A', 'C#', 'E', 'G#', 'B'],
    intervals: ['Root', 'Major 3rd', 'Perfect 5th', 'Major 7th', 'Major 9th'],
    quality: 'Major 9th',
    mood: 'Lush, sophisticated, colorful',
    difficulty: 'Advanced',
    history: 'Extended chords like the maj9 emerged in jazz during the bebop era (1940s). Musicians like Charlie Parker and Dizzy Gillespie used these complex harmonies to create more sophisticated and colorful music.',
    musicalProperties: 'A 5-note chord that spans more than an octave. The 9th (same as the 2nd) adds brightness and color without creating harsh dissonance, making it incredibly versatile.',
    famousUses: [
      '"Giant Steps" by John Coltrane',
      '"Misty" by Erroll Garner',
      'Modern R&B and neo-soul progressions'
    ],
    funFacts: [
      'Often omits the 5th when played on piano',
      'Became signature sound of smooth jazz in the 1980s',
      'Creates instant "professional" sound in chord progressions'
    ]
  },
  {
    id: 'bdim7',
    name: 'B Diminished 7th',
    symbol: 'B°7',
    notes: ['B', 'D', 'F', 'Ab'],
    intervals: ['Root', 'Minor 3rd', 'Diminished 5th', 'Diminished 7th'],
    quality: 'Fully Diminished 7th',
    mood: 'Spooky, mysterious, dramatic',
    difficulty: 'Advanced',
    history: 'Classical composers used diminished 7th chords to create drama and tension. Bach, Mozart, and especially Wagner employed them for their ability to create uncertainty and lead to unexpected harmonic destinations.',
    musicalProperties: 'Perfectly symmetrical - every interval is a minor third. This symmetry means it can resolve to multiple different chords, making it incredibly useful for modulation and creating surprise.',
    famousUses: [
      'Bach\'s "The Well-Tempered Clavier"',
      'Horror movie soundtracks',
      '"Moonlight Sonata" by Beethoven'
    ],
    funFacts: [
      'Only 3 unique diminished 7th chords exist due to symmetry',
      'Called the "nightmare chord" in film scoring',
      'Can function as 4 different chords depending on context'
    ]
  },
  {
    id: 'cadd9',
    name: 'C Add 9',
    symbol: 'Cadd9',
    notes: ['C', 'E', 'G', 'D'],
    intervals: ['Root', 'Major 3rd', 'Perfect 5th', 'Major 9th'],
    quality: 'Added Tone',
    mood: 'Bright, uplifting, modern',
    difficulty: 'Beginner',
    history: 'The add9 chord became popular in folk and pop music during the 1960s. Artists like The Beatles and Joni Mitchell used it to add color to simple major chords without the complexity of full jazz extensions.',
    musicalProperties: 'Adds the bright color of the 9th without the sophistication of the 7th. This makes it more accessible than jazz chords while still providing harmonic interest.',
    famousUses: [
      '"Wonderwall" by Oasis',
      '"Tears in Heaven" by Eric Clapton',
      '"Black" by Pearl Jam'
    ],
    funFacts: [
      'The "campfire chord" that makes acoustic guitars sound professional',
      'Creates instant emotional connection in ballads',
      'Often the first "jazz chord" beginners learn'
    ]
  },
  {
    id: 'em11',
    name: 'E Minor 11th',
    symbol: 'Em11',
    notes: ['E', 'G', 'B', 'D', 'A'],
    intervals: ['Root', 'Minor 3rd', 'Perfect 5th', 'Minor 7th', 'Perfect 11th'],
    quality: 'Minor 11th',
    mood: 'Ethereal, spacious, contemplative',
    difficulty: 'Advanced',
    history: 'Extended minor chords became prominent in modal jazz (1950s-60s) through the work of Miles Davis and Bill Evans. They create vast harmonic spaces that suggest rather than define specific emotions.',
    musicalProperties: 'The 11th (same as the 4th) creates harmonic ambiguity and spaciousness. In minor chords, this extension creates a floating, meditative quality perfect for modal music.',
    famousUses: [
      '"So What" by Miles Davis',
      'Bill Evans\' piano interpretations',
      'Modern ambient and post-rock music'
    ],
    funFacts: [
      'Defines the sound of modal jazz',
      'Creates "open" harmonies that breathe',
      'Popular in meditation and ambient music'
    ]
  },
  {
    id: 'db13',
    name: 'D♭ Dominant 13th',
    symbol: 'D♭13',
    notes: ['Db', 'F', 'Ab', 'B', 'Bb'],
    intervals: ['Root', 'Major 3rd', 'Perfect 5th', 'Minor 7th', 'Major 13th'],
    quality: 'Dominant 13th',
    mood: 'Sophisticated, colorful, funky',
    difficulty: 'Advanced',
    history: 'The 13th chord reached its peak in 1970s funk and fusion music. Musicians like Herbie Hancock and Chick Corea used these rich harmonies to create the complex, colorful sound that defined the era.',
    musicalProperties: 'Contains 6 different notes spanning nearly two octaves. The 13th adds brightness and complexity while maintaining the dominant function that creates forward motion in progressions.',
    famousUses: [
      '"Chameleon" by Herbie Hancock',
      'Stevie Wonder\'s classic period',
      'Modern neo-soul and R&B'
    ],
    funFacts: [
      'The most complex commonly used chord in popular music',
      'Signature sound of 1970s funk and fusion',
      'Often abbreviated by omitting the 5th and 11th'
    ]
  }
];

export function getChordOfTheDay(): ChordOfTheDay {
  // Use the current date as seed for consistent daily selection
  const today = new Date();
  const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / (24 * 60 * 60 * 1000));
  const chordIndex = dayOfYear % interestingChords.length;
  return interestingChords[chordIndex];
}

export function getRandomChord(): ChordOfTheDay {
  const randomIndex = Math.floor(Math.random() * interestingChords.length);
  return interestingChords[randomIndex];
}