import * as Tone from 'tone';

class AudioEngine {
  private synth: Tone.Sampler;
  private melodySynth: Tone.Sampler;
  private reverb: Tone.Reverb;
  private melodyReverb: Tone.Reverb;
  private chordCompressor: Tone.Compressor;
  private melodyCompressor: Tone.Compressor;
  private masterCompressor: Tone.Compressor;
  private filter: Tone.Filter;
  private isInitialized = false;
  private currentPlaybackResolver: (() => void) | null = null;
  private originalTempo: number | null = null;
  
  // Sustain and note tracking
  private activeNotes = new Map<string, Tone.Unit.Time>();
  private sustainedNotes = new Set<string>();
  private sustainEnabled = false;
  private autoSustainMs = 500;

  constructor() {
    // Create high-quality piano using Salamander Grand Piano samples
    // Professional-quality Yamaha C5 piano samples with proper octave coverage
    this.synth = new Tone.Sampler({
      urls: {
        A0: "A0.mp3", C1: "C1.mp3", "D#1": "Ds1.mp3",
        "F#1": "Fs1.mp3", A1: "A1.mp3", C2: "C2.mp3",
        "D#2": "Ds2.mp3", "F#2": "Fs2.mp3", A2: "A2.mp3",
        C3: "C3.mp3", "D#3": "Ds3.mp3", "F#3": "Fs3.mp3",
        A3: "A3.mp3", C4: "C4.mp3", "D#4": "Ds4.mp3",
        "F#4": "Fs4.mp3", A4: "A4.mp3", C5: "C5.mp3",
        "D#5": "Ds5.mp3", "F#5": "Fs5.mp3", A5: "A5.mp3",
        C6: "C6.mp3", "D#6": "Ds6.mp3", "F#6": "Fs6.mp3",
        A6: "A6.mp3", C7: "C7.mp3", "D#7": "Ds7.mp3",
        "F#7": "Fs7.mp3", A7: "A7.mp3", C8: "C8.mp3"
      },
      release: 1.2,
      baseUrl: "https://tonejs.github.io/audio/salamander/"
    });

    // Create melody synth with same high-quality samples
    this.melodySynth = new Tone.Sampler({
      urls: {
        A0: "A0.mp3", C1: "C1.mp3", "D#1": "Ds1.mp3",
        "F#1": "Fs1.mp3", A1: "A1.mp3", C2: "C2.mp3",
        "D#2": "Ds2.mp3", "F#2": "Fs2.mp3", A2: "A2.mp3",
        C3: "C3.mp3", "D#3": "Ds3.mp3", "F#3": "Fs3.mp3",
        A3: "A3.mp3", C4: "C4.mp3", "D#4": "Ds4.mp3",
        "F#4": "Fs4.mp3", A4: "A4.mp3", C5: "C5.mp3",
        "D#5": "Ds5.mp3", "F#5": "Fs5.mp3", A5: "A5.mp3",
        C6: "C6.mp3", "D#6": "Ds6.mp3", "F#6": "Fs6.mp3",
        A6: "A6.mp3", C7: "C7.mp3", "D#7": "Ds7.mp3",
        "F#7": "Fs7.mp3", A7: "A7.mp3", C8: "C8.mp3"
      },
      release: 1.2,
      baseUrl: "https://tonejs.github.io/audio/salamander/"
    });

    // Add reverb for natural piano sound
    this.reverb = new Tone.Reverb({
      decay: 2,
      wet: 0.15,
      preDelay: 0.01
    });

    // Add lighter reverb for melody
    this.melodyReverb = new Tone.Reverb({
      decay: 1.2,
      wet: 0.2,
      preDelay: 0.005
    });

    // Add a warm low-pass filter for piano-like tone
    this.filter = new Tone.Filter({
      frequency: 2800,
      type: 'lowpass',
      Q: 1.2
    });

    // Create separate compressors for each channel
    this.chordCompressor = new Tone.Compressor({
      threshold: -12,
      ratio: 4,
      attack: 0.003,
      release: 0.01
    });

    this.melodyCompressor = new Tone.Compressor({
      threshold: -15,
      ratio: 3,
      attack: 0.002,
      release: 0.008
    });

    // Master compressor for final limiting
    this.masterCompressor = new Tone.Compressor({
      threshold: -6,
      ratio: 2,
      attack: 0.001,
      release: 0.1
    });

    // Chain effects: 
    // Chords: synth -> filter -> chordCompressor -> reverb -> masterCompressor -> destination
    this.synth.chain(this.filter, this.chordCompressor, this.reverb, this.masterCompressor, Tone.Destination);
    
    // Melody: melodySynth -> melodyCompressor -> melodyReverb -> masterCompressor -> destination  
    this.melodySynth.chain(this.melodyCompressor, this.melodyReverb, this.masterCompressor);
    
    // Set reasonable volumes to prevent clashing
    this.synth.volume.value = -10; // Reduced volume for chords
    this.melodySynth.volume.value = -8; // Slightly louder for melody
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;
    
    try {
      await Tone.start();
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize audio:', error);
      throw error;
    }
  }

  async playNote(note: string, octave: number = 4, duration: string = '8n', velocity: number = 0.8): Promise<void> {
    await this.initialize();
    
    const noteWithOctave = `${note}${octave}`;
    // Use velocity-sensitive playback for more expression
    this.synth.triggerAttackRelease(noteWithOctave, duration, undefined, velocity);
  }

  async playChord(notes: string[], octave: number = 4, duration: string = '2n', velocity: number = 0.7): Promise<void> {
    await this.initialize();
    // Release all notes for chord changes to prevent excessive clashing
    this.synth.releaseAll();
    
    const notesWithOctave = notes.map(note => `${note}${octave}`);
    // Slightly lower velocity for chords to prevent harshness
    this.synth.triggerAttackRelease(notesWithOctave, duration, undefined, velocity);
  }

  // Play chords only (for chord progression playback)
  async playProgression(chords: string[][], tempo: number = 120, octave: number = 4): Promise<void> {
    await this.playComposition([], chords, tempo, octave);
  }

  setVolume(volume: number): void {
    // Clamp volume between 0 and 1 and convert to dB
    const clampedVolume = Math.max(0, Math.min(1, volume));
    this.synth.volume.value = Tone.gainToDb(clampedVolume * 0.4); // Scale down to prevent distortion
    this.melodySynth.volume.value = Tone.gainToDb(clampedVolume * 0.5); // Slightly louder for melody
  }

  // Play a melody note with the dedicated melody synth
  async playMelodyNote(note: string, octave: number = 5, duration: string = '8n', velocity: number = 0.9): Promise<void> {
    await this.initialize();
    
    const noteWithOctave = `${note}${octave}`;
    this.melodySynth.triggerAttackRelease(noteWithOctave, duration, undefined, velocity);
  }

  // Play a composition with both melody and chords
  async playComposition(
    melody: Array<{note: string, octave?: number, duration?: string, time: number}>, 
    chords: string[][], 
    tempo: number = 120, 
    chordOctave: number = 4
  ): Promise<void> {
    await this.initialize();
    
    return new Promise<void>((resolve) => {
      // Store resolver for manual stop handling
      this.currentPlaybackResolver = resolve;
      
      // Stop any currently playing transport and release all voices
      Tone.Transport.stop();
      Tone.Transport.cancel();
      this.synth.releaseAll();
      this.melodySynth.releaseAll();
      
      this.originalTempo = Tone.Transport.bpm.value;
      Tone.Transport.bpm.value = tempo;
      
      // Reset transport position
      Tone.Transport.position = 0;
      
      // Sort melody by time to ensure proper order
      const sortedMelody = [...melody].sort((a, b) => a.time - b.time);
      
      // Schedule melody notes (time is in beats, so use beats field)
      sortedMelody.forEach((noteInfo) => {
        const noteWithOctave = `${noteInfo.note}${noteInfo.octave || 5}`;
        const duration = noteInfo.duration || '8n';
        const time = `0:${noteInfo.time}:0`; // Use beats field for proper timing
        
        Tone.Transport.schedule((scheduleTime) => {
          this.melodySynth.triggerAttackRelease(noteWithOctave, duration, scheduleTime);
        }, time);
      });
      
      // Schedule chords
      chords.forEach((chord, index) => {
        const notesWithOctave = chord.map(note => `${note}${chordOctave}`);
        const time = `0:${index * 4}:0`; // Each chord plays every 4 beats
        
        Tone.Transport.schedule((scheduleTime) => {
          this.synth.triggerAttackRelease(notesWithOctave, '1m', scheduleTime);
        }, time);
      });
      
      // Calculate total duration in beats
      const melodyEndTime = melody.length > 0 ? Math.max(...melody.map(n => n.time)) + 4 : 0;
      const chordEndTime = chords.length * 4;
      const totalDuration = Math.max(melodyEndTime, chordEndTime);
      
      // Schedule transport to stop after composition (using beats field)
      Tone.Transport.schedule(() => {
        this.finishPlayback();
      }, `0:${totalDuration}:0`);
      
      // Start the transport
      Tone.Transport.start();
    });
  }

  private finishPlayback(): void {
    Tone.Transport.stop();
    Tone.Transport.cancel();
    
    if (this.originalTempo !== null) {
      Tone.Transport.bpm.value = this.originalTempo;
      this.originalTempo = null;
    }
    
    if (this.currentPlaybackResolver) {
      this.currentPlaybackResolver();
      this.currentPlaybackResolver = null;
    }
  }

  // Play melody only (for separate melody playback)
  async playMelodyOnly(notes: Array<{note: string, octave?: number, duration?: string, time: number}>, tempo: number = 120): Promise<void> {
    await this.playComposition(notes, [], tempo);
  }

  // Stop all currently playing sounds
  stopAll(): void {
    this.synth.releaseAll();
    this.melodySynth.releaseAll();
    this.finishPlayback(); // This handles Transport stop and promise resolution
  }

  // Enhanced note control with sustain support
  noteOn(note: string, octave: number = 5, velocity: number = 0.8): void {
    if (!this.isInitialized) {
      this.initialize();
    }
    
    const noteWithOctave = `${note}${octave}`;
    const noteKey = `${note}-${octave}`;
    
    // Store the note as active
    this.activeNotes.set(noteKey, Tone.now());
    
    // Play the note
    this.melodySynth.triggerAttack(noteWithOctave, undefined, velocity);
  }
  
  noteOff(note: string, octave: number = 5): void {
    if (!this.isInitialized) return;
    
    const noteWithOctave = `${note}${octave}`;
    const noteKey = `${note}-${octave}`;
    
    // Remove from active notes
    this.activeNotes.delete(noteKey);
    
    if (this.sustainEnabled) {
      // Add to sustained notes instead of releasing immediately
      this.sustainedNotes.add(noteKey);
      
      // Auto-release after autoSustainMs if configured
      if (this.autoSustainMs > 0) {
        setTimeout(() => {
          if (this.sustainedNotes.has(noteKey)) {
            this.sustainedNotes.delete(noteKey);
            this.melodySynth.triggerRelease(noteWithOctave);
          }
        }, this.autoSustainMs);
      }
    } else {
      // Immediate release
      this.melodySynth.triggerRelease(noteWithOctave);
    }
  }
  
  setSustainEnabled(enabled: boolean): void {
    this.sustainEnabled = enabled;
    if (!enabled) {
      this.releaseSustainedNotes();
    }
  }
  
  setAutoSustainMs(ms: number): void {
    this.autoSustainMs = ms;
  }
  
  releaseSustainedNotes(): void {
    this.sustainedNotes.forEach(noteKey => {
      const [note, octaveStr] = noteKey.split('-');
      const noteWithOctave = `${note}${octaveStr}`;
      this.melodySynth.triggerRelease(noteWithOctave);
    });
    this.sustainedNotes.clear();
  }
  
  // Get current sustain state
  getSustainState() {
    return {
      enabled: this.sustainEnabled,
      autoSustainMs: this.autoSustainMs,
      sustainedNotes: Array.from(this.sustainedNotes),
      activeNotes: Array.from(this.activeNotes.keys())
    };
  }

  dispose(): void {
    this.stopAll();
    this.releaseSustainedNotes();
    this.synth.dispose();
    this.melodySynth.dispose();
    this.filter.dispose();
    this.reverb.dispose();
    this.melodyReverb.dispose();
    this.chordCompressor.dispose();
    this.melodyCompressor.dispose();
    this.masterCompressor.dispose();
    this.activeNotes.clear();
    this.sustainedNotes.clear();
    this.isInitialized = false;
  }
}

export const audioEngine = new AudioEngine();
