import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Capacitor mobile initialization
import { Capacitor } from '@capacitor/core';
import { SplashScreen } from '@capacitor/splash-screen';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Keyboard } from '@capacitor/keyboard';

// Initialize mobile features if running on mobile
if (Capacitor.isNativePlatform()) {
  // Configure status bar for mobile
  StatusBar.setStyle({ style: Style.Dark });
  StatusBar.setBackgroundColor({ color: '#8b5cf6' });
  
  // Configure keyboard behavior
  Keyboard.setAccessoryBarVisible({ isVisible: false });
  Keyboard.setScroll({ isDisabled: false });
  
  // Hide splash screen after app loads
  SplashScreen.hide();
  
  // Prevent device sleep during piano use
  document.addEventListener('DOMContentLoaded', () => {
    // Keep screen on during use
    if ('wakeLock' in navigator && 'request' in navigator.wakeLock) {
      (navigator.wakeLock as any).request('screen').catch(() => {
        // Fail silently if wake lock not supported
      });
    }
  });
  
  // Handle hardware back button on Android
  if (Capacitor.getPlatform() === 'android') {
    document.addEventListener('ionBackButton', (ev: any) => {
      ev.detail.register(-1, () => {
        // Let the user exit the app naturally
      });
    });
  }
}

// Enhanced mobile viewport handling
const updateViewportHeight = () => {
  const vh = window.innerHeight * 0.01;
  document.documentElement.style.setProperty('--vh', `${vh}px`);
};

if (typeof window !== 'undefined') {
  updateViewportHeight();
  window.addEventListener('resize', updateViewportHeight);
  window.addEventListener('orientationchange', () => {
    setTimeout(updateViewportHeight, 100);
  });
}

createRoot(document.getElementById("root")!).render(<App />);
