package com.pianoteacher.mobile;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
