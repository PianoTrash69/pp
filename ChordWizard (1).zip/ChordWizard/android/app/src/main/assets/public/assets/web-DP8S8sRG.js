import{W as n}from"./index-g8eDPGbF.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
