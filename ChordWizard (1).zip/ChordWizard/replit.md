# Overview

Your Mobile Piano Teacher is a modern web application for music theory education and chord progression creation. It provides an interactive platform where users can explore musical scales, build chord progressions, play notes on a virtual piano keyboard, and learn music theory concepts through hands-on experimentation. The application features real-time audio playback, drag-and-drop chord building, and educational tools for understanding musical relationships.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client is built with React and TypeScript using a component-based architecture. The application uses Vite as the build tool and development server, providing fast hot module replacement. State management is handled through React hooks and custom hooks for specific domains (audio, chord progressions, themes). The UI is built with shadcn/ui components based on Radix UI primitives, styled with Tailwind CSS for consistent design and theming support (light/dark modes).

## Backend Architecture
The server follows a lightweight Express.js architecture with a modular route system. The backend is designed to be stateless and currently includes minimal API endpoints, with the storage interface prepared for future database integration. The server includes development middleware for Vite integration and error handling middleware for API requests.

## Data Storage
The application uses Drizzle ORM with PostgreSQL for data persistence, configured through environment variables. The database schema includes a chord progressions table for saving user-created progressions. The storage layer is abstracted through an interface pattern, allowing for easy switching between different storage implementations.

## Audio System
Audio functionality is implemented using Tone.js for web audio synthesis. The audio engine supports note playback, chord generation, and progression sequencing with configurable tempo and octave settings. Error handling ensures graceful degradation when audio contexts fail to initialize.

## Music Theory Engine
The core music theory logic is implemented as pure functions that generate scales, chords, and progressions based on musical intervals and chord qualities. The system supports comprehensive scale generation with all 12 chromatic roots across 9 different modes (108 total scales), organized by musical dissonance from most consonant to most dissonant. The engine features mode-aware seventh chord detection that calculates actual semitone intervals to determine correct chord types (dominant 7th, minor-major 7th, half-diminished, fully diminished, etc.) with accurate Roman numeral analysis.

## Component Architecture
The UI is organized into feature-specific components:
- Piano keyboard with octave selection and visual feedback
- Chord progression builder with drag-and-drop functionality
- Scale selector with automatic chord generation
- Chord library with audio playback and modal diagrams
- Quick actions for common progressions

## Development Workflow
The application uses TypeScript for type safety across the entire stack with shared types between client and server. The build process compiles both frontend and backend code, with the frontend built to a static directory and the backend bundled for production deployment.

# External Dependencies

## UI and Styling
- **Radix UI**: Headless UI components for accessibility and functionality
- **Tailwind CSS**: Utility-first CSS framework for styling
- **shadcn/ui**: Pre-built component library based on Radix UI
- **Lucide React**: Icon library for consistent iconography
- **class-variance-authority**: Type-safe variant management for components

## Audio Processing
- **Tone.js**: Web Audio API wrapper for sound synthesis and sequencing
- **Audio Context**: Browser API for real-time audio processing and playback

## Data Management
- **Drizzle ORM**: Type-safe SQL ORM for database operations
- **Drizzle Kit**: Database migration and schema management tools
- **@neondatabase/serverless**: PostgreSQL driver for serverless environments
- **Zod**: Runtime type validation for data schemas

## Development Tools
- **Vite**: Build tool and development server with HMR
- **TypeScript**: Static type checking for JavaScript
- **ESBuild**: Fast JavaScript bundler for production builds
- **@replit/vite-plugin-***: Replit-specific development plugins

## Routing and State
- **Wouter**: Lightweight client-side routing library
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form state management with validation

## Backend Infrastructure
- **Express.js**: Web server framework for API routes
- **connect-pg-simple**: PostgreSQL session store for Express
- **nanoid**: URL-safe unique ID generator